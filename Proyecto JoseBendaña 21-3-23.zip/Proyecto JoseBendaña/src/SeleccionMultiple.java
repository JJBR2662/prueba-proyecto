
import java.awt.Color;
import java.awt.Dimension;
import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

public class SeleccionMultiple extends Pregunta {

    private ArrayList<String> respdisp = new ArrayList();
    private ArrayList<String> respcorrectas = new ArrayList();

    public SeleccionMultiple() {
    }

    public SeleccionMultiple(String pregunta, int puntuacion) {
        super(pregunta, puntuacion);
    }

    public ArrayList<String> getRespdisp() {
        return respdisp;
    }

    public void setRespdisp(ArrayList<String> respdisp) {
        this.respdisp = respdisp;
    }

    public ArrayList<String> getRespcorrectas() {
        return respcorrectas;
    }

    public void setRespcorrectas(ArrayList<String> respcorrectas) {
        this.respcorrectas = respcorrectas;
    }

    @Override
    public String toString() {
        return "SeleccionMultiple{" + "respdisp=" + respdisp + ", respcorrectas=" + respcorrectas;
    }

    @Override
    public boolean evaluar(JPanel panel, Pregunta pregunta) {
        for (int i = 0; i < respdisp.size(); i++) {
            if (((JRadioButton) panel.getComponent(i + 1)).isSelected()) {
                if (((JRadioButton) panel.getComponent(i + 1)).getText().equalsIgnoreCase(respcorrectas.get(0))) {
                    JLabel sim = new JLabel(new javax.swing.ImageIcon(getClass().getResource("Imagenes/buena+(1).png")));
                    sim.setPreferredSize(new Dimension(35, 37));
                    sim.setSize(new Dimension(35, 37));
                    panel.add(sim);
                    panel.setBackground(Color.green);
                    return true;
                }
            }
        }
        JLabel sim = new JLabel(new javax.swing.ImageIcon(getClass().getResource("Imagenes/incorrecta.png")));
        sim.setPreferredSize(new Dimension(36, 36));
        sim.setSize(new Dimension(36, 36));
        panel.add(sim);
        panel.setBackground(Color.red);
        return false;
    }
}
