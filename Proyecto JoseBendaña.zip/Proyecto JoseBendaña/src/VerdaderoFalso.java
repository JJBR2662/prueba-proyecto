
public class VerdaderoFalso extends Pregunta{
    private boolean respcorrecta;

    public VerdaderoFalso() {
    }

    public VerdaderoFalso(boolean respcorrecta, String pregunta, int puntuacion) {
        super(pregunta, puntuacion);
        this.respcorrecta = respcorrecta;
    }

    

    public boolean isRespcorrecta() {
        return respcorrecta;
    }

    public void setRespcorrecta(boolean respcorrecta) {
        this.respcorrecta = respcorrecta;
    }

    @Override
    public String toString() {
        return "VerdaderoFalso{" + "respcorrecta=" + respcorrecta + '}';
    }
    
    
}
