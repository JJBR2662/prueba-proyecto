
import java.awt.Image;
import java.awt.Toolkit;
import desplazable.Desface;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import org.netbeans.lib.awtextra.AbsoluteLayout;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
/**
 *
 * @author Rolivis
 */
public class Principal extends javax.swing.JFrame {

    /**
     * Creates new form Principal
     */
    private ActionListener cambio = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            actualizartiempo();
            SimpleDateFormat formato = new SimpleDateFormat("hh:mm:ss");
            System.out.println("minuto" + formato.format(momentoactual));
        }
    };

    private ActionListener sumar = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            tiempotransc++;
            System.out.println("tiempo transcurrido en examen: "+tiempotransc+", tiempo del examen: "+tiempoex );
            if (tiempotransc == tiempoex) {
                if (JF_EXAMEN.isVisible() && boton_entregarex.isVisible()) {
                    au.CargarArchivo();
                    int notaex = 0;
                    for (int i = 0; i < paneles.size(); i++) {
                        int cuantasbuenas = 0;
                        if (((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i) instanceof Enumeracion) {
                            cuantasbuenas = 0;
                            int notaporbuena = ((Enumeracion) ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i)).getPuntuacion() / ((Enumeracion) ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i)).getRespcorrectas().size();
                            for (int j = 0; j < ((Enumeracion) ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i)).getCOPIARESP().size(); j++) {
                                ((Enumeracion) ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i)).getCOPIARESP().remove(j);
                            }
                            for (int j = 0; j < ((Enumeracion) ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i)).getRespcorrectas().size(); j++) {
                                ((Enumeracion) ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i)).getCOPIARESP().add(((Enumeracion) ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i)).getRespcorrectas().get(j));
                            }
                            System.out.println("Cant resp correctas: " + ((Enumeracion) ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i)).getRespcorrectas().size());
                            for (int j = 0; j < ((Enumeracion) ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i)).getRespcorrectas().size(); j++) {
                                System.out.println("Resp correctas " + ((Enumeracion) ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i)).getRespcorrectas());
                                System.out.println("Copia Resp correctas " + ((Enumeracion) ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i)).getCOPIARESP());
                                if (((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i).evaluar(paneles.get(i), ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i)) == true) {
                                    cuantasbuenas++;
                                }
                            }
                            notaex += notaporbuena * cuantasbuenas;
                            if (cuantasbuenas == 0) {
                                JLabel sim = new JLabel(new javax.swing.ImageIcon(getClass().getResource("Imagenes/incorrecta.png")));
                                sim.setPreferredSize(new Dimension(36, 36));
                                sim.setSize(new Dimension(36, 36));
                                paneles.get(i).add(sim);
                                paneles.get(i).setBackground(Color.red);
                                String lcor = "Las respuestas correctas son ";
                                for (int j = 0; j < ((Enumeracion) ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i)).getRespcorrectas().size(); j++) {
                                    lcor += ((Enumeracion) ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i)).getRespcorrectas().get(j) + " ";
                                }
                                paneles.get(i).add(new JLabel(lcor));
                            } else if (cuantasbuenas == ((Enumeracion) ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i)).getRespcorrectas().size()) {
                                JLabel sim = new JLabel(new javax.swing.ImageIcon(getClass().getResource("Imagenes/buena+(1).png")));
                                sim.setPreferredSize(new Dimension(35, 37));
                                sim.setSize(new Dimension(35, 37));
                                paneles.get(i).add(sim);
                                paneles.get(i).setBackground(Color.green);
                            } else {
                                JLabel sim = new JLabel(new javax.swing.ImageIcon(getClass().getResource("Imagenes/maso.png")));
                                sim.setPreferredSize(new Dimension(35, 37));
                                sim.setSize(new Dimension(35, 37));
                                paneles.get(i).add(sim);
                                paneles.get(i).setBackground(Color.yellow);
                                String lcor = "Las respuestas correctas son ";
                                for (int j = 0; j < ((Enumeracion) ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i)).getRespcorrectas().size(); j++) {
                                    lcor += ((Enumeracion) ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i)).getRespcorrectas().get(j) + " ";
                                }
                                paneles.get(i).add(new JLabel(lcor));
                            }
                            System.out.println(cuantasbuenas + " buenas");
                            cuantasbuenas = 0;
                        } else {
                            if (((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i).evaluar(paneles.get(i), ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i)) == true) {
                                notaex += (((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i)).getPuntuacion();
                            }
                            System.out.println(((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i));
                            System.out.println(((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i).evaluar(paneles.get(i), ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i)));
                            paneles.get(i).remove(paneles.get(i).getComponentCount() - 1);
                        }
                    }
                    System.out.println("nota" + notaex);

                    ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).setNota(notaex);
                    ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).setIntento(1);
                    for (int i = 0; i < au.getUsuarios().size(); i++) {
                        if (au.getUsuarios().get(i) instanceof Alumno) {
                            ((Alumno) au.getUsuarios().get(i)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getNota();
                        }
                    }
                    
                    JOptionPane.showMessageDialog(jf_inicioalumno, "Se cerro el examen por temas de tiempo, se entregara con lo que quedo");
                    boton_entregarex.setVisible(false);
                    timer_ex.stop();
                    tiempotransc=0;
//        JF_EXAMEN.setVisible(false);
                    au.EscribirArchivo();
                    au.CargarArchivo();
                }
            }
        }
    };

    public Image getIconImage() {
        Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("Imagenes/bayern.png"));
        return retValue;
    }

    public Principal() {
        initComponents();
        this.setExtendedState(MAXIMIZED_BOTH);
        au.CargarArchivo();
        ac.CargarArchivo();
        llenarchoices();
        desplace = new Desface();
        desplace2 = new Desface();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jf_inicioregistro = new javax.swing.JFrame();
        jp_inicioregistro = new javax.swing.JPanel();
        esconder1 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        esconder2 = new javax.swing.JTextArea();
        jScrollPane1 = new javax.swing.JScrollPane();
        esconder3 = new javax.swing.JTextArea();
        jLabel88 = new javax.swing.JLabel();
        Jp_asignarmaestroclase = new javax.swing.JPanel();
        jLabel125 = new javax.swing.JLabel();
        jScrollPane18 = new javax.swing.JScrollPane();
        jlista_maestroasig = new javax.swing.JList<>();
        jLabel126 = new javax.swing.JLabel();
        jScrollPane19 = new javax.swing.JScrollPane();
        jtable_maestroenclase = new javax.swing.JTable();
        jLabel127 = new javax.swing.JLabel();
        jScrollPane20 = new javax.swing.JScrollPane();
        jlista_metermaestroclase = new javax.swing.JList<>();
        jLabel128 = new javax.swing.JLabel();
        jButton8 = new javax.swing.JButton();
        jp_asignaralumclase = new javax.swing.JPanel();
        jScrollPane15 = new javax.swing.JScrollPane();
        jlista_clases = new javax.swing.JList<>();
        jLabel114 = new javax.swing.JLabel();
        jScrollPane16 = new javax.swing.JScrollPane();
        jlista_alumnosag = new javax.swing.JList<>();
        jLabel121 = new javax.swing.JLabel();
        jScrollPane17 = new javax.swing.JScrollPane();
        jtable_alumnosenclase = new javax.swing.JTable();
        jLabel122 = new javax.swing.JLabel();
        jLabel124 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jp_EliminarClase = new javax.swing.JPanel();
        jLabel109 = new javax.swing.JLabel();
        jb_eliminarMaestro2 = new javax.swing.JButton();
        jScrollPane12 = new javax.swing.JScrollPane();
        jlista_eliminarClase = new javax.swing.JList<>();
        jLabel210 = new javax.swing.JLabel();
        jpanel_elimregistro = new javax.swing.JPanel();
        jLabel111 = new javax.swing.JLabel();
        jScrollPane14 = new javax.swing.JScrollPane();
        jlista_eliminarRegistro = new javax.swing.JList<>();
        jb_eliminarRegistro = new javax.swing.JButton();
        jLabel211 = new javax.swing.JLabel();
        jp_EliminarAlumno = new javax.swing.JPanel();
        jLabel108 = new javax.swing.JLabel();
        jb_eliminarMaestro1 = new javax.swing.JButton();
        jScrollPane11 = new javax.swing.JScrollPane();
        jlista_eliminarAlumno = new javax.swing.JList<>();
        jLabel123 = new javax.swing.JLabel();
        jLabel212 = new javax.swing.JLabel();
        jp_eliminarmaestro = new javax.swing.JPanel();
        jLabel107 = new javax.swing.JLabel();
        jScrollPane10 = new javax.swing.JScrollPane();
        jlista_eliminarmister = new javax.swing.JList<>();
        jb_eliminarMaestro = new javax.swing.JButton();
        jLabel213 = new javax.swing.JLabel();
        jp_modificarclase = new javax.swing.JPanel();
        md1_UVNuevoClase = new javax.swing.JSpinner();
        md1_TipoHoraNuevoClase = new javax.swing.JComboBox<>();
        md1_SemestreNuevoClase = new javax.swing.JSpinner();
        md1_PeriodoNuevoClase = new javax.swing.JSpinner();
        md1_IDNuevoClase = new javax.swing.JFormattedTextField();
        jLabel98 = new javax.swing.JLabel();
        jb_modificarclase = new javax.swing.JButton();
        jSeparator34 = new javax.swing.JSeparator();
        jSeparator35 = new javax.swing.JSeparator();
        jLabel99 = new javax.swing.JLabel();
        md1_AnioNuevoClase = new com.toedter.calendar.JDateChooser();
        jLabel100 = new javax.swing.JLabel();
        jSeparator36 = new javax.swing.JSeparator();
        md1_MinutosNuevoClase = new javax.swing.JSpinner();
        jLabel101 = new javax.swing.JLabel();
        jSeparator37 = new javax.swing.JSeparator();
        md1_HoraNuevoClase = new javax.swing.JSpinner();
        jLabel102 = new javax.swing.JLabel();
        jSeparator38 = new javax.swing.JSeparator();
        jSeparator39 = new javax.swing.JSeparator();
        jLabel103 = new javax.swing.JLabel();
        jLabel104 = new javax.swing.JLabel();
        jSeparator40 = new javax.swing.JSeparator();
        jLabel105 = new javax.swing.JLabel();
        md1_NombreNuevoClase = new javax.swing.JTextField();
        jLabel106 = new javax.swing.JLabel();
        jScrollPane9 = new javax.swing.JScrollPane();
        jlista_clasesmod = new javax.swing.JList<>();
        jLabel214 = new javax.swing.JLabel();
        jpanel_modregistro = new javax.swing.JPanel();
        jb_crearregistro1 = new javax.swing.JButton();
        jSeparator44 = new javax.swing.JSeparator();
        jt_contraregistromod = new javax.swing.JTextField();
        jt_userregistromod = new javax.swing.JTextField();
        jSeparator46 = new javax.swing.JSeparator();
        jLabel113 = new javax.swing.JLabel();
        jLabel117 = new javax.swing.JLabel();
        jLabel119 = new javax.swing.JLabel();
        jLabel120 = new javax.swing.JLabel();
        jSeparator47 = new javax.swing.JSeparator();
        jt_nombreregistromod = new javax.swing.JTextField();
        jScrollPane13 = new javax.swing.JScrollPane();
        jlista_ModificarRegistro = new javax.swing.JList<>();
        jLabel215 = new javax.swing.JLabel();
        jp_modalumno = new javax.swing.JPanel();
        jSeparator28 = new javax.swing.JSeparator();
        jButton7 = new javax.swing.JButton();
        jLabel90 = new javax.swing.JLabel();
        md_NuevaCarreraAlumno = new javax.swing.JTextField();
        jLabel91 = new javax.swing.JLabel();
        jLabel92 = new javax.swing.JLabel();
        md_NuevoRolAlumno = new javax.swing.JTextField();
        jLabel93 = new javax.swing.JLabel();
        jSeparator29 = new javax.swing.JSeparator();
        md_NuevaContraAlumno = new javax.swing.JTextField();
        jLabel94 = new javax.swing.JLabel();
        jSeparator30 = new javax.swing.JSeparator();
        jSeparator31 = new javax.swing.JSeparator();
        jLabel95 = new javax.swing.JLabel();
        jSeparator32 = new javax.swing.JSeparator();
        md_NuevoNumCuentaAlumno = new javax.swing.JFormattedTextField();
        jLabel96 = new javax.swing.JLabel();
        jSeparator33 = new javax.swing.JSeparator();
        jLabel97 = new javax.swing.JLabel();
        md_NuevoNombreAlumno = new javax.swing.JTextField();
        md_NuevoUserAlumno = new javax.swing.JTextField();
        jScrollPane8 = new javax.swing.JScrollPane();
        jlista_modalumnos = new javax.swing.JList<>();
        jLabel216 = new javax.swing.JLabel();
        jp_modificarmaestros = new javax.swing.JPanel();
        jt_modificarnombremaestro = new javax.swing.JTextField();
        jLabel79 = new javax.swing.JLabel();
        jSeparator21 = new javax.swing.JSeparator();
        jLabel80 = new javax.swing.JLabel();
        jLabel81 = new javax.swing.JLabel();
        jt_modificarusermaestro = new javax.swing.JTextField();
        jSeparator22 = new javax.swing.JSeparator();
        jSeparator23 = new javax.swing.JSeparator();
        JB_MODIFICARMAESTRO = new javax.swing.JButton();
        jSeparator24 = new javax.swing.JSeparator();
        jSeparator25 = new javax.swing.JSeparator();
        jLabel82 = new javax.swing.JLabel();
        jLabel83 = new javax.swing.JLabel();
        jSeparator26 = new javax.swing.JSeparator();
        jLabel84 = new javax.swing.JLabel();
        jf_modificaridmaestro = new javax.swing.JFormattedTextField();
        jt_ModificarProfesionMaestro = new javax.swing.JTextField();
        jt_ModificarRolMaestro = new javax.swing.JTextField();
        jf_ModificarSueldoMaestro = new javax.swing.JFormattedTextField();
        jLabel85 = new javax.swing.JLabel();
        jLabel86 = new javax.swing.JLabel();
        jt_modificarcontramaestro = new javax.swing.JTextField();
        jSeparator27 = new javax.swing.JSeparator();
        jLabel87 = new javax.swing.JLabel();
        jScrollPane7 = new javax.swing.JScrollPane();
        jl_maestrosamodificar = new javax.swing.JList<>();
        jLabel69 = new javax.swing.JLabel();
        jLabel217 = new javax.swing.JLabel();
        jp_crearregistro = new javax.swing.JPanel();
        jb_crearregistro = new javax.swing.JButton();
        jSeparator42 = new javax.swing.JSeparator();
        jt_contraregistronuevo = new javax.swing.JTextField();
        jt_userregistronuevo = new javax.swing.JTextField();
        jSeparator43 = new javax.swing.JSeparator();
        jLabel112 = new javax.swing.JLabel();
        jLabel115 = new javax.swing.JLabel();
        jLabel116 = new javax.swing.JLabel();
        jLabel118 = new javax.swing.JLabel();
        jSeparator45 = new javax.swing.JSeparator();
        jt_nombreregistronuevo = new javax.swing.JTextField();
        jp_crearmaestro = new javax.swing.JPanel();
        jLabel52 = new javax.swing.JLabel();
        jLabel53 = new javax.swing.JLabel();
        jt_nombremaestronuevo = new javax.swing.JTextField();
        jLabel54 = new javax.swing.JLabel();
        jt_usermaestronuevo = new javax.swing.JTextField();
        jLabel55 = new javax.swing.JLabel();
        jt_contramaestronuevo = new javax.swing.JTextField();
        jLabel56 = new javax.swing.JLabel();
        jf_Sueldomaestronuevo = new javax.swing.JFormattedTextField();
        jLabel57 = new javax.swing.JLabel();
        jt_profesionmaestronuevo = new javax.swing.JTextField();
        jLabel58 = new javax.swing.JLabel();
        JT_Rolmaestronuevo = new javax.swing.JTextField();
        jLabel59 = new javax.swing.JLabel();
        jf_idmaestronuevo = new javax.swing.JFormattedTextField();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        jSeparator3 = new javax.swing.JSeparator();
        jSeparator4 = new javax.swing.JSeparator();
        jSeparator5 = new javax.swing.JSeparator();
        jSeparator6 = new javax.swing.JSeparator();
        jSeparator7 = new javax.swing.JSeparator();
        jButton1 = new javax.swing.JButton();
        jLabel60 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jp_crearAlumno = new javax.swing.JPanel();
        jLabel62 = new javax.swing.JLabel();
        jLabel61 = new javax.swing.JLabel();
        jt_nombrealumnonuevo = new javax.swing.JTextField();
        jLabel63 = new javax.swing.JLabel();
        jt_useralumnonuevo = new javax.swing.JTextField();
        jLabel64 = new javax.swing.JLabel();
        jt_contraalumnonuevo = new javax.swing.JTextField();
        jSeparator8 = new javax.swing.JSeparator();
        jSeparator9 = new javax.swing.JSeparator();
        jSeparator11 = new javax.swing.JSeparator();
        jSeparator12 = new javax.swing.JSeparator();
        jSeparator13 = new javax.swing.JSeparator();
        jSeparator14 = new javax.swing.JSeparator();
        jLabel65 = new javax.swing.JLabel();
        jLabel66 = new javax.swing.JLabel();
        jLabel67 = new javax.swing.JLabel();
        jLabel68 = new javax.swing.JLabel();
        jf_numcuentanuevoalumno = new javax.swing.JFormattedTextField();
        jt_rolalumnonuevo = new javax.swing.JTextField();
        jt_carreranuevoalumno = new javax.swing.JTextField();
        jButton6 = new javax.swing.JButton();
        jLabel89 = new javax.swing.JLabel();
        jp_crearclase = new javax.swing.JPanel();
        jLabel70 = new javax.swing.JLabel();
        jt_nombreclasenueva = new javax.swing.JTextField();
        jLabel71 = new javax.swing.JLabel();
        jSeparator15 = new javax.swing.JSeparator();
        jLabel72 = new javax.swing.JLabel();
        jLabel73 = new javax.swing.JLabel();
        jSeparator10 = new javax.swing.JSeparator();
        jSeparator16 = new javax.swing.JSeparator();
        jLabel74 = new javax.swing.JLabel();
        jSeparator17 = new javax.swing.JSeparator();
        js_horaclasenueva = new javax.swing.JSpinner();
        jLabel75 = new javax.swing.JLabel();
        js_minutoclasenueva = new javax.swing.JSpinner();
        jc_tipohoraclasenueva = new javax.swing.JComboBox<>();
        jSeparator18 = new javax.swing.JSeparator();
        js_semestreclasenueva = new javax.swing.JSpinner();
        jLabel77 = new javax.swing.JLabel();
        jSeparator20 = new javax.swing.JSeparator();
        js_Periodoclasenueva = new javax.swing.JSpinner();
        jLabel78 = new javax.swing.JLabel();
        jLabel76 = new javax.swing.JLabel();
        jSeparator19 = new javax.swing.JSeparator();
        js_uvclasenueva = new javax.swing.JSpinner();
        jb_crearclasenueva = new javax.swing.JButton();
        jf_idclasenueva = new javax.swing.JFormattedTextField();
        anioclasenueva = new com.toedter.calendar.JDateChooser();
        jp_todoregistro = new javax.swing.JPanel();
        jLabel110 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        ch_registro_registro = new java.awt.Choice();
        jLabel18 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        ch_clases_registro = new java.awt.Choice();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jl_claveregistro = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jl_usuarioregistro = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jl_correoregistro = new javax.swing.JLabel();
        jb_cerrarsesionregistro = new javax.swing.JButton();
        jLabel15 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        ch_maestros_registro = new java.awt.Choice();
        ch_alumnos_registro = new java.awt.Choice();
        jLabel11 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jf_iniciomaestro = new javax.swing.JFrame();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jp_menudesp = new javax.swing.JPanel();
        jl_barramaestros = new javax.swing.JLabel();
        jl_homemaestros = new javax.swing.JLabel();
        jl_crearexamen = new javax.swing.JLabel();
        jl_modificarexamen = new javax.swing.JLabel();
        jl_eliminarexamen = new javax.swing.JLabel();
        jl_vernota = new javax.swing.JLabel();
        jl_cuadrodenotas = new javax.swing.JLabel();
        jl_creartarea = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jl_usuario = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jl_correo = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jl_clave = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        jL_fondomenudesp2 = new javax.swing.JLabel();
        crear_tarea = new javax.swing.JPanel();
        jLabel167 = new javax.swing.JLabel();
        jLabel141 = new javax.swing.JLabel();
        jt_nombretarea = new javax.swing.JTextField();
        jSeparator51 = new javax.swing.JSeparator();
        jLabel143 = new javax.swing.JLabel();
        jSeparator52 = new javax.swing.JSeparator();
        jcb_tipo = new javax.swing.JComboBox<>();
        jSeparator53 = new javax.swing.JSeparator();
        jLabel168 = new javax.swing.JLabel();
        jdc_fechaentrega = new com.toedter.calendar.JDateChooser();
        jLabel169 = new javax.swing.JLabel();
        jdc_fechacierre = new com.toedter.calendar.JDateChooser();
        jSeparator54 = new javax.swing.JSeparator();
        jLabel170 = new javax.swing.JLabel();
        hora_tarea_emp = new javax.swing.JSpinner();
        jLabel171 = new javax.swing.JLabel();
        minuto_tarea_emp = new javax.swing.JSpinner();
        jSeparator55 = new javax.swing.JSeparator();
        jLabel172 = new javax.swing.JLabel();
        hora_tarea_cierre = new javax.swing.JSpinner();
        jLabel173 = new javax.swing.JLabel();
        minuto_tarea_cierre = new javax.swing.JSpinner();
        jSeparator56 = new javax.swing.JSeparator();
        jb_crearTarea = new javax.swing.JButton();
        jScrollPane40 = new javax.swing.JScrollPane();
        lista_clases_tarea = new javax.swing.JList<>();
        jButton18 = new javax.swing.JButton();
        jScrollPane50 = new javax.swing.JScrollPane();
        jTextArea2 = new javax.swing.JTextArea();
        jLabel205 = new javax.swing.JLabel();
        puntaje_tarea = new javax.swing.JSpinner();
        jSeparator58 = new javax.swing.JSeparator();
        jLabel218 = new javax.swing.JLabel();
        jp_iniciomaestro = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel43 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTextArea3 = new javax.swing.JTextArea();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTextArea4 = new javax.swing.JTextArea();
        jLabel33 = new javax.swing.JLabel();
        jf_mod_ex = new javax.swing.JPanel();
        jScrollPane43 = new javax.swing.JScrollPane();
        lista2lista_exa = new javax.swing.JList<>();
        jScrollPane44 = new javax.swing.JScrollPane();
        listalista_clases = new javax.swing.JList<>();
        jLabel179 = new javax.swing.JLabel();
        jLabel180 = new javax.swing.JLabel();
        jLabel181 = new javax.swing.JLabel();
        sp_newtimeex = new javax.swing.JSpinner();
        jSeparator59 = new javax.swing.JSeparator();
        jLabel182 = new javax.swing.JLabel();
        jd_fechaexamenmod = new com.toedter.calendar.JDateChooser();
        jSeparator60 = new javax.swing.JSeparator();
        jLabel183 = new javax.swing.JLabel();
        sp_newhora = new javax.swing.JSpinner();
        jSeparator61 = new javax.swing.JSeparator();
        sp_newminute = new javax.swing.JSpinner();
        jLabel184 = new javax.swing.JLabel();
        jButton19 = new javax.swing.JButton();
        jb_modex = new javax.swing.JButton();
        jScrollPane45 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel186 = new javax.swing.JLabel();
        Cuadro_Notas = new javax.swing.JPanel();
        jLabel158 = new javax.swing.JLabel();
        jScrollPane30 = new javax.swing.JScrollPane();
        cn_tabla = new javax.swing.JList<>();
        jScrollPane31 = new javax.swing.JScrollPane();
        tabla_cuadro = new javax.swing.JTable();
        jLabel219 = new javax.swing.JLabel();
        Resu_cadaex = new javax.swing.JPanel();
        jScrollPane27 = new javax.swing.JScrollPane();
        verresu_listaclase = new javax.swing.JList<>();
        jLabel157 = new javax.swing.JLabel();
        jScrollPane28 = new javax.swing.JScrollPane();
        verresu_listaexa = new javax.swing.JList<>();
        jScrollPane29 = new javax.swing.JScrollPane();
        tabla_verresu = new javax.swing.JTable();
        jLabel220 = new javax.swing.JLabel();
        jLabel221 = new javax.swing.JLabel();
        Elim_Jp_examen = new javax.swing.JPanel();
        jLabel156 = new javax.swing.JLabel();
        jScrollPane25 = new javax.swing.JScrollPane();
        elim_Lista_Elejirclase = new javax.swing.JList<>();
        jScrollPane26 = new javax.swing.JScrollPane();
        elim_Lista_Elejirexamen = new javax.swing.JList<>();
        jButton11 = new javax.swing.JButton();
        jLabel222 = new javax.swing.JLabel();
        jLabel223 = new javax.swing.JLabel();
        jp_crearExamen = new javax.swing.JPanel();
        jLabel129 = new javax.swing.JLabel();
        jt_tituloexamen = new javax.swing.JTextField();
        jLabel130 = new javax.swing.JLabel();
        jSeparator41 = new javax.swing.JSeparator();
        jLabel131 = new javax.swing.JLabel();
        jSeparator48 = new javax.swing.JSeparator();
        sp_minutosexamen = new javax.swing.JSpinner();
        jLabel132 = new javax.swing.JLabel();
        sp_horaexamenab = new javax.swing.JSpinner();
        jLabel133 = new javax.swing.JLabel();
        sp_minutoexamenab = new javax.swing.JSpinner();
        jSeparator49 = new javax.swing.JSeparator();
        jLabel134 = new javax.swing.JLabel();
        jSeparator50 = new javax.swing.JSeparator();
        jd_fechaexamen = new com.toedter.calendar.JDateChooser();
        jButton9 = new javax.swing.JButton();
        jScrollPane21 = new javax.swing.JScrollPane();
        lista_clasesmaestro = new javax.swing.JList<>();
        jLabel224 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jf_inicioalumno = new javax.swing.JFrame();
        jPanel5 = new javax.swing.JPanel();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        jp_menudespalumno = new javax.swing.JPanel();
        jl_barramaestros1 = new javax.swing.JLabel();
        jl_homemaestros1 = new javax.swing.JLabel();
        jl_resexamen = new javax.swing.JLabel();
        jl_vernotaalum = new javax.swing.JLabel();
        jl_cuadrodenotasalum = new javax.swing.JLabel();
        jl_creartareaalum = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        jl_usuario1 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        jl_correo1 = new javax.swing.JLabel();
        jLabel48 = new javax.swing.JLabel();
        jl_clave1 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        jL_fondomenudesp3 = new javax.swing.JLabel();
        panel_inicioalum = new javax.swing.JPanel();
        jLabel49 = new javax.swing.JLabel();
        jLabel50 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTextArea5 = new javax.swing.JTextArea();
        jScrollPane6 = new javax.swing.JScrollPane();
        jTextArea6 = new javax.swing.JTextArea();
        jf_tareas_alumno = new javax.swing.JPanel();
        jLabel174 = new javax.swing.JLabel();
        jSeparator57 = new javax.swing.JSeparator();
        jScrollPane41 = new javax.swing.JScrollPane();
        lista_clases_alum = new javax.swing.JList<>();
        jScrollPane42 = new javax.swing.JScrollPane();
        lista_tareas_alumno2 = new javax.swing.JList<>();
        jLabel175 = new javax.swing.JLabel();
        sba = new javax.swing.JLabel();
        jLabel206 = new javax.swing.JLabel();
        jButton26 = new javax.swing.JButton();
        entregartarea = new javax.swing.JButton();
        tarea_entregada = new javax.swing.JPanel();
        jLabel178 = new javax.swing.JLabel();
        jLabel207 = new javax.swing.JLabel();
        sba1 = new javax.swing.JLabel();
        jLabel208 = new javax.swing.JLabel();
        jLabel209 = new javax.swing.JLabel();
        Examenes_alum = new javax.swing.JPanel();
        jLabel159 = new javax.swing.JLabel();
        jScrollPane33 = new javax.swing.JScrollPane();
        lista_alum_clases = new javax.swing.JList<>();
        jScrollPane34 = new javax.swing.JScrollPane();
        lista_exa_clase = new javax.swing.JList<>();
        jButton16 = new javax.swing.JButton();
        jLabel160 = new javax.swing.JLabel();
        jLabel161 = new javax.swing.JLabel();
        jLabel162 = new javax.swing.JLabel();
        jp_Verresualu = new javax.swing.JPanel();
        jScrollPane35 = new javax.swing.JScrollPane();
        listaclasesalum = new javax.swing.JList<>();
        jScrollPane36 = new javax.swing.JScrollPane();
        listaexaalum = new javax.swing.JList<>();
        jScrollPane37 = new javax.swing.JScrollPane();
        tablaresualu = new javax.swing.JTable();
        jLabel165 = new javax.swing.JLabel();
        jLabel177 = new javax.swing.JLabel();
        jLabel225 = new javax.swing.JLabel();
        jLabel226 = new javax.swing.JLabel();
        jp_cuadroalu = new javax.swing.JPanel();
        jScrollPane38 = new javax.swing.JScrollPane();
        tabla = new javax.swing.JTable();
        jLabel166 = new javax.swing.JLabel();
        jScrollPane39 = new javax.swing.JScrollPane();
        lista2222222222 = new javax.swing.JList<>();
        jLabel176 = new javax.swing.JLabel();
        jLabel227 = new javax.swing.JLabel();
        jL_fondomenudesp1 = new javax.swing.JLabel();
        jLabel51 = new javax.swing.JLabel();
        jL_fondomenudesp = new javax.swing.JLabel();
        jd_preguntasex = new javax.swing.JDialog();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel139 = new javax.swing.JLabel();
        jLabel138 = new javax.swing.JLabel();
        jButton10 = new javax.swing.JButton();
        jScrollPane22 = new javax.swing.JScrollPane();
        ja_preguntavf = new javax.swing.JTextArea();
        jb_true = new javax.swing.JRadioButton();
        jb_false = new javax.swing.JRadioButton();
        jLabel152 = new javax.swing.JLabel();
        jLabel153 = new javax.swing.JLabel();
        puntuacionVF = new javax.swing.JSpinner();
        jLabel135 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel140 = new javax.swing.JLabel();
        jScrollPane23 = new javax.swing.JScrollPane();
        ja_pregunta2 = new javax.swing.JTextArea();
        jb_Agregarrespdispsm = new javax.swing.JButton();
        jLabel142 = new javax.swing.JLabel();
        jLabel144 = new javax.swing.JLabel();
        jLabel145 = new javax.swing.JLabel();
        tab_respdispsm = new javax.swing.JTextField();
        jButton12 = new javax.swing.JButton();
        puntuacionSM = new javax.swing.JSpinner();
        jLabel154 = new javax.swing.JLabel();
        jc_respsssss = new javax.swing.JComboBox<>();
        jLabel164 = new javax.swing.JLabel();
        jLabel136 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jLabel146 = new javax.swing.JLabel();
        jLabel147 = new javax.swing.JLabel();
        jScrollPane24 = new javax.swing.JScrollPane();
        ja_enu = new javax.swing.JTextArea();
        jButton14 = new javax.swing.JButton();
        jLabel148 = new javax.swing.JLabel();
        jLabel149 = new javax.swing.JLabel();
        tab2_respcoEnu = new javax.swing.JTextField();
        jButton15 = new javax.swing.JButton();
        puntuacionENU = new javax.swing.JSpinner();
        jLabel155 = new javax.swing.JLabel();
        jLabel137 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        jLabel151 = new javax.swing.JLabel();
        jLabel150 = new javax.swing.JLabel();
        trueorfalse = new javax.swing.ButtonGroup();
        JF_EXAMEN = new javax.swing.JFrame();
        jPanel6 = new javax.swing.JPanel();
        titulo = new javax.swing.JLabel();
        jScrollPane32 = new javax.swing.JScrollPane();
        jp_mostrarex = new javax.swing.JPanel();
        jl_tituloexamen = new javax.swing.JLabel();
        boton_entregarex = new javax.swing.JButton();
        jLabel163 = new javax.swing.JLabel();
        respcoSM = new javax.swing.ButtonGroup();
        jf_elegir_preguntas = new javax.swing.JFrame();
        jPanel9 = new javax.swing.JPanel();
        jLabel185 = new javax.swing.JLabel();
        jScrollPane46 = new javax.swing.JScrollPane();
        lista_preguntas = new javax.swing.JList<>();
        jButton20 = new javax.swing.JButton();
        jf_modvf = new javax.swing.JFrame();
        jPanel10 = new javax.swing.JPanel();
        jLabel187 = new javax.swing.JLabel();
        jLabel188 = new javax.swing.JLabel();
        jScrollPane47 = new javax.swing.JScrollPane();
        jta_newpreguntavfmod = new javax.swing.JTextArea();
        jLabel189 = new javax.swing.JLabel();
        jr_truemod = new javax.swing.JRadioButton();
        jr_falsemod = new javax.swing.JRadioButton();
        jButton21 = new javax.swing.JButton();
        jLabel190 = new javax.swing.JLabel();
        jSpinner1 = new javax.swing.JSpinner();
        jf_modsm = new javax.swing.JFrame();
        jPanel11 = new javax.swing.JPanel();
        jLabel192 = new javax.swing.JLabel();
        linea_respdisp = new javax.swing.JTextField();
        jLabel193 = new javax.swing.JLabel();
        jb_Agregarrespdispsm1 = new javax.swing.JButton();
        jScrollPane48 = new javax.swing.JScrollPane();
        jta2_newquestionsm = new javax.swing.JTextArea();
        jLabel194 = new javax.swing.JLabel();
        jLabel195 = new javax.swing.JLabel();
        linea_respco = new javax.swing.JComboBox<>();
        jLabel196 = new javax.swing.JLabel();
        jButton22 = new javax.swing.JButton();
        jLabel191 = new javax.swing.JLabel();
        jSpinner2 = new javax.swing.JSpinner();
        jf_modEnu = new javax.swing.JFrame();
        jPanel12 = new javax.swing.JPanel();
        jLabel197 = new javax.swing.JLabel();
        jLabel198 = new javax.swing.JLabel();
        jScrollPane49 = new javax.swing.JScrollPane();
        ja_modenu = new javax.swing.JTextArea();
        jLabel199 = new javax.swing.JLabel();
        jLabel200 = new javax.swing.JLabel();
        textf_respcomodenu = new javax.swing.JTextField();
        jButton23 = new javax.swing.JButton();
        jButton24 = new javax.swing.JButton();
        jLabel201 = new javax.swing.JLabel();
        jSpinner3 = new javax.swing.JSpinner();
        bg_vfmod = new javax.swing.ButtonGroup();
        jf_revisartarea = new javax.swing.JFrame();
        jPanel13 = new javax.swing.JPanel();
        jScrollPane51 = new javax.swing.JScrollPane();
        jl_tarea = new javax.swing.JList<>();
        jLabel202 = new javax.swing.JLabel();
        jScrollPane53 = new javax.swing.JScrollPane();
        arbol = new javax.swing.JTree();
        jLabel203 = new javax.swing.JLabel();
        jLabel204 = new javax.swing.JLabel();
        nota_tarea = new javax.swing.JSpinner();
        jButton25 = new javax.swing.JButton();
        jLabel228 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        tf_user = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        pf_clave = new javax.swing.JPasswordField();
        jb_iniciarsesion = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jButton13 = new javax.swing.JButton();
        jButton17 = new javax.swing.JButton();
        jl_fondo = new javax.swing.JLabel();

        jf_inicioregistro.setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        jf_inicioregistro.setTitle("Regsitro FCB UNITEC");
        jf_inicioregistro.setIconImage(getIconImage());
        jf_inicioregistro.setSize(new java.awt.Dimension(1960, 1050));
        jf_inicioregistro.getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jp_inicioregistro.setBackground(new java.awt.Color(193, 216, 252));
        jp_inicioregistro.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        esconder1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        esconder1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        esconder1.setText("Usted Administra Toda Esta Plataforma");
        jp_inicioregistro.add(esconder1, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 160, 460, 60));

        jScrollPane2.setBackground(new java.awt.Color(179, 205, 252));

        esconder2.setEditable(false);
        esconder2.setBackground(new java.awt.Color(142, 182, 252));
        esconder2.setColumns(20);
        esconder2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        esconder2.setRows(5);
        esconder2.setText("\t\n\tUsted es registro y no hay nadie que pueda hacer todo lo que usted hace, Aqui se podra crear lo que\t\t\n usted quiere ya que en este sistema encontramos maestros, alumos y tambien clases que cursaran los mismos alumnos por los maestros.\n\n   Aqui se podra ingresar, modificar y expulsar lo que viene ser los alumnos y los maestros. Tambien estara encargado de administrar las \nclases dadas por los maestros y las clases cursadas por los alumnos ya que debera matricularlos en el apartado de \"Administrar alumnos\".\n\n Usted al ser el usuario de registro tiene el privilegio de poder cerrar sesion y tambien cerrar el sistema completamente por si hay un fallo\n\t                  que arreglar o administrar con nuestros Ingenieros en Sistemas Computacionales.");
        esconder2.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jScrollPane2.setViewportView(esconder2);

        jp_inicioregistro.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 260, 960, 210));

        jScrollPane1.setBackground(new java.awt.Color(179, 205, 252));

        esconder3.setEditable(false);
        esconder3.setBackground(new java.awt.Color(142, 182, 252));
        esconder3.setColumns(20);
        esconder3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        esconder3.setRows(5);
        esconder3.setText("\t\t                  ¡¡MUCHAS GRACIAS POR ACEPTAR ESTE TRABAJO!!\n\n Confiamos en ti y dejamos la plataforma a tus manos para que no haya ni tan solo un error y que pueda funcionar perfectamente para\n    que nuestros alumnos puedan tener la mejor experiencia posible a la hora de utilizar nuestro programa con sus caracteristicas que \n se han estado programando por mas de 4 semanas y que de requisitos estaba el esforzarse demasiado y meterle mucho amor y animo.");
        esconder3.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jScrollPane1.setViewportView(esconder3);

        jp_inicioregistro.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 520, 920, 120));

        jLabel88.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel88.setText("UNITEC FCB © 2023 | Derechos reservados.");
        jp_inicioregistro.add(jLabel88, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 950, 350, 60));

        jf_inicioregistro.getContentPane().add(jp_inicioregistro, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 90, 1730, 880));

        Jp_asignarmaestroclase.setBackground(new java.awt.Color(193, 216, 252));
        Jp_asignarmaestroclase.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel125.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel125.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel125.setText("Asignando un Maestro a una Clase");
        Jp_asignarmaestroclase.add(jLabel125, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 30, 610, -1));

        jlista_maestroasig.setModel(new DefaultListModel());
        jlista_maestroasig.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jlista_maestroasigMouseClicked(evt);
            }
        });
        jScrollPane18.setViewportView(jlista_maestroasig);

        Jp_asignarmaestroclase.add(jScrollPane18, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 170, 220, 680));

        jLabel126.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel126.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel126.setText("Eliga el Maestro a Asignar");
        Jp_asignarmaestroclase.add(jLabel126, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 130, 240, 40));

        jtable_maestroenclase.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID de Clase", "Nombre", "Unidades Valorativas (UV)", "Hora"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane19.setViewportView(jtable_maestroenclase);

        Jp_asignarmaestroclase.add(jScrollPane19, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 170, 580, 680));

        jLabel127.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel127.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel127.setText("Clases que Enseña el Maestro");
        Jp_asignarmaestroclase.add(jLabel127, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 130, 250, 40));

        jlista_metermaestroclase.setModel(new DefaultListModel());
        jScrollPane20.setViewportView(jlista_metermaestroclase);

        Jp_asignarmaestroclase.add(jScrollPane20, new org.netbeans.lib.awtextra.AbsoluteConstraints(1020, 170, 220, 680));

        jLabel128.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel128.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel128.setText("Eliga la Clase");
        Jp_asignarmaestroclase.add(jLabel128, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 130, 240, 40));

        jButton8.setBackground(new java.awt.Color(204, 0, 0));
        jButton8.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jButton8.setText("Asignar Maestro");
        jButton8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton8MouseClicked(evt);
            }
        });
        Jp_asignarmaestroclase.add(jButton8, new org.netbeans.lib.awtextra.AbsoluteConstraints(1320, 490, 220, 60));

        jf_inicioregistro.getContentPane().add(Jp_asignarmaestroclase, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 90, 1580, 870));

        jp_asignaralumclase.setBackground(new java.awt.Color(193, 216, 252));
        jp_asignaralumclase.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jlista_clases.setModel(new DefaultListModel());
        jlista_clases.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jlista_clasesMouseClicked(evt);
            }
        });
        jScrollPane15.setViewportView(jlista_clases);

        jp_asignaralumclase.add(jScrollPane15, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 170, 220, 680));

        jLabel114.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel114.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel114.setText("Alumnos en esa clase");
        jp_asignaralumclase.add(jLabel114, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 130, 220, 40));

        jlista_alumnosag.setModel(new DefaultListModel());
        jScrollPane16.setViewportView(jlista_alumnosag);

        jp_asignaralumclase.add(jScrollPane16, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 170, 220, 680));

        jLabel121.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel121.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel121.setText("Eliga el Alumno a Asignar");
        jp_asignaralumclase.add(jLabel121, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 130, 240, 40));

        jtable_alumnosenclase.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Numero de Cuenta", "Nombre", "Carrera", "Username"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane17.setViewportView(jtable_alumnosenclase);

        jp_asignaralumclase.add(jScrollPane17, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 170, 580, 680));

        jLabel122.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel122.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel122.setText("Eliga la clase a asignar");
        jp_asignaralumclase.add(jLabel122, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 130, 220, 40));

        jLabel124.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel124.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel124.setText("Asignando un Alumno a una Clase");
        jp_asignaralumclase.add(jLabel124, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 30, 610, -1));

        jButton3.setBackground(new java.awt.Color(204, 0, 0));
        jButton3.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jButton3.setText("Asignar Clase");
        jButton3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton3MouseClicked(evt);
            }
        });
        jp_asignaralumclase.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1350, 470, 200, 60));

        jf_inicioregistro.getContentPane().add(jp_asignaralumclase, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 90, 1620, 870));

        jp_EliminarClase.setBackground(new java.awt.Color(193, 216, 252));
        jp_EliminarClase.setPreferredSize(new java.awt.Dimension(1230, 780));
        jp_EliminarClase.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel109.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel109.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel109.setText("Eliminar una Clase");
        jp_EliminarClase.add(jLabel109, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 50, 480, 40));

        jb_eliminarMaestro2.setBackground(new java.awt.Color(255, 0, 0));
        jb_eliminarMaestro2.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jb_eliminarMaestro2.setText("Eliminar Clase");
        jb_eliminarMaestro2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jb_eliminarMaestro2MouseClicked(evt);
            }
        });
        jp_EliminarClase.add(jb_eliminarMaestro2, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 680, 500, 80));

        jlista_eliminarClase.setModel(new DefaultListModel());
        jScrollPane12.setViewportView(jlista_eliminarClase);

        jp_EliminarClase.add(jScrollPane12, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 160, 330, 480));

        jLabel210.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel210.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel210.setText("Eliga la clase a eliminar");
        jp_EliminarClase.add(jLabel210, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 130, 330, 30));

        jf_inicioregistro.getContentPane().add(jp_EliminarClase, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 90, 1380, 870));

        jpanel_elimregistro.setBackground(new java.awt.Color(193, 216, 252));
        jpanel_elimregistro.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel111.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel111.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel111.setText("Eliminar un Usuario de Registro");
        jpanel_elimregistro.add(jLabel111, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 50, 550, 50));

        jlista_eliminarRegistro.setModel(new DefaultListModel());
        jScrollPane14.setViewportView(jlista_eliminarRegistro);

        jpanel_elimregistro.add(jScrollPane14, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 160, 330, 480));

        jb_eliminarRegistro.setBackground(new java.awt.Color(255, 0, 0));
        jb_eliminarRegistro.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jb_eliminarRegistro.setText("Eliminar Registro");
        jb_eliminarRegistro.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jb_eliminarRegistroMouseClicked(evt);
            }
        });
        jpanel_elimregistro.add(jb_eliminarRegistro, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 680, 500, 80));

        jLabel211.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel211.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel211.setText("Eliga el usuario a eliminar");
        jpanel_elimregistro.add(jLabel211, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 130, 330, 30));

        jf_inicioregistro.getContentPane().add(jpanel_elimregistro, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 90, 1380, 880));

        jp_EliminarAlumno.setBackground(new java.awt.Color(193, 216, 252));
        jp_EliminarAlumno.setPreferredSize(new java.awt.Dimension(1230, 780));
        jp_EliminarAlumno.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel108.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel108.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel108.setText("Eliminar a un Alumno");
        jp_EliminarAlumno.add(jLabel108, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 50, 480, 40));

        jb_eliminarMaestro1.setBackground(new java.awt.Color(255, 0, 0));
        jb_eliminarMaestro1.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jb_eliminarMaestro1.setText("Eliminar Alumno");
        jb_eliminarMaestro1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jb_eliminarMaestro1MouseClicked(evt);
            }
        });
        jp_EliminarAlumno.add(jb_eliminarMaestro1, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 680, 500, 80));

        jlista_eliminarAlumno.setModel(new DefaultListModel());
        jScrollPane11.setViewportView(jlista_eliminarAlumno);

        jp_EliminarAlumno.add(jScrollPane11, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 160, 330, 480));

        jLabel123.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel123.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel123.setText("Eliminar a un Alumno");
        jp_EliminarAlumno.add(jLabel123, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 50, 480, 40));

        jLabel212.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel212.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel212.setText("Eliga el alumno a eliminar");
        jp_EliminarAlumno.add(jLabel212, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 130, 330, 30));

        jf_inicioregistro.getContentPane().add(jp_EliminarAlumno, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 90, 1380, 870));

        jp_eliminarmaestro.setBackground(new java.awt.Color(193, 216, 252));
        jp_eliminarmaestro.setPreferredSize(new java.awt.Dimension(1230, 780));
        jp_eliminarmaestro.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel107.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel107.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel107.setText("Eliminar a un Maestro");
        jp_eliminarmaestro.add(jLabel107, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 50, 480, 40));

        jlista_eliminarmister.setModel(new DefaultListModel());
        jScrollPane10.setViewportView(jlista_eliminarmister);

        jp_eliminarmaestro.add(jScrollPane10, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 160, 330, 480));

        jb_eliminarMaestro.setBackground(new java.awt.Color(255, 0, 0));
        jb_eliminarMaestro.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jb_eliminarMaestro.setText("Eliminar Maestro");
        jb_eliminarMaestro.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jb_eliminarMaestroMouseClicked(evt);
            }
        });
        jp_eliminarmaestro.add(jb_eliminarMaestro, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 680, 500, 80));

        jLabel213.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel213.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel213.setText("Eliga el maestro a eliminar");
        jp_eliminarmaestro.add(jLabel213, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 130, 330, 30));

        jf_inicioregistro.getContentPane().add(jp_eliminarmaestro, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 90, 1380, 870));

        jp_modificarclase.setBackground(new java.awt.Color(193, 216, 252));
        jp_modificarclase.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        md1_UVNuevoClase.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jp_modificarclase.add(md1_UVNuevoClase, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 570, 100, 30));

        md1_TipoHoraNuevoClase.setBackground(new java.awt.Color(193, 216, 252));
        md1_TipoHoraNuevoClase.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Am", "Pm" }));
        md1_TipoHoraNuevoClase.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jp_modificarclase.add(md1_TipoHoraNuevoClase, new org.netbeans.lib.awtextra.AbsoluteConstraints(960, 410, 70, 30));

        md1_SemestreNuevoClase.setModel(new javax.swing.SpinnerNumberModel(1, 1, 2, 1));
        jp_modificarclase.add(md1_SemestreNuevoClase, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 490, 100, 30));

        md1_PeriodoNuevoClase.setModel(new javax.swing.SpinnerNumberModel(1, 1, 2, 1));
        jp_modificarclase.add(md1_PeriodoNuevoClase, new org.netbeans.lib.awtextra.AbsoluteConstraints(1090, 490, 100, 30));

        md1_IDNuevoClase.setBackground(new java.awt.Color(193, 216, 252));
        md1_IDNuevoClase.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        md1_IDNuevoClase.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("########"))));
        jp_modificarclase.add(md1_IDNuevoClase, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 250, 470, 30));

        jLabel98.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel98.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel98.setText("Nuevo Año:");
        jp_modificarclase.add(jLabel98, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 330, 140, 30));

        jb_modificarclase.setBackground(new java.awt.Color(255, 0, 0));
        jb_modificarclase.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jb_modificarclase.setText("Modificar Clase");
        jb_modificarclase.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jb_modificarclaseMouseClicked(evt);
            }
        });
        jp_modificarclase.add(jb_modificarclase, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 690, 500, 80));

        jSeparator34.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator34.setForeground(new java.awt.Color(0, 0, 0));
        jp_modificarclase.add(jSeparator34, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 600, 100, 10));

        jSeparator35.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator35.setForeground(new java.awt.Color(0, 0, 0));
        jp_modificarclase.add(jSeparator35, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 360, 140, 10));

        jLabel99.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel99.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel99.setText("Nuevo Periodo(1-2):");
        jp_modificarclase.add(jLabel99, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 490, 210, 30));

        md1_AnioNuevoClase.setBackground(new java.awt.Color(193, 216, 252));
        jp_modificarclase.add(md1_AnioNuevoClase, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 330, 140, 30));

        jLabel100.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel100.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel100.setText("Nuevas Unidades Valorativas:");
        jp_modificarclase.add(jLabel100, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 570, 270, 30));

        jSeparator36.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator36.setForeground(new java.awt.Color(0, 0, 0));
        jp_modificarclase.add(jSeparator36, new org.netbeans.lib.awtextra.AbsoluteConstraints(1090, 520, 100, 10));

        md1_MinutosNuevoClase.setModel(new javax.swing.SpinnerNumberModel(0, 0, 50, 10));
        jp_modificarclase.add(md1_MinutosNuevoClase, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 410, 70, 30));

        jLabel101.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel101.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel101.setText("Nuevo Semestre (1-2):");
        jp_modificarclase.add(jLabel101, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 490, 220, 30));

        jSeparator37.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator37.setForeground(new java.awt.Color(0, 0, 0));
        jp_modificarclase.add(jSeparator37, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 520, 100, 10));

        md1_HoraNuevoClase.setModel(new javax.swing.SpinnerNumberModel(1, 1, 12, 1));
        jp_modificarclase.add(md1_HoraNuevoClase, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 410, 70, 30));

        jLabel102.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel102.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel102.setText(":");
        jp_modificarclase.add(jLabel102, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 410, -1, 30));

        jSeparator38.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator38.setForeground(new java.awt.Color(0, 0, 0));
        jp_modificarclase.add(jSeparator38, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 440, 270, 10));

        jSeparator39.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator39.setForeground(new java.awt.Color(0, 0, 0));
        jp_modificarclase.add(jSeparator39, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 200, 470, 10));

        jLabel103.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel103.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel103.setText("Nuevo Nombre de la Clase:");
        jp_modificarclase.add(jLabel103, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 170, 250, 30));

        jLabel104.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel104.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel104.setText("Nuevo ID de la Clase:");
        jp_modificarclase.add(jLabel104, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 250, 200, 30));

        jSeparator40.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator40.setForeground(new java.awt.Color(0, 0, 0));
        jp_modificarclase.add(jSeparator40, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 280, 470, 10));

        jLabel105.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel105.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel105.setText("Nueva Hora de la Clase:");
        jp_modificarclase.add(jLabel105, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 410, 260, 30));

        md1_NombreNuevoClase.setBackground(new java.awt.Color(193, 216, 252));
        md1_NombreNuevoClase.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jp_modificarclase.add(md1_NombreNuevoClase, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 170, 470, 30));

        jLabel106.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel106.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel106.setText("Modificando Una Clase");
        jp_modificarclase.add(jLabel106, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 60, 520, 40));

        jlista_clasesmod.setModel(new DefaultListModel());
        jlista_clasesmod.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jlista_clasesmodMouseClicked(evt);
            }
        });
        jScrollPane9.setViewportView(jlista_clasesmod);

        jp_modificarclase.add(jScrollPane9, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 90, 310, 690));

        jLabel214.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel214.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel214.setText("Eliga la clase a modificar");
        jp_modificarclase.add(jLabel214, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 60, 310, 30));

        jf_inicioregistro.getContentPane().add(jp_modificarclase, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 90, 1380, 870));

        jpanel_modregistro.setBackground(new java.awt.Color(193, 216, 252));
        jpanel_modregistro.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jb_crearregistro1.setBackground(new java.awt.Color(255, 0, 0));
        jb_crearregistro1.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jb_crearregistro1.setText("Crear Usuario de Registro");
        jb_crearregistro1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jb_crearregistro1MouseClicked(evt);
            }
        });
        jpanel_modregistro.add(jb_crearregistro1, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 600, 500, 80));

        jSeparator44.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator44.setForeground(new java.awt.Color(0, 0, 0));
        jpanel_modregistro.add(jSeparator44, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 280, 470, 10));

        jt_contraregistromod.setBackground(new java.awt.Color(193, 216, 252));
        jt_contraregistromod.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jpanel_modregistro.add(jt_contraregistromod, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 480, 470, 30));

        jt_userregistromod.setBackground(new java.awt.Color(193, 216, 252));
        jt_userregistromod.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jpanel_modregistro.add(jt_userregistromod, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 360, 470, 30));

        jSeparator46.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator46.setForeground(new java.awt.Color(0, 0, 0));
        jpanel_modregistro.add(jSeparator46, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 390, 470, 10));

        jLabel113.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel113.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel113.setText("Nuevo Username del Usuario:");
        jpanel_modregistro.add(jLabel113, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 360, 260, 30));

        jLabel117.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel117.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel117.setText("Nuevo Nombre del Usuario:");
        jpanel_modregistro.add(jLabel117, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 250, 260, 30));

        jLabel119.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel119.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel119.setText("Nueva Contraseña del Usuario:");
        jpanel_modregistro.add(jLabel119, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 480, 280, 30));

        jLabel120.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel120.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel120.setText("Modificando un Usuario de Registro");
        jpanel_modregistro.add(jLabel120, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 120, 670, 50));

        jSeparator47.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator47.setForeground(new java.awt.Color(0, 0, 0));
        jpanel_modregistro.add(jSeparator47, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 510, 470, 10));

        jt_nombreregistromod.setBackground(new java.awt.Color(193, 216, 252));
        jt_nombreregistromod.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jpanel_modregistro.add(jt_nombreregistromod, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 250, 470, 30));

        jlista_ModificarRegistro.setModel(new DefaultListModel());
        jScrollPane13.setViewportView(jlista_ModificarRegistro);

        jpanel_modregistro.add(jScrollPane13, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 50, 270, 650));

        jLabel215.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel215.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel215.setText("Eliga el usuario a modificar");
        jpanel_modregistro.add(jLabel215, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 20, 270, 30));

        jf_inicioregistro.getContentPane().add(jpanel_modregistro, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 90, 1380, 870));

        jp_modalumno.setBackground(new java.awt.Color(193, 216, 252));
        jp_modalumno.setPreferredSize(new java.awt.Dimension(1920, 1080));
        jp_modalumno.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jSeparator28.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator28.setForeground(new java.awt.Color(0, 0, 0));
        jp_modalumno.add(jSeparator28, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 540, 470, 10));

        jButton7.setBackground(new java.awt.Color(255, 0, 0));
        jButton7.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jButton7.setText("Modificar Alumno");
        jButton7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton7MouseClicked(evt);
            }
        });
        jp_modalumno.add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 610, 500, 80));

        jLabel90.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel90.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel90.setText("Modificando un Alumno");
        jp_modalumno.add(jLabel90, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 100, 480, 40));

        md_NuevaCarreraAlumno.setBackground(new java.awt.Color(193, 216, 252));
        md_NuevaCarreraAlumno.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jp_modalumno.add(md_NuevaCarreraAlumno, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 450, 470, 30));

        jLabel91.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel91.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel91.setText("Nuevo Rol del Alumno:");
        jp_modalumno.add(jLabel91, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 510, 280, 30));

        jLabel92.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel92.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel92.setText("Nuevo Nombre del Alumno:");
        jp_modalumno.add(jLabel92, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 210, 250, 30));

        md_NuevoRolAlumno.setBackground(new java.awt.Color(193, 216, 252));
        md_NuevoRolAlumno.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        md_NuevoRolAlumno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                md_NuevoRolAlumnoActionPerformed(evt);
            }
        });
        jp_modalumno.add(md_NuevoRolAlumno, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 510, 470, 30));

        jLabel93.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel93.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel93.setText("Nuevo Carrera del Alumno:");
        jp_modalumno.add(jLabel93, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 450, 280, 30));

        jSeparator29.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator29.setForeground(new java.awt.Color(0, 0, 0));
        jp_modalumno.add(jSeparator29, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 360, 470, 10));

        md_NuevaContraAlumno.setBackground(new java.awt.Color(193, 216, 252));
        md_NuevaContraAlumno.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jp_modalumno.add(md_NuevaContraAlumno, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 330, 470, 30));

        jLabel94.setForeground(new java.awt.Color(102, 102, 102));
        jLabel94.setText("Numero de cuenta debe ser de 8 digitos");
        jp_modalumno.add(jLabel94, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 420, 470, -1));

        jSeparator30.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator30.setForeground(new java.awt.Color(0, 0, 0));
        jp_modalumno.add(jSeparator30, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 480, 470, 10));

        jSeparator31.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator31.setForeground(new java.awt.Color(0, 0, 0));
        jp_modalumno.add(jSeparator31, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 240, 470, 10));

        jLabel95.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel95.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel95.setText("Nuevo Numero de Cuenta del Alumno:");
        jp_modalumno.add(jLabel95, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 390, 340, 30));

        jSeparator32.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator32.setForeground(new java.awt.Color(0, 0, 0));
        jp_modalumno.add(jSeparator32, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 300, 470, 10));

        md_NuevoNumCuentaAlumno.setBackground(new java.awt.Color(193, 216, 252));
        md_NuevoNumCuentaAlumno.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        md_NuevoNumCuentaAlumno.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("########"))));
        jp_modalumno.add(md_NuevoNumCuentaAlumno, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 390, 470, 30));

        jLabel96.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel96.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel96.setText("Nuevo Username del Alumno:");
        jp_modalumno.add(jLabel96, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 270, 270, 30));

        jSeparator33.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator33.setForeground(new java.awt.Color(0, 0, 0));
        jp_modalumno.add(jSeparator33, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 420, 470, 10));

        jLabel97.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel97.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel97.setText("Nueva Contraseña del Alumno:");
        jp_modalumno.add(jLabel97, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 330, 270, 30));

        md_NuevoNombreAlumno.setBackground(new java.awt.Color(193, 216, 252));
        md_NuevoNombreAlumno.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jp_modalumno.add(md_NuevoNombreAlumno, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 210, 470, 30));

        md_NuevoUserAlumno.setBackground(new java.awt.Color(193, 216, 252));
        md_NuevoUserAlumno.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jp_modalumno.add(md_NuevoUserAlumno, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 270, 470, 30));

        jlista_modalumnos.setModel(new DefaultListModel());
        jScrollPane8.setViewportView(jlista_modalumnos);

        jp_modalumno.add(jScrollPane8, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 110, 240, 580));

        jLabel216.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel216.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel216.setText("Eliga el alumno a modificar");
        jp_modalumno.add(jLabel216, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 80, 270, 30));

        jf_inicioregistro.getContentPane().add(jp_modalumno, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 90, 1380, 750));

        jp_modificarmaestros.setBackground(new java.awt.Color(193, 216, 252));
        jp_modificarmaestros.setPreferredSize(new java.awt.Dimension(1920, 1080));
        jp_modificarmaestros.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jt_modificarnombremaestro.setBackground(new java.awt.Color(193, 216, 252));
        jt_modificarnombremaestro.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jp_modificarmaestros.add(jt_modificarnombremaestro, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 160, 470, 30));

        jLabel79.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel79.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel79.setText("Nuevo Sueldo del Maestro:");
        jp_modificarmaestros.add(jLabel79, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 520, 240, 30));

        jSeparator21.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator21.setForeground(new java.awt.Color(0, 0, 0));
        jp_modificarmaestros.add(jSeparator21, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 550, 470, 10));

        jLabel80.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel80.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel80.setText("Nuevo Rol del Maestro:");
        jp_modificarmaestros.add(jLabel80, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 460, 210, 30));

        jLabel81.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel81.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel81.setText("Modificando al Maestro");
        jp_modificarmaestros.add(jLabel81, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 50, 480, 40));

        jt_modificarusermaestro.setBackground(new java.awt.Color(193, 216, 252));
        jt_modificarusermaestro.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jp_modificarmaestros.add(jt_modificarusermaestro, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 220, 460, 30));

        jSeparator22.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator22.setForeground(new java.awt.Color(0, 0, 0));
        jp_modificarmaestros.add(jSeparator22, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 490, 470, 10));

        jSeparator23.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator23.setForeground(new java.awt.Color(0, 0, 0));
        jp_modificarmaestros.add(jSeparator23, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 370, 470, 10));

        JB_MODIFICARMAESTRO.setBackground(new java.awt.Color(255, 0, 0));
        JB_MODIFICARMAESTRO.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        JB_MODIFICARMAESTRO.setText("Modificar al Maestro");
        JB_MODIFICARMAESTRO.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                JB_MODIFICARMAESTROMouseClicked(evt);
            }
        });
        jp_modificarmaestros.add(JB_MODIFICARMAESTRO, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 620, 500, 80));

        jSeparator24.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator24.setForeground(new java.awt.Color(0, 0, 0));
        jp_modificarmaestros.add(jSeparator24, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 190, 470, 10));

        jSeparator25.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator25.setForeground(new java.awt.Color(0, 0, 0));
        jp_modificarmaestros.add(jSeparator25, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 310, 470, 10));

        jLabel82.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel82.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel82.setText("Nueva Profesion del Maestro:");
        jp_modificarmaestros.add(jLabel82, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 400, 260, 30));

        jLabel83.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel83.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel83.setText("Nueva Contraseña del Maestro:");
        jp_modificarmaestros.add(jLabel83, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 280, 270, 30));

        jSeparator26.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator26.setForeground(new java.awt.Color(0, 0, 0));
        jp_modificarmaestros.add(jSeparator26, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 250, 470, 10));

        jLabel84.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel84.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel84.setText("Nuevo ID del Maestro:");
        jp_modificarmaestros.add(jLabel84, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 340, 200, 30));

        jf_modificaridmaestro.setBackground(new java.awt.Color(193, 216, 252));
        jf_modificaridmaestro.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jf_modificaridmaestro.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("########"))));
        jp_modificarmaestros.add(jf_modificaridmaestro, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 340, 460, 30));

        jt_ModificarProfesionMaestro.setBackground(new java.awt.Color(193, 216, 252));
        jt_ModificarProfesionMaestro.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jp_modificarmaestros.add(jt_ModificarProfesionMaestro, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 400, 460, 30));

        jt_ModificarRolMaestro.setBackground(new java.awt.Color(193, 216, 252));
        jt_ModificarRolMaestro.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jp_modificarmaestros.add(jt_ModificarRolMaestro, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 460, 460, 30));

        jf_ModificarSueldoMaestro.setBackground(new java.awt.Color(193, 216, 252));
        jf_ModificarSueldoMaestro.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jf_ModificarSueldoMaestro.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#0"))));
        jp_modificarmaestros.add(jf_ModificarSueldoMaestro, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 520, 460, 30));

        jLabel85.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel85.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel85.setText("Nuevo Username del Maestro:");
        jp_modificarmaestros.add(jLabel85, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 220, 270, 30));

        jLabel86.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel86.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel86.setText("Nuevo Nombre del Maestro:");
        jp_modificarmaestros.add(jLabel86, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 160, 250, 30));

        jt_modificarcontramaestro.setBackground(new java.awt.Color(193, 216, 252));
        jt_modificarcontramaestro.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jp_modificarmaestros.add(jt_modificarcontramaestro, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 280, 460, 30));

        jSeparator27.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator27.setForeground(new java.awt.Color(0, 0, 0));
        jp_modificarmaestros.add(jSeparator27, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 430, 470, 10));

        jLabel87.setForeground(new java.awt.Color(102, 102, 102));
        jLabel87.setText("ID debe ser de 8 caracteres");
        jp_modificarmaestros.add(jLabel87, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 370, 470, -1));

        jl_maestrosamodificar.setModel(new DefaultListModel());
        jScrollPane7.setViewportView(jl_maestrosamodificar);

        jp_modificarmaestros.add(jScrollPane7, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 50, 270, 650));

        jLabel69.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel69.setText("UNITEC FCB © 2023 | Derechos reservados.");
        jp_modificarmaestros.add(jLabel69, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 860, 350, 60));

        jLabel217.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel217.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel217.setText("Eliga el maestro a modificar");
        jp_modificarmaestros.add(jLabel217, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 20, 270, 30));

        jf_inicioregistro.getContentPane().add(jp_modificarmaestros, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 90, -1, -1));

        jp_crearregistro.setBackground(new java.awt.Color(193, 216, 252));
        jp_crearregistro.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jb_crearregistro.setBackground(new java.awt.Color(255, 0, 0));
        jb_crearregistro.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jb_crearregistro.setText("Crear Usuario de Registro");
        jb_crearregistro.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jb_crearregistroMouseClicked(evt);
            }
        });
        jp_crearregistro.add(jb_crearregistro, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 530, 500, 80));

        jSeparator42.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator42.setForeground(new java.awt.Color(0, 0, 0));
        jp_crearregistro.add(jSeparator42, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 210, 470, 10));

        jt_contraregistronuevo.setBackground(new java.awt.Color(193, 216, 252));
        jt_contraregistronuevo.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jp_crearregistro.add(jt_contraregistronuevo, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 410, 470, 30));

        jt_userregistronuevo.setBackground(new java.awt.Color(193, 216, 252));
        jt_userregistronuevo.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jp_crearregistro.add(jt_userregistronuevo, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 290, 470, 30));

        jSeparator43.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator43.setForeground(new java.awt.Color(0, 0, 0));
        jp_crearregistro.add(jSeparator43, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 320, 470, 10));

        jLabel112.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel112.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel112.setText("Username del Usuario:");
        jp_crearregistro.add(jLabel112, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 290, 210, 30));

        jLabel115.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel115.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel115.setText("Nombre del Usuario:");
        jp_crearregistro.add(jLabel115, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 180, 190, 30));

        jLabel116.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel116.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel116.setText("Contraseña del Usuario:");
        jp_crearregistro.add(jLabel116, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 410, 210, 30));

        jLabel118.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel118.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel118.setText("Creando un Nuevo Usuario de Registro");
        jp_crearregistro.add(jLabel118, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 50, 670, 50));

        jSeparator45.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator45.setForeground(new java.awt.Color(0, 0, 0));
        jp_crearregistro.add(jSeparator45, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 440, 470, 10));

        jt_nombreregistronuevo.setBackground(new java.awt.Color(193, 216, 252));
        jt_nombreregistronuevo.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jp_crearregistro.add(jt_nombreregistronuevo, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 180, 470, 30));

        jf_inicioregistro.getContentPane().add(jp_crearregistro, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 90, 1380, 870));

        jp_crearmaestro.setBackground(new java.awt.Color(193, 216, 252));
        jp_crearmaestro.setPreferredSize(new java.awt.Dimension(1920, 1080));
        jp_crearmaestro.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel52.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel52.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel52.setText("Creando Un Nuevo Maestro");
        jp_crearmaestro.add(jLabel52, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 50, 480, 40));

        jLabel53.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel53.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel53.setText("Nombre del Maestro:");
        jp_crearmaestro.add(jLabel53, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 160, 190, 30));

        jt_nombremaestronuevo.setBackground(new java.awt.Color(193, 216, 252));
        jt_nombremaestronuevo.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jp_crearmaestro.add(jt_nombremaestronuevo, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 160, 470, 30));

        jLabel54.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel54.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel54.setText("Username del Maestro:");
        jp_crearmaestro.add(jLabel54, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 220, 210, 30));

        jt_usermaestronuevo.setBackground(new java.awt.Color(193, 216, 252));
        jt_usermaestronuevo.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jp_crearmaestro.add(jt_usermaestronuevo, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 220, 460, 30));

        jLabel55.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel55.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel55.setText("Contraseña del Maestro:");
        jp_crearmaestro.add(jLabel55, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 280, 210, 30));

        jt_contramaestronuevo.setBackground(new java.awt.Color(193, 216, 252));
        jt_contramaestronuevo.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jp_crearmaestro.add(jt_contramaestronuevo, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 280, 460, 30));

        jLabel56.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel56.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel56.setText("ID del Maestro:");
        jp_crearmaestro.add(jLabel56, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 340, 190, 30));

        jf_Sueldomaestronuevo.setBackground(new java.awt.Color(193, 216, 252));
        jf_Sueldomaestronuevo.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jf_Sueldomaestronuevo.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#0"))));
        jp_crearmaestro.add(jf_Sueldomaestronuevo, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 520, 460, 30));

        jLabel57.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel57.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel57.setText("Profesion del Maestro:");
        jp_crearmaestro.add(jLabel57, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 400, 210, 30));

        jt_profesionmaestronuevo.setBackground(new java.awt.Color(193, 216, 252));
        jt_profesionmaestronuevo.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jp_crearmaestro.add(jt_profesionmaestronuevo, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 400, 460, 30));

        jLabel58.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel58.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel58.setText("Rol del Maestro:");
        jp_crearmaestro.add(jLabel58, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 460, 190, 30));

        JT_Rolmaestronuevo.setBackground(new java.awt.Color(193, 216, 252));
        JT_Rolmaestronuevo.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jp_crearmaestro.add(JT_Rolmaestronuevo, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 460, 460, 30));

        jLabel59.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel59.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel59.setText("Sueldo del Maestro:");
        jp_crearmaestro.add(jLabel59, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 520, 190, 30));

        jf_idmaestronuevo.setBackground(new java.awt.Color(193, 216, 252));
        jf_idmaestronuevo.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jf_idmaestronuevo.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("########"))));
        jp_crearmaestro.add(jf_idmaestronuevo, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 340, 460, 30));

        jSeparator1.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator1.setForeground(new java.awt.Color(0, 0, 0));
        jp_crearmaestro.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 550, 470, 10));

        jSeparator2.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator2.setForeground(new java.awt.Color(0, 0, 0));
        jp_crearmaestro.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 190, 470, 10));

        jSeparator3.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator3.setForeground(new java.awt.Color(0, 0, 0));
        jp_crearmaestro.add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 250, 470, 10));

        jSeparator4.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator4.setForeground(new java.awt.Color(0, 0, 0));
        jp_crearmaestro.add(jSeparator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 310, 470, 10));

        jSeparator5.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator5.setForeground(new java.awt.Color(0, 0, 0));
        jp_crearmaestro.add(jSeparator5, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 370, 470, 10));

        jSeparator6.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator6.setForeground(new java.awt.Color(0, 0, 0));
        jp_crearmaestro.add(jSeparator6, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 430, 470, 10));

        jSeparator7.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator7.setForeground(new java.awt.Color(0, 0, 0));
        jp_crearmaestro.add(jSeparator7, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 490, 470, 10));

        jButton1.setBackground(new java.awt.Color(255, 0, 0));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jButton1.setText("Crear Maestro");
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });
        jp_crearmaestro.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 620, 500, 80));

        jLabel60.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel60.setText("UNITEC FCB © 2023 | Derechos reservados.");
        jp_crearmaestro.add(jLabel60, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 860, 350, 60));

        jLabel19.setForeground(new java.awt.Color(102, 102, 102));
        jLabel19.setText("ID debe ser de 8 caracteres");
        jp_crearmaestro.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 370, 470, -1));

        jf_inicioregistro.getContentPane().add(jp_crearmaestro, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 90, -1, 1070));

        jp_crearAlumno.setBackground(new java.awt.Color(193, 216, 252));
        jp_crearAlumno.setPreferredSize(new java.awt.Dimension(1920, 1080));
        jp_crearAlumno.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel62.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel62.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel62.setText("Creando Un Nuevo Alumno");
        jp_crearAlumno.add(jLabel62, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 50, 480, 40));

        jLabel61.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel61.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel61.setText("Nombre del Alumno:");
        jp_crearAlumno.add(jLabel61, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 160, 190, 30));

        jt_nombrealumnonuevo.setBackground(new java.awt.Color(193, 216, 252));
        jt_nombrealumnonuevo.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jp_crearAlumno.add(jt_nombrealumnonuevo, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 160, 470, 30));

        jLabel63.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel63.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel63.setText("Username del Alumno:");
        jp_crearAlumno.add(jLabel63, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 220, 210, 30));

        jt_useralumnonuevo.setBackground(new java.awt.Color(193, 216, 252));
        jt_useralumnonuevo.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jp_crearAlumno.add(jt_useralumnonuevo, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 220, 470, 30));

        jLabel64.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel64.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel64.setText("Rol del Alumno:");
        jp_crearAlumno.add(jLabel64, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 460, 280, 30));

        jt_contraalumnonuevo.setBackground(new java.awt.Color(193, 216, 252));
        jt_contraalumnonuevo.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jp_crearAlumno.add(jt_contraalumnonuevo, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 280, 470, 30));

        jSeparator8.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator8.setForeground(new java.awt.Color(0, 0, 0));
        jp_crearAlumno.add(jSeparator8, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 190, 470, 10));

        jSeparator9.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator9.setForeground(new java.awt.Color(0, 0, 0));
        jp_crearAlumno.add(jSeparator9, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 430, 470, 10));

        jSeparator11.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator11.setForeground(new java.awt.Color(0, 0, 0));
        jp_crearAlumno.add(jSeparator11, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 250, 470, 10));

        jSeparator12.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator12.setForeground(new java.awt.Color(0, 0, 0));
        jp_crearAlumno.add(jSeparator12, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 490, 470, 10));

        jSeparator13.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator13.setForeground(new java.awt.Color(0, 0, 0));
        jp_crearAlumno.add(jSeparator13, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 310, 470, 10));

        jSeparator14.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator14.setForeground(new java.awt.Color(0, 0, 0));
        jp_crearAlumno.add(jSeparator14, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 370, 470, 10));

        jLabel65.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel65.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel65.setText("Contraseña del Alumno:");
        jp_crearAlumno.add(jLabel65, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 280, 210, 30));

        jLabel66.setForeground(new java.awt.Color(102, 102, 102));
        jLabel66.setText("Numero de cuenta debe ser de 8 digitos");
        jp_crearAlumno.add(jLabel66, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 370, 470, -1));

        jLabel67.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel67.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel67.setText("Numero de Cuenta del Alumno:");
        jp_crearAlumno.add(jLabel67, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 340, 280, 30));

        jLabel68.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel68.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel68.setText("Carrera del Alumno:");
        jp_crearAlumno.add(jLabel68, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 400, 280, 30));

        jf_numcuentanuevoalumno.setBackground(new java.awt.Color(193, 216, 252));
        jf_numcuentanuevoalumno.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jf_numcuentanuevoalumno.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("########"))));
        jp_crearAlumno.add(jf_numcuentanuevoalumno, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 340, 470, 30));

        jt_rolalumnonuevo.setBackground(new java.awt.Color(193, 216, 252));
        jt_rolalumnonuevo.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jp_crearAlumno.add(jt_rolalumnonuevo, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 460, 470, 30));

        jt_carreranuevoalumno.setBackground(new java.awt.Color(193, 216, 252));
        jt_carreranuevoalumno.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jp_crearAlumno.add(jt_carreranuevoalumno, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 400, 470, 30));

        jButton6.setBackground(new java.awt.Color(255, 0, 0));
        jButton6.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jButton6.setText("Crear Alumno");
        jButton6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton6MouseClicked(evt);
            }
        });
        jp_crearAlumno.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 530, 500, 80));

        jLabel89.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel89.setText("UNITEC FCB © 2023 | Derechos reservados.");
        jp_crearAlumno.add(jLabel89, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 860, 350, 60));

        jf_inicioregistro.getContentPane().add(jp_crearAlumno, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 90, -1, -1));

        jp_crearclase.setBackground(new java.awt.Color(193, 216, 252));
        jp_crearclase.setPreferredSize(new java.awt.Dimension(1920, 1000));
        jp_crearclase.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel70.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel70.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel70.setText("Creando Una Nueva Clase");
        jp_crearclase.add(jLabel70, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 50, 480, 40));

        jt_nombreclasenueva.setBackground(new java.awt.Color(193, 216, 252));
        jt_nombreclasenueva.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jp_crearclase.add(jt_nombreclasenueva, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 160, 470, 30));

        jLabel71.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel71.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel71.setText("Hora de la Clase:");
        jp_crearclase.add(jLabel71, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 400, 160, 30));

        jSeparator15.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator15.setForeground(new java.awt.Color(0, 0, 0));
        jp_crearclase.add(jSeparator15, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 270, 470, 10));

        jLabel72.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel72.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel72.setText("ID de la Clase:");
        jp_crearclase.add(jLabel72, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 240, 210, 30));

        jLabel73.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel73.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel73.setText("Nombre de la Clase:");
        jp_crearclase.add(jLabel73, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 160, 190, 30));

        jSeparator10.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator10.setForeground(new java.awt.Color(0, 0, 0));
        jp_crearclase.add(jSeparator10, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 190, 470, 10));

        jSeparator16.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator16.setForeground(new java.awt.Color(0, 0, 0));
        jp_crearclase.add(jSeparator16, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 430, 270, 10));

        jLabel74.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel74.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel74.setText(":");
        jp_crearclase.add(jLabel74, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 400, -1, 30));

        jSeparator17.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator17.setForeground(new java.awt.Color(0, 0, 0));
        jp_crearclase.add(jSeparator17, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 510, 100, 10));

        js_horaclasenueva.setModel(new javax.swing.SpinnerNumberModel(1, 1, 12, 1));
        jp_crearclase.add(js_horaclasenueva, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 400, 70, 30));

        jLabel75.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel75.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel75.setText("Semestre (1-2):");
        jp_crearclase.add(jLabel75, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 480, 150, 30));

        js_minutoclasenueva.setModel(new javax.swing.SpinnerNumberModel(0, 0, 50, 10));
        jp_crearclase.add(js_minutoclasenueva, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 400, 70, 30));

        jc_tipohoraclasenueva.setBackground(new java.awt.Color(193, 216, 252));
        jc_tipohoraclasenueva.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Am", "Pm" }));
        jc_tipohoraclasenueva.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jp_crearclase.add(jc_tipohoraclasenueva, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 400, 70, 30));

        jSeparator18.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator18.setForeground(new java.awt.Color(0, 0, 0));
        jp_crearclase.add(jSeparator18, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 350, 140, 10));

        js_semestreclasenueva.setModel(new javax.swing.SpinnerNumberModel(1, 1, 2, 1));
        jp_crearclase.add(js_semestreclasenueva, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 480, 100, 30));

        jLabel77.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel77.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel77.setText("Periodo(Trimestre(1-2)):");
        jp_crearclase.add(jLabel77, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 480, 210, 30));

        jSeparator20.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator20.setForeground(new java.awt.Color(0, 0, 0));
        jp_crearclase.add(jSeparator20, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 510, 100, 10));

        js_Periodoclasenueva.setModel(new javax.swing.SpinnerNumberModel(1, 1, 2, 1));
        jp_crearclase.add(js_Periodoclasenueva, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 480, 100, 30));

        jLabel78.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel78.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel78.setText("Año:");
        jp_crearclase.add(jLabel78, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 320, 50, 30));

        jLabel76.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel76.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel76.setText("Unidades Valorativas:");
        jp_crearclase.add(jLabel76, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 560, 210, 30));

        jSeparator19.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator19.setForeground(new java.awt.Color(0, 0, 0));
        jp_crearclase.add(jSeparator19, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 590, 100, 10));

        js_uvclasenueva.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jp_crearclase.add(js_uvclasenueva, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 560, 100, 30));

        jb_crearclasenueva.setBackground(new java.awt.Color(255, 0, 0));
        jb_crearclasenueva.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jb_crearclasenueva.setText("Crear Clase");
        jb_crearclasenueva.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jb_crearclasenuevaMouseClicked(evt);
            }
        });
        jp_crearclase.add(jb_crearclasenueva, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 680, 500, 80));

        jf_idclasenueva.setBackground(new java.awt.Color(193, 216, 252));
        jf_idclasenueva.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jf_idclasenueva.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("########"))));
        jp_crearclase.add(jf_idclasenueva, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 240, 470, 30));

        anioclasenueva.setBackground(new java.awt.Color(193, 216, 252));
        jp_crearclase.add(anioclasenueva, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 320, 140, 30));

        jf_inicioregistro.getContentPane().add(jp_crearclase, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 90, 1690, 870));

        jp_todoregistro.setBackground(new java.awt.Color(193, 216, 252));
        jp_todoregistro.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel110.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel110.setForeground(new java.awt.Color(0, 204, 204));
        jLabel110.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel110.setText("Administrar Regristro");
        jLabel110.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jp_todoregistro.add(jLabel110, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 320, 190, 20));

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel13.setText("Opciones de");
        jp_todoregistro.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 60, 110, 20));

        jLabel21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Bayern superchiquito.png"))); // NOI18N
        jp_todoregistro.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(1280, 10, 50, 60));

        jLabel20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Bayern superchiquito.png"))); // NOI18N
        jp_todoregistro.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 10, 50, 60));

        ch_registro_registro.setBackground(new java.awt.Color(193, 216, 252));
        ch_registro_registro.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ch_registro_registro.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        ch_registro_registro.setForeground(new java.awt.Color(0, 0, 0));
        ch_registro_registro.setName(""); // NOI18N
        ch_registro_registro.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                ch_registro_registroItemStateChanged(evt);
            }
        });
        jp_todoregistro.add(ch_registro_registro, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 350, 150, -1));

        jLabel18.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 255, 255));
        jLabel18.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel18.setText("BIEVENIDO A REGISTRO");
        jp_todoregistro.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(563, 6, 870, 70));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/fondo rojo mejor.png"))); // NOI18N
        jp_todoregistro.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 2000, 85));

        ch_clases_registro.setBackground(new java.awt.Color(193, 216, 252));
        ch_clases_registro.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ch_clases_registro.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        ch_clases_registro.setForeground(new java.awt.Color(0, 0, 0));
        ch_clases_registro.setName(""); // NOI18N
        ch_clases_registro.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                ch_clases_registroItemStateChanged(evt);
            }
        });
        jp_todoregistro.add(ch_clases_registro, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 290, 150, -1));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 204, 204));
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/usuario.png"))); // NOI18N
        jp_todoregistro.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 370, 140, 320));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 204, 204));
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("Administrar Maestros");
        jp_todoregistro.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, 190, 20));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 204, 204));
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setText("Administrar Clases");
        jp_todoregistro.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 260, 190, 20));

        jl_claveregistro.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jl_claveregistro.setForeground(new java.awt.Color(255, 255, 255));
        jl_claveregistro.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jp_todoregistro.add(jl_claveregistro, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 910, 190, 20));

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 17)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel12.setText("Contraseña");
        jp_todoregistro.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 880, 110, 20));

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 17)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel14.setText("Usuario");
        jp_todoregistro.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 730, 110, 20));

        jl_usuarioregistro.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jl_usuarioregistro.setForeground(new java.awt.Color(255, 255, 255));
        jl_usuarioregistro.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jp_todoregistro.add(jl_usuarioregistro, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 760, 180, 20));

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 17)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel16.setText("Correo");
        jp_todoregistro.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 800, 100, 20));

        jl_correoregistro.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jl_correoregistro.setForeground(new java.awt.Color(255, 255, 255));
        jl_correoregistro.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jp_todoregistro.add(jl_correoregistro, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 830, 190, 20));

        jb_cerrarsesionregistro.setBackground(new java.awt.Color(193, 216, 252));
        jb_cerrarsesionregistro.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jb_cerrarsesionregistro.setText("Cerrar Sesion");
        jb_cerrarsesionregistro.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jb_cerrarsesionregistroMouseClicked(evt);
            }
        });
        jb_cerrarsesionregistro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jb_cerrarsesionregistroActionPerformed(evt);
            }
        });
        jp_todoregistro.add(jb_cerrarsesionregistro, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 950, 130, 50));

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel15.setText("registro");
        jp_todoregistro.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 80, 110, 30));

        jLabel17.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel17.setText("Informacion");
        jp_todoregistro.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 690, 110, 20));

        ch_maestros_registro.setBackground(new java.awt.Color(193, 216, 252));
        ch_maestros_registro.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ch_maestros_registro.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        ch_maestros_registro.setName(""); // NOI18N
        ch_maestros_registro.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                ch_maestros_registroItemStateChanged(evt);
            }
        });
        jp_todoregistro.add(ch_maestros_registro, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 150, 150, -1));

        ch_alumnos_registro.setBackground(new java.awt.Color(193, 216, 252));
        ch_alumnos_registro.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ch_alumnos_registro.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        ch_alumnos_registro.setForeground(new java.awt.Color(0, 0, 0));
        ch_alumnos_registro.setName(""); // NOI18N
        ch_alumnos_registro.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                ch_alumnos_registroItemStateChanged(evt);
            }
        });
        jp_todoregistro.add(ch_alumnos_registro, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 220, 150, -1));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 204, 204));
        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel11.setText("Administrar Alumnos");
        jp_todoregistro.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 190, 190, 20));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/fondo rojo mejor.png"))); // NOI18N
        jp_todoregistro.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 230, 1050));

        jLabel22.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel22.setText("UNITEC FCB © 2023 | Derechos reservados.");
        jp_todoregistro.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 950, 350, 60));

        jf_inicioregistro.getContentPane().add(jp_todoregistro, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1960, 1050));

        jf_iniciomaestro.setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        jf_iniciomaestro.setTitle("FCB UNITEC");
        jf_iniciomaestro.setIconImage(getIconImage());
        jf_iniciomaestro.setSize(new java.awt.Dimension(1920, 1080));
        jf_iniciomaestro.getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel28.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Bayern superchiquito.png"))); // NOI18N
        jf_iniciomaestro.getContentPane().add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(1280, 10, 50, 60));

        jLabel29.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Bayern superchiquito.png"))); // NOI18N
        jf_iniciomaestro.getContentPane().add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 10, 50, 60));

        jLabel30.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(255, 255, 255));
        jLabel30.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel30.setText("BIEVENIDO MAESTRO");
        jf_iniciomaestro.getContentPane().add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 10, 870, 70));

        jLabel31.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/fondo rojo mejor.png"))); // NOI18N
        jf_iniciomaestro.getContentPane().add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 2000, 90));

        jp_menudesp.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jp_menudesp.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jl_barramaestros.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jl_barramaestros.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/tres+lineas.png"))); // NOI18N
        jl_barramaestros.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 15));
        jl_barramaestros.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jl_barramaestros.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jl_barramaestrosMouseClicked(evt);
            }
        });
        jp_menudesp.add(jl_barramaestros, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 100, 50, 30));

        jl_homemaestros.setFont(new java.awt.Font("SansSerif", 1, 16)); // NOI18N
        jl_homemaestros.setForeground(new java.awt.Color(255, 255, 255));
        jl_homemaestros.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jl_homemaestros.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/home.png"))); // NOI18N
        jl_homemaestros.setText("Home");
        jl_homemaestros.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 15));
        jl_homemaestros.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jl_homemaestros.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jl_homemaestros.setIconTextGap(15);
        jl_homemaestros.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jl_homemaestrosMouseClicked(evt);
            }
        });
        jp_menudesp.add(jl_homemaestros, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, 210, 30));

        jl_crearexamen.setFont(new java.awt.Font("SansSerif", 1, 16)); // NOI18N
        jl_crearexamen.setForeground(new java.awt.Color(255, 255, 255));
        jl_crearexamen.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jl_crearexamen.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/nuevoexamen (1).png"))); // NOI18N
        jl_crearexamen.setText("Nuevo Examen");
        jl_crearexamen.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 15));
        jl_crearexamen.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jl_crearexamen.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jl_crearexamen.setIconTextGap(15);
        jl_crearexamen.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jl_crearexamenMouseClicked(evt);
            }
        });
        jp_menudesp.add(jl_crearexamen, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, 210, 30));

        jl_modificarexamen.setFont(new java.awt.Font("SansSerif", 1, 16)); // NOI18N
        jl_modificarexamen.setForeground(new java.awt.Color(255, 255, 255));
        jl_modificarexamen.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jl_modificarexamen.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/modificarexamen+(1).png"))); // NOI18N
        jl_modificarexamen.setText("Modificar Examen");
        jl_modificarexamen.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 15));
        jl_modificarexamen.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jl_modificarexamen.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jl_modificarexamen.setIconTextGap(15);
        jl_modificarexamen.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jl_modificarexamenMouseClicked(evt);
            }
        });
        jp_menudesp.add(jl_modificarexamen, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 190, 210, 30));

        jl_eliminarexamen.setFont(new java.awt.Font("SansSerif", 1, 16)); // NOI18N
        jl_eliminarexamen.setForeground(new java.awt.Color(255, 255, 255));
        jl_eliminarexamen.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jl_eliminarexamen.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/borrarexamen.png"))); // NOI18N
        jl_eliminarexamen.setText("Eliminar Examen ");
        jl_eliminarexamen.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 12));
        jl_eliminarexamen.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jl_eliminarexamen.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jl_eliminarexamen.setIconTextGap(15);
        jl_eliminarexamen.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jl_eliminarexamenMouseClicked(evt);
            }
        });
        jp_menudesp.add(jl_eliminarexamen, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, 210, 30));

        jl_vernota.setFont(new java.awt.Font("SansSerif", 1, 16)); // NOI18N
        jl_vernota.setForeground(new java.awt.Color(255, 255, 255));
        jl_vernota.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jl_vernota.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/ojos_3.png"))); // NOI18N
        jl_vernota.setText("Ver Resultados");
        jl_vernota.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 15));
        jl_vernota.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jl_vernota.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jl_vernota.setIconTextGap(15);
        jl_vernota.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jl_vernotaMouseClicked(evt);
            }
        });
        jp_menudesp.add(jl_vernota, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 250, 210, 30));

        jl_cuadrodenotas.setFont(new java.awt.Font("SansSerif", 1, 16)); // NOI18N
        jl_cuadrodenotas.setForeground(new java.awt.Color(255, 255, 255));
        jl_cuadrodenotas.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jl_cuadrodenotas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/tabla.png"))); // NOI18N
        jl_cuadrodenotas.setText("Cuadro de Notas");
        jl_cuadrodenotas.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 15));
        jl_cuadrodenotas.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jl_cuadrodenotas.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jl_cuadrodenotas.setIconTextGap(15);
        jl_cuadrodenotas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jl_cuadrodenotasMouseClicked(evt);
            }
        });
        jp_menudesp.add(jl_cuadrodenotas, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 280, 210, 30));

        jl_creartarea.setFont(new java.awt.Font("SansSerif", 1, 16)); // NOI18N
        jl_creartarea.setForeground(new java.awt.Color(255, 255, 255));
        jl_creartarea.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jl_creartarea.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/tarea.png"))); // NOI18N
        jl_creartarea.setText("Tareas");
        jl_creartarea.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 15));
        jl_creartarea.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jl_creartarea.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jl_creartarea.setIconTextGap(15);
        jl_creartarea.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jl_creartareaMouseClicked(evt);
            }
        });
        jp_menudesp.add(jl_creartarea, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 310, 210, 30));

        jLabel32.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel32.setForeground(new java.awt.Color(0, 204, 204));
        jLabel32.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel32.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/usuario.png"))); // NOI18N
        jp_menudesp.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 340, 140, 330));

        jLabel40.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel40.setForeground(new java.awt.Color(255, 255, 255));
        jLabel40.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel40.setText("Informacion");
        jp_menudesp.add(jLabel40, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 690, 110, 20));

        jLabel37.setFont(new java.awt.Font("Segoe UI", 1, 17)); // NOI18N
        jLabel37.setForeground(new java.awt.Color(255, 255, 255));
        jLabel37.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel37.setText("Usuario");
        jp_menudesp.add(jLabel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 730, 110, 20));

        jl_usuario.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jl_usuario.setForeground(new java.awt.Color(255, 255, 255));
        jl_usuario.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jp_menudesp.add(jl_usuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 760, 180, 20));

        jLabel38.setFont(new java.awt.Font("Segoe UI", 1, 17)); // NOI18N
        jLabel38.setForeground(new java.awt.Color(255, 255, 255));
        jLabel38.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel38.setText("Correo");
        jp_menudesp.add(jLabel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 800, 100, 20));

        jl_correo.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jl_correo.setForeground(new java.awt.Color(255, 255, 255));
        jl_correo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jp_menudesp.add(jl_correo, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 830, 190, 20));

        jLabel36.setFont(new java.awt.Font("Segoe UI", 1, 17)); // NOI18N
        jLabel36.setForeground(new java.awt.Color(255, 255, 255));
        jLabel36.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel36.setText("Contraseña");
        jp_menudesp.add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 880, 110, 20));

        jl_clave.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jl_clave.setForeground(new java.awt.Color(255, 255, 255));
        jl_clave.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jp_menudesp.add(jl_clave, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 910, 190, 20));

        jButton4.setBackground(new java.awt.Color(193, 216, 252));
        jButton4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton4.setText("Cerrar Sesion");
        jButton4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton4MouseClicked(evt);
            }
        });
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jp_menudesp.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 950, 130, 50));

        jL_fondomenudesp2.setBackground(new java.awt.Color(193, 216, 252));
        jL_fondomenudesp2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/fondo rojo mejor.png"))); // NOI18N
        jp_menudesp.add(jL_fondomenudesp2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 230, 1040));

        jf_iniciomaestro.getContentPane().add(jp_menudesp, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 230, 1040));

        crear_tarea.setBackground(new java.awt.Color(193, 216, 252));
        crear_tarea.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel167.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel167.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel167.setText("Crear Tareas");
        crear_tarea.add(jLabel167, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 80, 610, -1));

        jLabel141.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel141.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel141.setText("Nombre de la Tarea:");
        crear_tarea.add(jLabel141, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 190, 190, 30));

        jt_nombretarea.setBackground(new java.awt.Color(193, 216, 252));
        jt_nombretarea.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        crear_tarea.add(jt_nombretarea, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 190, 470, 30));

        jSeparator51.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator51.setForeground(new java.awt.Color(0, 0, 0));
        crear_tarea.add(jSeparator51, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 220, 560, 10));

        jLabel143.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel143.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel143.setText("Tipo de Archivo:");
        crear_tarea.add(jLabel143, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 300, 190, 30));

        jSeparator52.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator52.setForeground(new java.awt.Color(0, 0, 0));
        crear_tarea.add(jSeparator52, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 330, 130, 10));

        jcb_tipo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { ".txt", ".ppt", ".pdf", ".pdp", ".svg", ".doc", ".docx", ".xls", ".mp3", ".mp4" }));
        crear_tarea.add(jcb_tipo, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 300, 130, 30));

        jSeparator53.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator53.setForeground(new java.awt.Color(0, 0, 0));
        crear_tarea.add(jSeparator53, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 430, 130, 10));

        jLabel168.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel168.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel168.setText("Fecha de Entrega:");
        crear_tarea.add(jLabel168, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 400, 190, 30));
        crear_tarea.add(jdc_fechaentrega, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 400, 130, 30));

        jLabel169.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel169.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel169.setText("Fecha de Cierre:");
        crear_tarea.add(jLabel169, new org.netbeans.lib.awtextra.AbsoluteConstraints(1100, 400, 190, 30));
        crear_tarea.add(jdc_fechacierre, new org.netbeans.lib.awtextra.AbsoluteConstraints(1300, 400, 130, 30));

        jSeparator54.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator54.setForeground(new java.awt.Color(0, 0, 0));
        crear_tarea.add(jSeparator54, new org.netbeans.lib.awtextra.AbsoluteConstraints(1300, 430, 130, 10));

        jLabel170.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel170.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel170.setText("Hora Para Habilitar:");
        crear_tarea.add(jLabel170, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 510, 260, 30));

        hora_tarea_emp.setModel(new javax.swing.SpinnerNumberModel(1, 1, 24, 1));
        crear_tarea.add(hora_tarea_emp, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 510, 70, 30));

        jLabel171.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel171.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel171.setText(":");
        crear_tarea.add(jLabel171, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 510, -1, 30));

        minuto_tarea_emp.setModel(new javax.swing.SpinnerNumberModel(0, 0, 59, 1));
        crear_tarea.add(minuto_tarea_emp, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, 510, 70, 30));

        jSeparator55.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator55.setForeground(new java.awt.Color(0, 0, 0));
        crear_tarea.add(jSeparator55, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 540, 180, 10));

        jLabel172.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel172.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel172.setText("Hora Para Cerrar:");
        crear_tarea.add(jLabel172, new org.netbeans.lib.awtextra.AbsoluteConstraints(980, 510, 260, 30));

        hora_tarea_cierre.setModel(new javax.swing.SpinnerNumberModel(1, 1, 24, 1));
        crear_tarea.add(hora_tarea_cierre, new org.netbeans.lib.awtextra.AbsoluteConstraints(1250, 510, 70, 30));

        jLabel173.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel173.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel173.setText(":");
        crear_tarea.add(jLabel173, new org.netbeans.lib.awtextra.AbsoluteConstraints(1340, 510, -1, 30));

        minuto_tarea_cierre.setModel(new javax.swing.SpinnerNumberModel(0, 0, 59, 1));
        crear_tarea.add(minuto_tarea_cierre, new org.netbeans.lib.awtextra.AbsoluteConstraints(1360, 510, 70, 30));

        jSeparator56.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator56.setForeground(new java.awt.Color(0, 0, 0));
        crear_tarea.add(jSeparator56, new org.netbeans.lib.awtextra.AbsoluteConstraints(1250, 540, 180, 10));

        jb_crearTarea.setBackground(new java.awt.Color(255, 0, 0));
        jb_crearTarea.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jb_crearTarea.setText("Crear Tarea");
        jb_crearTarea.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jb_crearTareaMouseClicked(evt);
            }
        });
        crear_tarea.add(jb_crearTarea, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 610, 500, 80));

        lista_clases_tarea.setModel(new DefaultListModel());
        jScrollPane40.setViewportView(lista_clases_tarea);

        crear_tarea.add(jScrollPane40, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 90, 320, 610));

        jButton18.setBackground(new java.awt.Color(204, 0, 204));
        jButton18.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton18.setForeground(new java.awt.Color(255, 255, 255));
        jButton18.setText("Revisar Tareas");
        jButton18.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton18MouseClicked(evt);
            }
        });
        crear_tarea.add(jButton18, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 780, 140, 30));

        jTextArea2.setBackground(new java.awt.Color(193, 216, 252));
        jTextArea2.setColumns(20);
        jTextArea2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jTextArea2.setRows(5);
        jTextArea2.setText("     En el caso de querer revisar una tarea\n        haga click en el boton de abajo y \n  sera llevado a la pagina de lo que busca.");
        jScrollPane50.setViewportView(jTextArea2);

        crear_tarea.add(jScrollPane50, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 710, 240, -1));

        jLabel205.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel205.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel205.setText("Puntaje:");
        crear_tarea.add(jLabel205, new org.netbeans.lib.awtextra.AbsoluteConstraints(1200, 300, 90, 30));

        puntaje_tarea.setModel(new javax.swing.SpinnerNumberModel(1, 1, 24, 1));
        crear_tarea.add(puntaje_tarea, new org.netbeans.lib.awtextra.AbsoluteConstraints(1300, 300, 130, 30));

        jSeparator58.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator58.setForeground(new java.awt.Color(0, 0, 0));
        crear_tarea.add(jSeparator58, new org.netbeans.lib.awtextra.AbsoluteConstraints(1300, 330, 130, 10));

        jLabel218.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel218.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel218.setText("Eliga la clase a asiganar");
        crear_tarea.add(jLabel218, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 50, 270, 30));

        jf_iniciomaestro.getContentPane().add(crear_tarea, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 90, 1780, 850));

        jp_iniciomaestro.setBackground(new java.awt.Color(255, 255, 255));
        jp_iniciomaestro.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBackground(new java.awt.Color(193, 216, 252));
        jPanel3.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel43.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel43.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel43.setText("¿Esta preparado?");
        jPanel3.add(jLabel43, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 80, 460, 60));

        jLabel44.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel44.setText("UNITEC FCB © 2023 | Derechos reservados.");
        jPanel3.add(jLabel44, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 850, 350, 60));

        jScrollPane3.setBackground(new java.awt.Color(179, 205, 252));

        jTextArea3.setEditable(false);
        jTextArea3.setBackground(new java.awt.Color(142, 182, 252));
        jTextArea3.setColumns(20);
        jTextArea3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jTextArea3.setRows(5);
        jTextArea3.setText("\t\t                  ¡¡MUCHAS GRACIAS POR ACEPTAR ESTE TRABAJO!!\n\n           Confiamos en ti y dejamos la vida professional de nuestros amados alumnos en tus manos, esperamos que no tengas ningun\n           inconveniente a la hora de usar nuestra plataforma y en el caso de que lo haya, consulta con nuestros Ingenieros en Sistemas\n Computacionales de Programacion || ya que ellos fueron encargados de crear esta hermosa plataforma tematizada del Bayern Munchen.\n           Si quieres mas datos especificos contacta con el creador de la plataforma Jose Julian Bendaña Rodriguez de estas manera:\n\t\t\t     correo: julian.bendana@unitec.edu\n\t\t\t                   numero: 8786-7948\n");
        jTextArea3.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jScrollPane3.setViewportView(jTextArea3);

        jPanel3.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 440, 930, 190));

        jScrollPane4.setBackground(new java.awt.Color(179, 205, 252));

        jTextArea4.setEditable(false);
        jTextArea4.setBackground(new java.awt.Color(142, 182, 252));
        jTextArea4.setColumns(20);
        jTextArea4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jTextArea4.setRows(5);
        jTextArea4.setText("\t\n\tUsted fue contratado para dar de la mejor manera sus conocimientos sobre los temas que hay en sus clases\n asignadas. Usted estara a cargo de crear uin buen ambiente con sus alumnos a la hora de evaluarlos ya que ellos se esfuerzan y se matan casi\n\t       todos los dias para poder sacar las mejores notas posibles y tener un buen rendimiento academico.\n\n Es por eso que le daremos esta plataforma creada con demasiado pero muchisimo pero con bastante esfuerzo que se encargara de que usted\n    pueda crear examenes y tareas para asignarles a sus respectivos alumnos de su clase asignada. Tambien sera capaz de revisar las notas de \n   cada examen y al mismo tiempo tendra un apartado de \"Cuadro de Notas\" que podra ver las notas de todos los alumnos de esa clase y sus \n\t\t\t                             acumulativos.");
        jTextArea4.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jScrollPane4.setViewportView(jTextArea4);

        jPanel3.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 180, 960, 210));

        jp_iniciomaestro.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1920, 970));

        jLabel33.setBackground(new java.awt.Color(193, 216, 252));
        jp_iniciomaestro.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 230, 1040));

        jf_iniciomaestro.getContentPane().add(jp_iniciomaestro, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 90, 1780, 960));

        jf_mod_ex.setBackground(new java.awt.Color(193, 216, 252));
        jf_mod_ex.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lista2lista_exa.setModel(new DefaultListModel());
        lista2lista_exa.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lista2lista_exaMouseClicked(evt);
            }
        });
        jScrollPane43.setViewportView(lista2lista_exa);

        jf_mod_ex.add(jScrollPane43, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 150, 300, 650));

        listalista_clases.setModel(new DefaultListModel());
        listalista_clases.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                listalista_clasesMouseClicked(evt);
            }
        });
        jScrollPane44.setViewportView(listalista_clases);

        jf_mod_ex.add(jScrollPane44, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 150, 300, 650));

        jLabel179.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel179.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel179.setText("Modificar Examen");
        jf_mod_ex.add(jLabel179, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 50, 610, -1));

        jLabel180.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel180.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel180.setText("Elija el examen a modificar");
        jf_mod_ex.add(jLabel180, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 110, 300, 30));

        jLabel181.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel181.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel181.setText("Duracion del Examen (Minutos):");
        jf_mod_ex.add(jLabel181, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 150, 280, 30));

        sp_newtimeex.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jf_mod_ex.add(sp_newtimeex, new org.netbeans.lib.awtextra.AbsoluteConstraints(1100, 150, 100, 30));

        jSeparator59.setForeground(new java.awt.Color(0, 0, 0));
        jf_mod_ex.add(jSeparator59, new org.netbeans.lib.awtextra.AbsoluteConstraints(1100, 180, 100, 10));

        jLabel182.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel182.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel182.setText("Nueva Fecha del Examen:");
        jf_mod_ex.add(jLabel182, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 240, 230, 30));
        jf_mod_ex.add(jd_fechaexamenmod, new org.netbeans.lib.awtextra.AbsoluteConstraints(1100, 240, 150, 30));

        jSeparator60.setForeground(new java.awt.Color(0, 0, 0));
        jf_mod_ex.add(jSeparator60, new org.netbeans.lib.awtextra.AbsoluteConstraints(1100, 270, 150, 10));

        jLabel183.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel183.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel183.setText("Nueva Hora Para Habilitar:");
        jf_mod_ex.add(jLabel183, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 330, 260, 30));

        sp_newhora.setModel(new javax.swing.SpinnerNumberModel(1, 1, 24, 1));
        jf_mod_ex.add(sp_newhora, new org.netbeans.lib.awtextra.AbsoluteConstraints(1100, 330, 70, 30));

        jSeparator61.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator61.setForeground(new java.awt.Color(0, 0, 0));
        jf_mod_ex.add(jSeparator61, new org.netbeans.lib.awtextra.AbsoluteConstraints(1100, 360, 180, 10));

        sp_newminute.setModel(new javax.swing.SpinnerNumberModel(0, 0, 59, 1));
        jf_mod_ex.add(sp_newminute, new org.netbeans.lib.awtextra.AbsoluteConstraints(1210, 330, 70, 30));

        jLabel184.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel184.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel184.setText(":");
        jf_mod_ex.add(jLabel184, new org.netbeans.lib.awtextra.AbsoluteConstraints(1190, 330, -1, 30));

        jButton19.setBackground(new java.awt.Color(0, 0, 255));
        jButton19.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jButton19.setForeground(new java.awt.Color(255, 255, 255));
        jButton19.setText("Modificar Las Preguntas");
        jButton19.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton19MouseClicked(evt);
            }
        });
        jf_mod_ex.add(jButton19, new org.netbeans.lib.awtextra.AbsoluteConstraints(1000, 660, 340, 60));

        jb_modex.setBackground(new java.awt.Color(255, 0, 0));
        jb_modex.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jb_modex.setText("Modificar Datos Generales");
        jb_modex.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jb_modexMouseClicked(evt);
            }
        });
        jf_mod_ex.add(jb_modex, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 390, 340, 60));

        jTextArea1.setEditable(false);
        jTextArea1.setBackground(new java.awt.Color(193, 216, 252));
        jTextArea1.setColumns(20);
        jTextArea1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jTextArea1.setRows(5);
        jTextArea1.setText("\n\t\t\t       \n\t\t\t         OJO\n     En el caso de queres modificar las preguntas una por una haga clic en el boton de \"Modificar Las Preguntas\".\n            En este apartado se modificaran las preguntas de una en una sin importar que tipo de la misma sea.\n");
        jTextArea1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jScrollPane45.setViewportView(jTextArea1);

        jf_mod_ex.add(jScrollPane45, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 520, 640, 130));

        jLabel186.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel186.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel186.setText("Elija la clase del examen");
        jf_mod_ex.add(jLabel186, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 110, 300, 30));

        jf_iniciomaestro.getContentPane().add(jf_mod_ex, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 90, 1790, 870));

        Cuadro_Notas.setBackground(new java.awt.Color(193, 216, 252));
        Cuadro_Notas.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel158.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel158.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel158.setText("Cuadro de Notas");
        Cuadro_Notas.add(jLabel158, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 80, 610, -1));

        cn_tabla.setModel(new DefaultListModel());
        cn_tabla.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cn_tablaMouseClicked(evt);
            }
        });
        jScrollPane30.setViewportView(cn_tabla);

        Cuadro_Notas.add(jScrollPane30, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 160, 300, 600));

        tabla_cuadro.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Numero de Cuenta", "Nombre del Alumno"
            }
        ));
        jScrollPane31.setViewportView(tabla_cuadro);

        Cuadro_Notas.add(jScrollPane31, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 160, 1210, 600));

        jLabel219.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel219.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel219.setText("Eliga la clase");
        Cuadro_Notas.add(jLabel219, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 130, 270, 30));

        jf_iniciomaestro.getContentPane().add(Cuadro_Notas, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 90, 1690, 860));

        Resu_cadaex.setBackground(new java.awt.Color(193, 216, 252));
        Resu_cadaex.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        verresu_listaclase.setModel(new DefaultListModel());
        verresu_listaclase.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                verresu_listaclaseMouseClicked(evt);
            }
        });
        jScrollPane27.setViewportView(verresu_listaclase);

        Resu_cadaex.add(jScrollPane27, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 170, 300, 590));

        jLabel157.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel157.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel157.setText("Ver Resultados");
        Resu_cadaex.add(jLabel157, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 80, 610, -1));

        verresu_listaexa.setModel(new DefaultListModel());
        verresu_listaexa.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                verresu_listaexaMouseClicked(evt);
            }
        });
        jScrollPane28.setViewportView(verresu_listaexa);

        Resu_cadaex.add(jScrollPane28, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 170, 300, 590));

        tabla_verresu.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Numero de Cuenta", "Nombre", "Username", "Nota"
            }
        ));
        jScrollPane29.setViewportView(tabla_verresu);

        Resu_cadaex.add(jScrollPane29, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 170, 600, 590));

        jLabel220.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel220.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel220.setText("Eliga la clase");
        Resu_cadaex.add(jLabel220, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 140, 270, 30));

        jLabel221.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel221.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel221.setText("Eliga el examen");
        Resu_cadaex.add(jLabel221, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 140, 280, 30));

        jf_iniciomaestro.getContentPane().add(Resu_cadaex, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 90, 1690, 860));

        Elim_Jp_examen.setBackground(new java.awt.Color(193, 216, 252));
        Elim_Jp_examen.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel156.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel156.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel156.setText("Eliminando Examen");
        Elim_Jp_examen.add(jLabel156, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 80, 610, -1));

        elim_Lista_Elejirclase.setModel(new DefaultListModel());
        elim_Lista_Elejirclase.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                elim_Lista_ElejirclaseMouseClicked(evt);
            }
        });
        jScrollPane25.setViewportView(elim_Lista_Elejirclase);

        Elim_Jp_examen.add(jScrollPane25, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 160, 300, 600));

        elim_Lista_Elejirexamen.setModel(new DefaultListModel());
        elim_Lista_Elejirexamen.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                elim_Lista_ElejirexamenMouseClicked(evt);
            }
        });
        jScrollPane26.setViewportView(elim_Lista_Elejirexamen);

        Elim_Jp_examen.add(jScrollPane26, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 160, 300, 600));

        jButton11.setBackground(new java.awt.Color(204, 0, 0));
        jButton11.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton11.setText("Eliminar");
        jButton11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton11MouseClicked(evt);
            }
        });
        Elim_Jp_examen.add(jButton11, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 740, 120, 50));

        jLabel222.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel222.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel222.setText("Eliga la clase donde se encuentra el examen");
        Elim_Jp_examen.add(jLabel222, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 130, 400, 30));

        jLabel223.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel223.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel223.setText("Eliga el examen");
        Elim_Jp_examen.add(jLabel223, new org.netbeans.lib.awtextra.AbsoluteConstraints(900, 130, 280, 30));

        jf_iniciomaestro.getContentPane().add(Elim_Jp_examen, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 90, 1690, 860));

        jp_crearExamen.setBackground(new java.awt.Color(193, 216, 252));
        jp_crearExamen.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel129.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel129.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel129.setText("Creando un Nuevo Examen");
        jp_crearExamen.add(jLabel129, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 70, 610, -1));

        jt_tituloexamen.setBackground(new java.awt.Color(193, 216, 252));
        jt_tituloexamen.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jt_tituloexamen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jt_tituloexamenActionPerformed(evt);
            }
        });
        jp_crearExamen.add(jt_tituloexamen, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 180, 470, 30));

        jLabel130.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel130.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel130.setText("Titulo del Examen:");
        jp_crearExamen.add(jLabel130, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 180, 210, 30));

        jSeparator41.setForeground(new java.awt.Color(0, 0, 0));
        jp_crearExamen.add(jSeparator41, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 210, 470, 10));

        jLabel131.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel131.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel131.setText("Duracion del Examen (Minutos):");
        jp_crearExamen.add(jLabel131, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 270, 280, 30));

        jSeparator48.setForeground(new java.awt.Color(0, 0, 0));
        jp_crearExamen.add(jSeparator48, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 300, 100, 10));

        sp_minutosexamen.setModel(new javax.swing.SpinnerNumberModel());
        jp_crearExamen.add(sp_minutosexamen, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 270, 100, 30));

        jLabel132.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel132.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel132.setText("Hora Para Habilitar:");
        jp_crearExamen.add(jLabel132, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 450, 260, 30));

        sp_horaexamenab.setModel(new javax.swing.SpinnerNumberModel(1, 1, 24, 1));
        jp_crearExamen.add(sp_horaexamenab, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 450, 70, 30));

        jLabel133.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel133.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel133.setText(":");
        jp_crearExamen.add(jLabel133, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 450, -1, 30));

        sp_minutoexamenab.setModel(new javax.swing.SpinnerNumberModel(0, 0, 59, 1));
        jp_crearExamen.add(sp_minutoexamenab, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 450, 70, 30));

        jSeparator49.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator49.setForeground(new java.awt.Color(0, 0, 0));
        jp_crearExamen.add(jSeparator49, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 480, 180, 10));

        jLabel134.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel134.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel134.setText("Fecha del Examen:");
        jp_crearExamen.add(jLabel134, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 360, 210, 30));

        jSeparator50.setForeground(new java.awt.Color(0, 0, 0));
        jp_crearExamen.add(jSeparator50, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 390, 150, 10));
        jp_crearExamen.add(jd_fechaexamen, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 360, 150, 30));

        jButton9.setBackground(new java.awt.Color(255, 0, 0));
        jButton9.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jButton9.setText("Pasar a las Preguntas");
        jButton9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton9MouseClicked(evt);
            }
        });
        jp_crearExamen.add(jButton9, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 540, 280, 60));

        lista_clasesmaestro.setModel(new DefaultListModel());
        jScrollPane21.setViewportView(lista_clasesmaestro);

        jp_crearExamen.add(jScrollPane21, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 80, 300, 650));

        jLabel224.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel224.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel224.setText("Eliga la clase a asignar el examen");
        jp_crearExamen.add(jLabel224, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 50, 330, 30));

        jf_iniciomaestro.getContentPane().add(jp_crearExamen, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 90, 1690, 880));

        jPanel2.setBackground(new java.awt.Color(193, 216, 252));
        jPanel2.setPreferredSize(new java.awt.Dimension(1920, 1080));
        jf_iniciomaestro.getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 2020, -1));

        jf_inicioalumno.setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        jf_inicioalumno.setTitle("FCB UNITEC");
        jf_inicioalumno.setIconImage(getIconImage());
        jf_inicioalumno.setSize(new java.awt.Dimension(1920, 1080));
        jf_inicioalumno.getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel34.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Bayern superchiquito.png"))); // NOI18N
        jPanel5.add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(1280, 10, 50, 60));

        jLabel35.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Bayern superchiquito.png"))); // NOI18N
        jPanel5.add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 10, 50, 60));

        jLabel39.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        jLabel39.setForeground(new java.awt.Color(255, 255, 255));
        jLabel39.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel39.setText("BIEVENIDO ALUMNO");
        jPanel5.add(jLabel39, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 10, 870, 70));

        jLabel41.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/fondo rojo mejor.png"))); // NOI18N
        jPanel5.add(jLabel41, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 2000, 90));

        jp_menudespalumno.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jp_menudespalumno.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jl_barramaestros1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jl_barramaestros1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/tres+lineas.png"))); // NOI18N
        jl_barramaestros1.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 15));
        jl_barramaestros1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jl_barramaestros1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jl_barramaestros1MouseClicked(evt);
            }
        });
        jp_menudespalumno.add(jl_barramaestros1, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 100, 50, 30));

        jl_homemaestros1.setFont(new java.awt.Font("SansSerif", 1, 16)); // NOI18N
        jl_homemaestros1.setForeground(new java.awt.Color(255, 255, 255));
        jl_homemaestros1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jl_homemaestros1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/home.png"))); // NOI18N
        jl_homemaestros1.setText("Home");
        jl_homemaestros1.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 15));
        jl_homemaestros1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jl_homemaestros1.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jl_homemaestros1.setIconTextGap(15);
        jl_homemaestros1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jl_homemaestros1MouseClicked(evt);
            }
        });
        jp_menudespalumno.add(jl_homemaestros1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, 210, 30));

        jl_resexamen.setFont(new java.awt.Font("SansSerif", 1, 16)); // NOI18N
        jl_resexamen.setForeground(new java.awt.Color(255, 255, 255));
        jl_resexamen.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jl_resexamen.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/nuevoexamen (1).png"))); // NOI18N
        jl_resexamen.setText("Examenes ");
        jl_resexamen.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 15));
        jl_resexamen.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jl_resexamen.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jl_resexamen.setIconTextGap(15);
        jl_resexamen.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jl_resexamenMouseClicked(evt);
            }
        });
        jp_menudespalumno.add(jl_resexamen, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, 210, 30));

        jl_vernotaalum.setFont(new java.awt.Font("SansSerif", 1, 16)); // NOI18N
        jl_vernotaalum.setForeground(new java.awt.Color(255, 255, 255));
        jl_vernotaalum.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jl_vernotaalum.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/ojos_3.png"))); // NOI18N
        jl_vernotaalum.setText("Ver Resultados");
        jl_vernotaalum.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 15));
        jl_vernotaalum.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jl_vernotaalum.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jl_vernotaalum.setIconTextGap(15);
        jl_vernotaalum.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jl_vernotaalumMouseClicked(evt);
            }
        });
        jp_menudespalumno.add(jl_vernotaalum, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 190, 210, 30));

        jl_cuadrodenotasalum.setFont(new java.awt.Font("SansSerif", 1, 16)); // NOI18N
        jl_cuadrodenotasalum.setForeground(new java.awt.Color(255, 255, 255));
        jl_cuadrodenotasalum.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jl_cuadrodenotasalum.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/tabla.png"))); // NOI18N
        jl_cuadrodenotasalum.setText("Cuadro de Notas");
        jl_cuadrodenotasalum.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 15));
        jl_cuadrodenotasalum.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jl_cuadrodenotasalum.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jl_cuadrodenotasalum.setIconTextGap(15);
        jl_cuadrodenotasalum.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jl_cuadrodenotasalumMouseClicked(evt);
            }
        });
        jp_menudespalumno.add(jl_cuadrodenotasalum, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, 210, 30));

        jl_creartareaalum.setFont(new java.awt.Font("SansSerif", 1, 16)); // NOI18N
        jl_creartareaalum.setForeground(new java.awt.Color(255, 255, 255));
        jl_creartareaalum.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jl_creartareaalum.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/tarea.png"))); // NOI18N
        jl_creartareaalum.setText("Tareas");
        jl_creartareaalum.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 12));
        jl_creartareaalum.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jl_creartareaalum.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jl_creartareaalum.setIconTextGap(15);
        jl_creartareaalum.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jl_creartareaalumMouseClicked(evt);
            }
        });
        jp_menudespalumno.add(jl_creartareaalum, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 250, 210, 30));

        jLabel42.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel42.setForeground(new java.awt.Color(0, 204, 204));
        jLabel42.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel42.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/usuario.png"))); // NOI18N
        jp_menudespalumno.add(jLabel42, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 340, 140, 330));

        jLabel45.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel45.setForeground(new java.awt.Color(255, 255, 255));
        jLabel45.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel45.setText("Informacion");
        jp_menudespalumno.add(jLabel45, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 690, 110, 20));

        jLabel46.setFont(new java.awt.Font("Segoe UI", 1, 17)); // NOI18N
        jLabel46.setForeground(new java.awt.Color(255, 255, 255));
        jLabel46.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel46.setText("Usuario");
        jp_menudespalumno.add(jLabel46, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 730, 110, 20));

        jl_usuario1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jl_usuario1.setForeground(new java.awt.Color(255, 255, 255));
        jl_usuario1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jp_menudespalumno.add(jl_usuario1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 760, 180, 20));

        jLabel47.setFont(new java.awt.Font("Segoe UI", 1, 17)); // NOI18N
        jLabel47.setForeground(new java.awt.Color(255, 255, 255));
        jLabel47.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel47.setText("Correo");
        jp_menudespalumno.add(jLabel47, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 800, 100, 20));

        jl_correo1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jl_correo1.setForeground(new java.awt.Color(255, 255, 255));
        jl_correo1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jp_menudespalumno.add(jl_correo1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 830, 190, 20));

        jLabel48.setFont(new java.awt.Font("Segoe UI", 1, 17)); // NOI18N
        jLabel48.setForeground(new java.awt.Color(255, 255, 255));
        jLabel48.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel48.setText("Contraseña");
        jp_menudespalumno.add(jLabel48, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 880, 110, 20));

        jl_clave1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jl_clave1.setForeground(new java.awt.Color(255, 255, 255));
        jl_clave1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jp_menudespalumno.add(jl_clave1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 910, 190, 20));

        jButton5.setBackground(new java.awt.Color(193, 216, 252));
        jButton5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton5.setText("Cerrar Sesion");
        jButton5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton5MouseClicked(evt);
            }
        });
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jp_menudespalumno.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 950, 130, 50));

        jL_fondomenudesp3.setBackground(new java.awt.Color(193, 216, 252));
        jL_fondomenudesp3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/fondo rojo mejor.png"))); // NOI18N
        jp_menudespalumno.add(jL_fondomenudesp3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 230, 1040));

        jPanel5.add(jp_menudespalumno, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 230, 1040));

        panel_inicioalum.setBackground(new java.awt.Color(193, 216, 252));
        panel_inicioalum.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panel_inicioalum.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel49.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel49.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel49.setText("Bienvenido a FCB UNITEC");
        panel_inicioalum.add(jLabel49, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 80, 460, 60));

        jLabel50.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel50.setText("UNITEC FCB © 2023 | Derechos reservados.");
        panel_inicioalum.add(jLabel50, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 860, 350, 60));

        jScrollPane5.setBackground(new java.awt.Color(179, 205, 252));

        jTextArea5.setEditable(false);
        jTextArea5.setBackground(new java.awt.Color(142, 182, 252));
        jTextArea5.setColumns(20);
        jTextArea5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jTextArea5.setRows(5);
        jTextArea5.setText("\t\t  ¡¡MUCHAS GRACIAS POR ACEPTAR LOS TERMINOS DE NUESTRA PLATAFORMA!!\n\n           Creamos esta plataforma para que usted pueda ser evaluado eficazmente de una manera automatica y manual. esperamos que \n                 no tengas ningun inconveniente a la hora de usar nuestra plataforma y en el caso de que lo haya, consulta con nuestros \n           Ingenieros en Sistemas Computacionales de Programacion || ya que ellos fueron encargados de crear esta hermosa plataforma \n           tematizada del Bayern Munchen. Si quieres mas datos especificos contacta con el creador de la plataforma Jose Julian Bendaña \n\t\t                                     Rodriguez de estas manera:\n\t\t\t     correo: julian.bendana@unitec.edu\n\t\t\t                   numero: 8786-7948\n");
        jTextArea5.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jScrollPane5.setViewportView(jTextArea5);

        panel_inicioalum.add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 440, 930, 220));

        jScrollPane6.setBackground(new java.awt.Color(179, 205, 252));

        jTextArea6.setEditable(false);
        jTextArea6.setBackground(new java.awt.Color(142, 182, 252));
        jTextArea6.setColumns(20);
        jTextArea6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jTextArea6.setRows(5);
        jTextArea6.setText("\n         Esta plataforma esta hecha para que puedas disfrutar de la universidad tan bella a la que se matriculo. Usted podra hacer todas sus         \n        asignaciones creadas por sus docentes de la manera mas facil posible, podra hacer sus examenes, subir sus archivos de las tareas a la\n                                                                                              plataforma para ser revisado.\n\n  Podra ver los resultados de todos sus examenes al momento en que se envie el examen y podra ver el cuadro de notas donde estaran todas\n                                                 las notas de sus examenes en la clase elegida de las que usted matriculo anteriormente.                      \n\n\t              Usted es la razon por la que estamos aqui y queremos hacer de su experiencia un experiencia unica!");
        jTextArea6.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jScrollPane6.setViewportView(jTextArea6);

        panel_inicioalum.add(jScrollPane6, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 180, 960, 210));

        jPanel5.add(panel_inicioalum, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 2010, 970));

        jf_tareas_alumno.setBackground(new java.awt.Color(193, 216, 252));
        jf_tareas_alumno.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel174.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel174.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel174.setText("Tareas");
        jf_tareas_alumno.add(jLabel174, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 60, 610, -1));

        jSeparator57.setForeground(new java.awt.Color(51, 0, 51));
        jf_tareas_alumno.add(jSeparator57, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 300, 410, 10));

        lista_clases_alum.setModel(new DefaultListModel());
        lista_clases_alum.setPreferredSize(new java.awt.Dimension(260, 630));
        lista_clases_alum.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lista_clases_alumMouseClicked(evt);
            }
        });
        jScrollPane41.setViewportView(lista_clases_alum);

        jf_tareas_alumno.add(jScrollPane41, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 160, -1, 630));

        lista_tareas_alumno2.setModel(new DefaultListModel()
        );
        lista_tareas_alumno2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lista_tareas_alumno2MouseClicked(evt);
            }
        });
        jScrollPane42.setViewportView(lista_tareas_alumno2);

        jf_tareas_alumno.add(jScrollPane42, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 160, 270, 630));

        jLabel175.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel175.setText("UNITEC FCB © 2023 | Derechos reservados.");
        jf_tareas_alumno.add(jLabel175, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 860, 350, 60));

        sba.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        sba.setText("Subir Archivo:");
        jf_tareas_alumno.add(sba, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 160, 130, 30));

        jLabel206.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel206.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/archivo.png"))); // NOI18N
        jf_tareas_alumno.add(jLabel206, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 250, 410, 50));

        jButton26.setBackground(new java.awt.Color(255, 204, 102));
        jButton26.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton26.setText("Cargar un Archivo");
        jButton26.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton26MouseClicked(evt);
            }
        });
        jf_tareas_alumno.add(jButton26, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 360, 170, 40));

        entregartarea.setBackground(new java.awt.Color(204, 0, 0));
        entregartarea.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        entregartarea.setForeground(new java.awt.Color(255, 255, 255));
        entregartarea.setText("Entregar");
        entregartarea.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                entregartareaMouseClicked(evt);
            }
        });
        jf_tareas_alumno.add(entregartarea, new org.netbeans.lib.awtextra.AbsoluteConstraints(1230, 360, 130, 40));

        tarea_entregada.setBackground(new java.awt.Color(193, 216, 252));
        tarea_entregada.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel178.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/tarea+hecha.png"))); // NOI18N
        jLabel178.setPreferredSize(new java.awt.Dimension(340, 370));
        tarea_entregada.add(jLabel178, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 160, -1, -1));

        jLabel207.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel207.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel207.setText("La Tarea Ya esta Entregada");
        tarea_entregada.add(jLabel207, new org.netbeans.lib.awtextra.AbsoluteConstraints(-1, 20, 480, 40));

        jf_tareas_alumno.add(tarea_entregada, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 160, 480, 630));

        sba1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        sba1.setText("Subir Archivo:");
        jf_tareas_alumno.add(sba1, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 160, 130, 30));

        jLabel208.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel208.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel208.setText("Eliga la tarea");
        jf_tareas_alumno.add(jLabel208, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 130, 270, 30));

        jLabel209.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel209.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel209.setText("Eliga la clase");
        jf_tareas_alumno.add(jLabel209, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 130, 270, 30));

        jPanel5.add(jf_tareas_alumno, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 90, 1780, 960));

        Examenes_alum.setBackground(new java.awt.Color(193, 216, 252));
        Examenes_alum.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel159.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel159.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel159.setText("Examenes");
        Examenes_alum.add(jLabel159, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 50, 610, -1));

        lista_alum_clases.setModel(new DefaultListModel());
        lista_alum_clases.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lista_alum_clasesMouseClicked(evt);
            }
        });
        jScrollPane33.setViewportView(lista_alum_clases);

        Examenes_alum.add(jScrollPane33, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 170, 250, 600));

        lista_exa_clase.setModel(new DefaultListModel());
        jScrollPane34.setViewportView(lista_exa_clase);

        Examenes_alum.add(jScrollPane34, new org.netbeans.lib.awtextra.AbsoluteConstraints(1110, 170, 250, 600));

        jButton16.setBackground(new java.awt.Color(255, 0, 0));
        jButton16.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton16.setText("Empezar Examen");
        jButton16.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton16MouseClicked(evt);
            }
        });
        Examenes_alum.add(jButton16, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 810, 200, 50));

        jLabel160.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel160.setText("Elegir Examen");
        Examenes_alum.add(jLabel160, new org.netbeans.lib.awtextra.AbsoluteConstraints(1150, 130, -1, -1));

        jLabel161.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel161.setText("Elegir Clase");
        Examenes_alum.add(jLabel161, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 130, -1, -1));

        jLabel162.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel162.setText("UNITEC FCB © 2023 | Derechos reservados.");
        Examenes_alum.add(jLabel162, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 860, 350, 60));

        jPanel5.add(Examenes_alum, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 1930, 960));

        jp_Verresualu.setBackground(new java.awt.Color(193, 216, 252));
        jp_Verresualu.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        listaclasesalum.setModel(new DefaultListModel());
        listaclasesalum.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                listaclasesalumMouseClicked(evt);
            }
        });
        jScrollPane35.setViewportView(listaclasesalum);

        jp_Verresualu.add(jScrollPane35, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 180, 290, 600));

        listaexaalum.setModel(new DefaultListModel());
        listaexaalum.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                listaexaalumMouseClicked(evt);
            }
        });
        jScrollPane36.setViewportView(listaexaalum);

        jp_Verresualu.add(jScrollPane36, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 180, 300, 600));

        tablaresualu.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Numero de Cuenta", "Nombre", "Username", "Nota"
            }
        ));
        jScrollPane37.setViewportView(tablaresualu);

        jp_Verresualu.add(jScrollPane37, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 180, 600, 600));

        jLabel165.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel165.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel165.setText("Ver Resultados");
        jp_Verresualu.add(jLabel165, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 90, 610, -1));

        jLabel177.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel177.setText("UNITEC FCB © 2023 | Derechos reservados.");
        jp_Verresualu.add(jLabel177, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 870, 350, 60));

        jLabel225.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel225.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel225.setText("Eliga la clase");
        jp_Verresualu.add(jLabel225, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 150, 270, 30));

        jLabel226.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel226.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel226.setText("Eliga el examen");
        jp_Verresualu.add(jLabel226, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 150, 280, 30));

        jPanel5.add(jp_Verresualu, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 2010, 960));

        jp_cuadroalu.setBackground(new java.awt.Color(193, 216, 252));
        jp_cuadroalu.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Nombre de la Clase", "Hora", "UV"
            }
        ));
        jScrollPane38.setViewportView(tabla);

        jp_cuadroalu.add(jScrollPane38, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 690, 1070, 120));

        jLabel166.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel166.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel166.setText("Cuadro de notas");
        jp_cuadroalu.add(jLabel166, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 60, 610, -1));

        lista2222222222.setModel(new DefaultListModel());
        lista2222222222.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lista2222222222MouseClicked(evt);
            }
        });
        jScrollPane39.setViewportView(lista2222222222);

        jp_cuadroalu.add(jScrollPane39, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 180, 300, 470));

        jLabel176.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel176.setText("UNITEC FCB © 2023 | Derechos reservados.");
        jp_cuadroalu.add(jLabel176, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 870, 350, 60));

        jLabel227.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel227.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel227.setText("Eliga la clase");
        jp_cuadroalu.add(jLabel227, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 150, 280, 30));

        jPanel5.add(jp_cuadroalu, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 2010, 960));

        jL_fondomenudesp1.setBackground(new java.awt.Color(193, 216, 252));
        jPanel5.add(jL_fondomenudesp1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 230, 1050));

        jLabel51.setBackground(new java.awt.Color(193, 216, 252));
        jPanel5.add(jLabel51, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 230, 1040));

        jf_inicioalumno.getContentPane().add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 2010, 1050));

        jL_fondomenudesp.setBackground(new java.awt.Color(193, 216, 252));

        jd_preguntasex.setTitle("FCB UNITEC");
        jd_preguntasex.setSize(new java.awt.Dimension(720, 760));
        jd_preguntasex.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jd_preguntasexMouseClicked(evt);
            }
        });
        jd_preguntasex.getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTabbedPane1.setBackground(new java.awt.Color(0, 0, 0));
        jTabbedPane1.setForeground(new java.awt.Color(255, 255, 255));

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel139.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel139.setForeground(new java.awt.Color(255, 255, 255));
        jLabel139.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel139.setText("VERDADERO O FALSO");
        jPanel1.add(jLabel139, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 50, 410, 30));

        jLabel138.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel138.setForeground(new java.awt.Color(255, 255, 255));
        jLabel138.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel138.setText("La Respuesta es:");
        jPanel1.add(jLabel138, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 350, 270, 30));

        jButton10.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton10.setText("Agregar Pregunta");
        jButton10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton10MouseClicked(evt);
            }
        });
        jPanel1.add(jButton10, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 470, 190, 40));

        ja_preguntavf.setColumns(20);
        ja_preguntavf.setRows(5);
        jScrollPane22.setViewportView(ja_preguntavf);

        jPanel1.add(jScrollPane22, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 190, 540, 150));

        jb_true.setBackground(new java.awt.Color(102, 0, 0));
        trueorfalse.add(jb_true);
        jb_true.setForeground(new java.awt.Color(255, 255, 255));
        jb_true.setText("Verdadero");
        jPanel1.add(jb_true, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 410, -1, -1));

        jb_false.setBackground(new java.awt.Color(102, 0, 0));
        trueorfalse.add(jb_false);
        jb_false.setForeground(new java.awt.Color(255, 255, 255));
        jb_false.setText("Falso");
        jPanel1.add(jb_false, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 410, -1, -1));

        jLabel152.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel152.setForeground(new java.awt.Color(255, 255, 255));
        jLabel152.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel152.setText("Ingrese la Pregunta");
        jPanel1.add(jLabel152, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 130, 270, 30));

        jLabel153.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel153.setForeground(new java.awt.Color(255, 255, 255));
        jLabel153.setText("Puntuacion");
        jPanel1.add(jLabel153, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 100, -1, -1));

        puntuacionVF.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel1.add(puntuacionVF, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 100, -1, -1));

        jLabel135.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/fondo rojo mejor.png"))); // NOI18N
        jPanel1.add(jLabel135, new org.netbeans.lib.awtextra.AbsoluteConstraints(-20, -10, 740, 590));

        jTabbedPane1.addTab("Verdadero o Falso", jPanel1);

        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel140.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel140.setForeground(new java.awt.Color(255, 255, 255));
        jLabel140.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel140.setText("SELECCION MULTIPLE");
        jPanel4.add(jLabel140, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 50, 410, 30));

        ja_pregunta2.setColumns(20);
        ja_pregunta2.setRows(5);
        jScrollPane23.setViewportView(ja_pregunta2);

        jPanel4.add(jScrollPane23, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 160, 540, -1));

        jb_Agregarrespdispsm.setBackground(new java.awt.Color(0, 0, 0));
        jb_Agregarrespdispsm.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jb_Agregarrespdispsm.setForeground(new java.awt.Color(255, 255, 255));
        jb_Agregarrespdispsm.setText("Agregar Posible Respuesta");
        jb_Agregarrespdispsm.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jb_AgregarrespdispsmMouseClicked(evt);
            }
        });
        jPanel4.add(jb_Agregarrespdispsm, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 350, 230, 20));

        jLabel142.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel142.setForeground(new java.awt.Color(255, 255, 255));
        jLabel142.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel142.setText("Ingrese la Pregunta");
        jPanel4.add(jLabel142, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 110, 270, 30));

        jLabel144.setForeground(new java.awt.Color(255, 255, 255));
        jLabel144.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel144.setText("De una en una porfavor");
        jPanel4.add(jLabel144, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 300, 180, -1));

        jLabel145.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel145.setForeground(new java.awt.Color(255, 255, 255));
        jLabel145.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel145.setText("Respuesta Correcta:");
        jPanel4.add(jLabel145, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 390, 400, 30));
        jPanel4.add(tab_respdispsm, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 320, 540, -1));

        jButton12.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton12.setText("Agregar Pregunta");
        jButton12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton12MouseClicked(evt);
            }
        });
        jPanel4.add(jButton12, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 510, 170, 40));

        puntuacionSM.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel4.add(puntuacionSM, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 100, -1, -1));

        jLabel154.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel154.setForeground(new java.awt.Color(255, 255, 255));
        jLabel154.setText("Puntuacion");
        jPanel4.add(jLabel154, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 100, -1, -1));
        jPanel4.add(jc_respsssss, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 430, -1, -1));

        jLabel164.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel164.setForeground(new java.awt.Color(255, 255, 255));
        jLabel164.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel164.setText("Respuestas Disponibles");
        jPanel4.add(jLabel164, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 270, 400, 30));

        jLabel136.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/fondo+azul.png"))); // NOI18N
        jPanel4.add(jLabel136, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 720, 580));

        jTabbedPane1.addTab("Seleccion Multiple", jPanel4);

        jPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel146.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel146.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel146.setText("ENUMERACION");
        jPanel7.add(jLabel146, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 50, 410, 30));

        jLabel147.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel147.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel147.setText("Ingrese la Pregunta");
        jPanel7.add(jLabel147, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 110, 270, 30));

        ja_enu.setColumns(20);
        ja_enu.setRows(5);
        jScrollPane24.setViewportView(ja_enu);

        jPanel7.add(jScrollPane24, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 160, 540, -1));

        jButton14.setBackground(new java.awt.Color(0, 0, 0));
        jButton14.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton14.setForeground(new java.awt.Color(255, 255, 255));
        jButton14.setText("Agregar Respuesta Correcta");
        jButton14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton14MouseClicked(evt);
            }
        });
        jPanel7.add(jButton14, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 380, 240, 30));

        jLabel148.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel148.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel148.setText("Ingrese las Respuestas Correctas");
        jPanel7.add(jLabel148, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 280, 380, 30));

        jLabel149.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel149.setText("De una en una porfavor");
        jPanel7.add(jLabel149, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 310, 180, -1));
        jPanel7.add(tab2_respcoEnu, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 340, 540, 30));

        jButton15.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton15.setText("Agregar Pregunta");
        jButton15.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton15MouseClicked(evt);
            }
        });
        jPanel7.add(jButton15, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 470, 170, 40));

        puntuacionENU.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel7.add(puntuacionENU, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 100, -1, -1));

        jLabel155.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel155.setText("Puntuacion");
        jPanel7.add(jLabel155, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 100, -1, -1));

        jLabel137.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/fondo+blanco.png"))); // NOI18N
        jPanel7.add(jLabel137, new org.netbeans.lib.awtextra.AbsoluteConstraints(-150, -90, 990, 740));

        jTabbedPane1.addTab("Enumeracion", jPanel7);

        jd_preguntasex.getContentPane().add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 720, 610));

        jPanel8.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel151.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel151.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel151.setText("Terminar Examen");
        jLabel151.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel151.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel151MouseClicked(evt);
            }
        });
        jPanel8.add(jLabel151, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 720, 110));

        jLabel150.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Imagen1 (1).png"))); // NOI18N
        jLabel150.setText("jLabel150");
        jPanel8.add(jLabel150, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 720, 110));

        jd_preguntasex.getContentPane().add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 610, 720, 110));

        JF_EXAMEN.setTitle("Examen");
        JF_EXAMEN.setSize(new java.awt.Dimension(945, 730));
        JF_EXAMEN.getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel6.setBackground(new java.awt.Color(255, 153, 153));

        titulo.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        titulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addComponent(titulo, javax.swing.GroupLayout.DEFAULT_SIZE, 944, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap(46, Short.MAX_VALUE)
                .addComponent(titulo, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        JF_EXAMEN.getContentPane().add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -40, 950, 80));

        jScrollPane32.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        jp_mostrarex.setBackground(new java.awt.Color(255, 153, 153));
        jp_mostrarex.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jl_tituloexamen.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jl_tituloexamen.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jl_tituloexamen.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jp_mostrarex.add(jl_tituloexamen, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 920, 40));

        jScrollPane32.setViewportView(jp_mostrarex);

        JF_EXAMEN.getContentPane().add(jScrollPane32, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 36, 930, 550));

        boton_entregarex.setBackground(new java.awt.Color(204, 255, 255));
        boton_entregarex.setText("Entregar");
        boton_entregarex.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                boton_entregarexMouseClicked(evt);
            }
        });
        JF_EXAMEN.getContentPane().add(boton_entregarex, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 610, 128, 48));

        jLabel163.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/fondo+azul.png"))); // NOI18N
        JF_EXAMEN.getContentPane().add(jLabel163, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 570, 940, 140));

        jf_elegir_preguntas.setTitle("Elejir Preguntas");
        jf_elegir_preguntas.setPreferredSize(new java.awt.Dimension(375, 590));
        jf_elegir_preguntas.setSize(new java.awt.Dimension(375, 590));
        jf_elegir_preguntas.getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel9.setBackground(new java.awt.Color(255, 153, 153));
        jPanel9.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel185.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel185.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel185.setText("Eliga la Pregunta a Modificar");
        jPanel9.add(jLabel185, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, 360, 30));

        lista_preguntas.setModel(new DefaultListModel());
        jScrollPane46.setViewportView(lista_preguntas);

        jPanel9.add(jScrollPane46, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, 340, 410));

        jButton20.setBackground(new java.awt.Color(255, 255, 204));
        jButton20.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton20.setText("Modificar Pregunta");
        jButton20.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton20MouseClicked(evt);
            }
        });
        jPanel9.add(jButton20, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 490, 180, 40));

        jf_elegir_preguntas.getContentPane().add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 380, 600));

        jf_modvf.setTitle("Verdadero y Falso");
        jf_modvf.setSize(new java.awt.Dimension(531, 554));
        jf_modvf.getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel10.setBackground(new java.awt.Color(204, 255, 204));
        jPanel10.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel187.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel187.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel187.setText("Modificando Verdadero y Falso");
        jPanel10.add(jLabel187, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 530, 40));

        jLabel188.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel188.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel188.setText("Ingrese la Nueva Respuesta");
        jPanel10.add(jLabel188, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 290, 530, 40));

        jta_newpreguntavfmod.setColumns(20);
        jta_newpreguntavfmod.setRows(5);
        jScrollPane47.setViewportView(jta_newpreguntavfmod);

        jPanel10.add(jScrollPane47, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 170, 390, -1));

        jLabel189.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel189.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel189.setText("Ingrese la Nueva Pregunta");
        jPanel10.add(jLabel189, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 530, 40));

        jr_truemod.setBackground(new java.awt.Color(204, 255, 204));
        bg_vfmod.add(jr_truemod);
        jr_truemod.setText("Verdadero");
        jPanel10.add(jr_truemod, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 360, -1, -1));

        jr_falsemod.setBackground(new java.awt.Color(204, 255, 204));
        bg_vfmod.add(jr_falsemod);
        jr_falsemod.setText("Falso");
        jPanel10.add(jr_falsemod, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 360, -1, -1));

        jButton21.setBackground(new java.awt.Color(204, 204, 255));
        jButton21.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton21.setText("Modificar la Pregunta");
        jButton21.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton21MouseClicked(evt);
            }
        });
        jPanel10.add(jButton21, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 440, 230, 50));

        jLabel190.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel190.setText("Nueva puntuacion:");
        jPanel10.add(jLabel190, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 60, 120, 20));

        jSpinner1.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel10.add(jSpinner1, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 90, 100, -1));

        jf_modvf.getContentPane().add(jPanel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 530, 554));

        jf_modsm.setTitle("Seleccion Multiple");
        jf_modsm.setPreferredSize(new java.awt.Dimension(585, 600));
        jf_modsm.setSize(new java.awt.Dimension(585, 600));
        jf_modsm.getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel11.setBackground(new java.awt.Color(204, 204, 255));
        jPanel11.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel192.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel192.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel192.setText("SELECCION MULTIPLE");
        jPanel11.add(jLabel192, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 50, 400, 30));
        jPanel11.add(linea_respdisp, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 320, 530, 30));

        jLabel193.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel193.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel193.setText("Respuestas Disponibles");
        jPanel11.add(jLabel193, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 270, 390, 30));

        jb_Agregarrespdispsm1.setBackground(new java.awt.Color(0, 0, 0));
        jb_Agregarrespdispsm1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jb_Agregarrespdispsm1.setForeground(new java.awt.Color(255, 255, 255));
        jb_Agregarrespdispsm1.setText("Agregar Posible Respuesta");
        jb_Agregarrespdispsm1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jb_Agregarrespdispsm1MouseClicked(evt);
            }
        });
        jPanel11.add(jb_Agregarrespdispsm1, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 360, 270, 20));

        jta2_newquestionsm.setColumns(20);
        jta2_newquestionsm.setRows(5);
        jScrollPane48.setViewportView(jta2_newquestionsm);

        jPanel11.add(jScrollPane48, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, 530, 90));

        jLabel194.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel194.setText("De una en una porfavor");
        jPanel11.add(jLabel194, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 300, 170, 20));

        jLabel195.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel195.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel195.setText("Ingrese la Pregunta");
        jPanel11.add(jLabel195, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 110, 260, 30));
        jPanel11.add(linea_respco, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 430, 150, 30));

        jLabel196.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel196.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel196.setText("Respuesta Correcta:");
        jPanel11.add(jLabel196, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 390, 390, 30));

        jButton22.setBackground(new java.awt.Color(204, 255, 255));
        jButton22.setText("Modificar Pregunta");
        jButton22.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton22MouseClicked(evt);
            }
        });
        jPanel11.add(jButton22, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 480, 230, 50));

        jLabel191.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel191.setText("Nueva puntuacion:");
        jPanel11.add(jLabel191, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 90, 120, 20));

        jSpinner2.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel11.add(jSpinner2, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 120, 100, -1));

        jf_modsm.getContentPane().add(jPanel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 570, 590));

        jf_modEnu.setTitle("Enumeracion");
        jf_modEnu.setMinimumSize(new java.awt.Dimension(585, 500));
        jf_modEnu.setPreferredSize(new java.awt.Dimension(595, 540));
        jf_modEnu.setSize(new java.awt.Dimension(595, 540));
        jf_modEnu.getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel12.setBackground(new java.awt.Color(255, 204, 204));
        jPanel12.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel197.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel197.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel197.setText("ENUMERACION");
        jPanel12.add(jLabel197, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 20, 410, 30));

        jLabel198.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel198.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel198.setText("Ingrese la Pregunta");
        jPanel12.add(jLabel198, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 80, 270, 30));

        ja_modenu.setColumns(20);
        ja_modenu.setRows(5);
        jScrollPane49.setViewportView(ja_modenu);

        jPanel12.add(jScrollPane49, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, 540, -1));

        jLabel199.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel199.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel199.setText("Ingrese las Respuestas Correctas");
        jPanel12.add(jLabel199, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 250, 380, 30));

        jLabel200.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel200.setText("De una en una porfavor");
        jPanel12.add(jLabel200, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 280, 180, -1));
        jPanel12.add(textf_respcomodenu, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 310, 540, 30));

        jButton23.setBackground(new java.awt.Color(0, 0, 0));
        jButton23.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton23.setForeground(new java.awt.Color(255, 255, 255));
        jButton23.setText("Agregar Respuesta Correcta");
        jButton23.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton23MouseClicked(evt);
            }
        });
        jPanel12.add(jButton23, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 350, 240, 30));

        jButton24.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton24.setText("Agregar Pregunta");
        jButton24.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton24MouseClicked(evt);
            }
        });
        jPanel12.add(jButton24, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 440, 170, 40));

        jLabel201.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel201.setText("Nueva puntuacion:");
        jPanel12.add(jLabel201, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 70, 120, 20));

        jSpinner3.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel12.add(jSpinner3, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 100, 100, -1));

        jf_modEnu.getContentPane().add(jPanel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 580, 500));

        jf_revisartarea.setPreferredSize(new java.awt.Dimension(690, 550));
        jf_revisartarea.setSize(new java.awt.Dimension(690, 550));
        jf_revisartarea.getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel13.setBackground(new java.awt.Color(102, 255, 204));
        jPanel13.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jl_tarea.setModel(new DefaultListModel());
        jl_tarea.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jl_tareaMouseClicked(evt);
            }
        });
        jScrollPane51.setViewportView(jl_tarea);

        jPanel13.add(jScrollPane51, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 90, 130, 370));

        jLabel202.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel202.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel202.setText("Revisando Tareas");
        jPanel13.add(jLabel202, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, 690, -1));

        javax.swing.tree.DefaultMutableTreeNode treeNode1 = new javax.swing.tree.DefaultMutableTreeNode("Entrega");
        javax.swing.tree.DefaultMutableTreeNode treeNode2 = new javax.swing.tree.DefaultMutableTreeNode("Si");
        treeNode1.add(treeNode2);
        treeNode2 = new javax.swing.tree.DefaultMutableTreeNode("No");
        treeNode1.add(treeNode2);
        arbol.setModel(new javax.swing.tree.DefaultTreeModel(treeNode1));
        arbol.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                arbolMouseClicked(evt);
            }
        });
        jScrollPane53.setViewportView(arbol);

        jPanel13.add(jScrollPane53, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 90, 130, 370));

        jLabel203.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel203.setText("Asignar nota:");
        jPanel13.add(jLabel203, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 110, 120, 30));

        jLabel204.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel204.setText("Ingrese la nota de la tarea:");
        jPanel13.add(jLabel204, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 160, 150, 30));

        nota_tarea.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel13.add(nota_tarea, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 160, 90, 30));

        jButton25.setBackground(new java.awt.Color(0, 0, 0));
        jButton25.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton25.setForeground(new java.awt.Color(255, 255, 255));
        jButton25.setText("Calificar");
        jButton25.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton25MouseClicked(evt);
            }
        });
        jPanel13.add(jButton25, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 230, 130, 40));

        jLabel228.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel228.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel228.setText("Eliga la clase");
        jPanel13.add(jLabel228, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 60, 130, 30));

        jf_revisartarea.getContentPane().add(jPanel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 690, 550));

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("FCB UNITEC");
        setIconImage(getIconImage());
        setPreferredSize(new java.awt.Dimension(1920, 1080));
        setSize(new java.awt.Dimension(1920, 1080));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 50)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("BIENVENIDO A FCB UNITEC");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 150, 690, 120));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Bayern chiqui.png"))); // NOI18N
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 280, 150, 170));

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Contraseña de Usuario:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(577, 700, -1, 40));

        tf_user.setBackground(new java.awt.Color(242, 242, 242));
        tf_user.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        getContentPane().add(tf_user, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 620, 440, 40));

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Nombre de Usuario:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 620, 210, 40));

        pf_clave.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        getContentPane().add(pf_clave, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 700, 440, 40));

        jb_iniciarsesion.setText("ENTRAR");
        jb_iniciarsesion.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jb_iniciarsesion.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jb_iniciarsesionMouseClicked(evt);
            }
        });
        getContentPane().add(jb_iniciarsesion, new org.netbeans.lib.awtextra.AbsoluteConstraints(900, 790, 180, 60));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Iniciar Sesion");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 520, 230, 50));

        jButton2.setText("Marcos");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1470, 740, -1, -1));

        jLabel23.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(255, 255, 255));
        jLabel23.setText("Registro");
        getContentPane().add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(1800, 900, 70, -1));

        jLabel24.setForeground(new java.awt.Color(255, 255, 255));
        jLabel24.setText("Contraseña:");
        getContentPane().add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(1760, 960, 70, -1));

        jLabel25.setForeground(new java.awt.Color(255, 255, 255));
        jLabel25.setText("registro");
        getContentPane().add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(1830, 930, 50, -1));

        jLabel26.setForeground(new java.awt.Color(255, 255, 255));
        jLabel26.setText("registro123");
        getContentPane().add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(1830, 960, 80, -1));

        jLabel27.setForeground(new java.awt.Color(255, 255, 255));
        jLabel27.setText("Usuario:");
        getContentPane().add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(1780, 930, 50, -1));

        jButton13.setText("Registro");
        jButton13.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton13MouseClicked(evt);
            }
        });
        getContentPane().add(jButton13, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 560, -1, -1));

        jButton17.setText("Juan");
        jButton17.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton17MouseClicked(evt);
            }
        });
        getContentPane().add(jButton17, new org.netbeans.lib.awtextra.AbsoluteConstraints(1240, 530, -1, -1));

        jl_fondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/fondo rojo mejor.png"))); // NOI18N
        getContentPane().add(jl_fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1920, 1050));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
//        jf_inicioregistro.setLocationRelativeTo(this);
//        jf_inicioregistro.setExtendedState(MAXIMIZED_BOTH);
//        jf_inicioregistro.setVisible(true);
//        jp_eliminarmaestro.setVisible(false);
//        jp_modalumno.setVisible(false);
//        jp_crearmaestro.setVisible(false);
//        jp_crearAlumno.setVisible(false);
//        jp_crearclase.setVisible(false);
//        jp_modificarmaestros.setVisible(false);
//        jp_modificarclase.setVisible(false);
//        jp_asignaralumclase.setVisible(false);
//        jp_EliminarClase.setVisible(false);
//        jpanel_modregistro.setVisible(false);
//        jpanel_elimregistro.setVisible(false);
//        Jp_asignarmaestroclase.setVisible(false);
//        tf_user.setText("");
//        pf_clave.setText("");
//        this.setVisible(false);
//        ch_maestros_registro.select(0);
//        ch_alumnos_registro.select(0);
//        ch_clases_registro.select(0);
//        ch_registro_registro.select(0);
        tf_user.setText("marcos");
        pf_clave.setText("1234");
//        for (int i = 0; i < ac.getClases().size(); i++) {
//            for (int j = 0; j < ac.getClases().get(i).getExamenes().size(); j++) {
//                ac.getClases().get(i).getExamenes().remove(j);
//            }
//        }
//        for (int i = 0; i < au.getUsuarios().size(); i++) {
//            if ( au.getUsuarios().get(i) instanceof Alumno) {
//                for (int j = 0; j < ((Alumno)au.getUsuarios().get(i)).getClases().size(); j++) {
//                    for (int k = 0; k < ((Alumno)au.getUsuarios().get(i)).getClases().get(j).getExamenes().size(); k++) {
//                        ((Alumno)au.getUsuarios().get(i)).getClases().get(j).getExamenes().remove(k);
//                    }
//                }
//            }else if( au.getUsuarios().get(i) instanceof Maestro){
//                for (int j = 0; j < ((Maestro)au.getUsuarios().get(i)).getClasesense().size(); j++) {
//                    for (int k = 0; k < ((Maestro)au.getUsuarios().get(i)).getClasesense().get(j).getExamenes().size(); k++) {
//                        ((Maestro)au.getUsuarios().get(i)).getClasesense().get(j).getExamenes().remove(k);
//                    }
//                }
//            }
//        }
//        ac.EscribirArchivo();
//        au.EscribirArchivo();
//        ac.CargarArchivo();
//        au.CargarArchivo();

//        for (int i = 0; i < ac.getClases().size(); i++) {
//            for (int j = 0; j < ac.getClases().get(i).getExamenes().size(); j++) {
//                JOptionPane.showMessageDialog(this, ac.getClases().get(i).getNombreclase() + " " + ac.getClases().get(i).getExamenes().get(j).getNota());
//            }
//
//        }
//        for (int i = 0; i < au.getUsuarios().size(); i++) {
//            if (au.getUsuarios().get(i) instanceof Alumno) {
//                for (int j = 0; j < ((Alumno)au.getUsuarios().get(i)).getClases().size(); j++) {
//                    JOptionPane.showMessageDialog(this, au.getUsuarios().get(i).getNombreusuario() + " " + ((Alumno)au.getUsuarios().get(i)).getClases().get(j).getNombreclase()+ " "+((Alumno)au.getUsuarios().get(i)).getClases().get(j).getExamenes()+" "+j);
//                }
//            }
//        }
//          for (int i = 0; i < ac.getClases().size(); i++) {
//             JOptionPane.showMessageDialog(this, ac.getClases().get(i).getNombreclase()+" "+ac.getClases().get(i).getExamenes());
//        }

    }//GEN-LAST:event_jButton2ActionPerformed

    private void jb_cerrarsesionregistroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jb_cerrarsesionregistroActionPerformed
        cualentra = -1;
        jf_inicioregistro.setVisible(false);
        this.setVisible(true);
    }//GEN-LAST:event_jb_cerrarsesionregistroActionPerformed

    private void ch_maestros_registroItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_ch_maestros_registroItemStateChanged

        ch_alumnos_registro.select(0);
        ch_clases_registro.select(0);
        ch_registro_registro.select(0);
        if (ch_maestros_registro.getSelectedItem().equalsIgnoreCase("Ingresar Maestro")) {
            jp_eliminarmaestro.setVisible(false);
            jp_inicioregistro.setVisible(false);
            jp_modificarmaestros.setVisible(false);
            jp_modalumno.setVisible(false);
            jp_crearmaestro.setVisible(true);
            jp_crearAlumno.setVisible(false);
            jp_crearclase.setVisible(false);
            jp_modificarclase.setVisible(false);
            jp_EliminarAlumno.setVisible(false);
            jp_EliminarClase.setVisible(false);
            jp_crearregistro.setVisible(false);
            jpanel_modregistro.setVisible(false);
            jpanel_elimregistro.setVisible(false);
            jp_asignaralumclase.setVisible(false);
            Jp_asignarmaestroclase.setVisible(false);

            jButton1.setVisible(true);
            jf_idmaestronuevo.setText("");
            jf_Sueldomaestronuevo.setText("");
            jt_profesionmaestronuevo.setText("");
            JT_Rolmaestronuevo.setText("");
            jt_usermaestronuevo.setText("");
            jt_nombremaestronuevo.setText("");
            jt_contramaestronuevo.setText("");

        } else if (ch_maestros_registro.getSelectedItem().equalsIgnoreCase("Modificar Maestro")) {
            jp_eliminarmaestro.setVisible(false);
            jp_inicioregistro.setVisible(false);
            jp_modalumno.setVisible(false);
            jp_crearmaestro.setVisible(false);
            jp_crearAlumno.setVisible(false);
            jp_modificarclase.setVisible(false);
            jp_crearclase.setVisible(false);
            jp_crearregistro.setVisible(false);
            llenarlistamodmaestros();
            jp_modificarmaestros.setVisible(true);
            jp_EliminarAlumno.setVisible(false);
            jp_EliminarClase.setVisible(false);
            jpanel_modregistro.setVisible(false);
            jpanel_elimregistro.setVisible(false);
            jp_asignaralumclase.setVisible(false);
            Jp_asignarmaestroclase.setVisible(false);

        } else if (ch_maestros_registro.getSelectedItem().equalsIgnoreCase("Eliminar Maestro")) {
            LlenarListaElimMaestro();
            jp_eliminarmaestro.setVisible(true);
            jp_inicioregistro.setVisible(false);
            jp_modificarmaestros.setVisible(false);
            jp_modalumno.setVisible(false);
            jp_modificarclase.setVisible(false);
            jp_crearmaestro.setVisible(false);
            jp_crearAlumno.setVisible(false);
            jp_crearclase.setVisible(false);
            jp_EliminarAlumno.setVisible(false);
            jp_crearregistro.setVisible(false);
            jp_EliminarClase.setVisible(false);
            jpanel_modregistro.setVisible(false);
            jpanel_elimregistro.setVisible(false);
            jp_asignaralumclase.setVisible(false);
            Jp_asignarmaestroclase.setVisible(false);

        } else if (ch_maestros_registro.getSelectedItem().equalsIgnoreCase("Inicio")) {
            jp_eliminarmaestro.setVisible(false);
            jp_inicioregistro.setVisible(true);
            jp_modificarmaestros.setVisible(false);
            jp_modalumno.setVisible(false);
            jp_modificarclase.setVisible(false);
            jp_crearmaestro.setVisible(false);
            jp_crearAlumno.setVisible(false);
            jp_crearclase.setVisible(false);
            jp_EliminarAlumno.setVisible(false);
            jp_EliminarClase.setVisible(false);
            jp_crearregistro.setVisible(false);
            jpanel_modregistro.setVisible(false);
            jpanel_elimregistro.setVisible(false);
            jp_asignaralumclase.setVisible(false);
            Jp_asignarmaestroclase.setVisible(false);

        }
    }//GEN-LAST:event_ch_maestros_registroItemStateChanged

    private void ch_clases_registroItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_ch_clases_registroItemStateChanged
        ch_maestros_registro.select(0);
        ch_alumnos_registro.select(0);
        ch_registro_registro.select(0);
        if (ch_clases_registro.getSelectedItem().equalsIgnoreCase("Ingresar Clase")) {
            jp_modificarmaestros.setVisible(false);
            jp_inicioregistro.setVisible(false);
            jp_modificarclase.setVisible(false);
            jp_crearmaestro.setVisible(false);
            jp_modalumno.setVisible(false);
            jp_crearAlumno.setVisible(false);
            jp_eliminarmaestro.setVisible(false);
            jp_crearclase.setVisible(true);
            jp_EliminarAlumno.setVisible(false);
            jp_EliminarClase.setVisible(false);
            jp_crearregistro.setVisible(false);
            jpanel_modregistro.setVisible(false);
            jpanel_elimregistro.setVisible(false);
            jp_asignaralumclase.setVisible(false);
            Jp_asignarmaestroclase.setVisible(false);

            jButton1.setVisible(true);
            jt_nombreclasenueva.setText("");
            jf_idclasenueva.setText("");
            anioclasenueva.setDate(null);
            js_horaclasenueva.setValue(1);
            js_minutoclasenueva.setValue(0);
            jc_tipohoraclasenueva.setSelectedIndex(0);
            js_semestreclasenueva.setValue(1);
            js_Periodoclasenueva.setValue(1);
            js_uvclasenueva.setValue(1);
        } else if (ch_clases_registro.getSelectedItem().equalsIgnoreCase("Modificar Clase")) {
            jp_modificarclase.setVisible(true);
            llenarlistadeclases();
            jp_inicioregistro.setVisible(false);
            jp_modalumno.setVisible(false);
            jp_crearmaestro.setVisible(false);
            jp_eliminarmaestro.setVisible(false);
            jp_crearAlumno.setVisible(false);
            jp_crearclase.setVisible(false);
            jp_modalumno.setVisible(false);
            jp_EliminarAlumno.setVisible(false);
            jp_crearregistro.setVisible(false);
            jp_EliminarClase.setVisible(false);
            jpanel_modregistro.setVisible(false);
            jpanel_elimregistro.setVisible(false);
            jp_asignaralumclase.setVisible(false);
            Jp_asignarmaestroclase.setVisible(false);

        } else if (ch_clases_registro.getSelectedItem().equalsIgnoreCase("Eliminar Clase")) {
            jp_EliminarClase.setVisible(true);
            jp_inicioregistro.setVisible(false);
            jp_eliminarmaestro.setVisible(false);
            jp_modificarmaestros.setVisible(false);
            jp_modalumno.setVisible(false);
            jp_modificarclase.setVisible(false);
            jp_crearmaestro.setVisible(false);
            jp_crearAlumno.setVisible(false);
            jp_crearclase.setVisible(false);
            jp_EliminarAlumno.setVisible(false);
            jp_crearregistro.setVisible(false);
            jpanel_modregistro.setVisible(false);
            jpanel_elimregistro.setVisible(false);
            jp_asignaralumclase.setVisible(false);
            Jp_asignarmaestroclase.setVisible(false);
            LlenarListaElimClase();

        } else if (ch_clases_registro.getSelectedItem().equalsIgnoreCase("Inicio")) {
            jp_inicioregistro.setVisible(true);
            jp_eliminarmaestro.setVisible(false);
            jp_modificarmaestros.setVisible(false);
            jp_modalumno.setVisible(false);
            jp_modificarclase.setVisible(false);
            jp_crearmaestro.setVisible(false);
            jp_crearAlumno.setVisible(false);
            jp_crearclase.setVisible(false);
            jp_EliminarAlumno.setVisible(false);
            jp_EliminarClase.setVisible(false);
            jp_crearregistro.setVisible(false);
            jpanel_modregistro.setVisible(false);
            jpanel_elimregistro.setVisible(false);
            jp_asignaralumclase.setVisible(false);
            Jp_asignarmaestroclase.setVisible(false);

        } else if (ch_clases_registro.getSelectedItem().equalsIgnoreCase("Agregar Maestro A Clases")) {
            Jp_asignarmaestroclase.setVisible(true);
            jp_eliminarmaestro.setVisible(false);
            jp_inicioregistro.setVisible(false);
            jp_modificarmaestros.setVisible(false);
            jp_modalumno.setVisible(false);
            jp_modificarclase.setVisible(false);
            jp_crearmaestro.setVisible(false);
            jp_crearAlumno.setVisible(false);
            jp_crearclase.setVisible(false);
            jp_EliminarAlumno.setVisible(false);
            jp_EliminarClase.setVisible(false);
            jp_crearregistro.setVisible(false);
            jpanel_modregistro.setVisible(false);
            jpanel_elimregistro.setVisible(false);
            jp_asignaralumclase.setVisible(false);

            DefaultTableModel modelotablilla = (DefaultTableModel) jtable_maestroenclase.getModel();
            modelotablilla.getDataVector().removeAllElements();
            jtable_maestroenclase.updateUI();

            llenarlistamodmaestros();
            DefaultListModel modelolistamestros = (DefaultListModel) jlista_maestroasig.getModel();
            modelolistamestros.removeAllElements();
            for (int i = 0; i < maestrosmodificadores.size(); i++) {
                modelolistamestros.addElement(maestrosmodificadores.get(i));
            }
            jlista_maestroasig.setModel(modelolistamestros);

            llenarlistadeclases();
            DefaultListModel modelolistadeclases = (DefaultListModel) jlista_metermaestroclase.getModel();
            modelolistadeclases.removeAllElements();

            for (int i = 0; i < ac.getClases().size(); i++) {
                modelolistadeclases.addElement(ac.getClases().get(i));
            }
            jlista_metermaestroclase.setModel(modelolistadeclases);

        } else if (ch_clases_registro.getSelectedItem().equalsIgnoreCase("Agregar Alumno A Clases")) {
            jp_eliminarmaestro.setVisible(false);
            jp_asignaralumclase.setVisible(true);
            jp_inicioregistro.setVisible(false);
            jp_modificarmaestros.setVisible(false);
            jp_modalumno.setVisible(false);
            jp_modificarclase.setVisible(false);
            jp_crearmaestro.setVisible(false);
            jp_crearAlumno.setVisible(false);
            jp_crearclase.setVisible(false);
            jp_EliminarAlumno.setVisible(false);
            jp_EliminarClase.setVisible(false);
            jp_crearregistro.setVisible(false);
            jpanel_modregistro.setVisible(false);
            jpanel_elimregistro.setVisible(false);
            Jp_asignarmaestroclase.setVisible(false);

            DefaultTableModel modelotabla = (DefaultTableModel) jtable_alumnosenclase.getModel();
            modelotabla.getDataVector().removeAllElements();
            jtable_alumnosenclase.updateUI();

            llenarlistamodalumnos();
            DefaultListModel modelolistaalumnos = (DefaultListModel) jlista_alumnosag.getModel();
            modelolistaalumnos.removeAllElements();
            for (int i = 0; i < alumnosmodificadores.size(); i++) {
                modelolistaalumnos.addElement(alumnosmodificadores.get(i));
            }
            jlista_alumnosag.setModel(modelolistaalumnos);

            llenarlistadeclases();
            DefaultListModel modelolistaclases = (DefaultListModel) jlista_clases.getModel();
            modelolistaclases.removeAllElements();
            for (int i = 0; i < ac.getClases().size(); i++) {
                modelolistaclases.addElement(ac.getClases().get(i));
            }
            jlista_clases.setModel(modelolistaclases);
        }
    }//GEN-LAST:event_ch_clases_registroItemStateChanged

    private void ch_alumnos_registroItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_ch_alumnos_registroItemStateChanged
        ch_maestros_registro.select(0);
        ch_clases_registro.select(0);
        ch_registro_registro.select(0);
        if (ch_alumnos_registro.getSelectedItem().equalsIgnoreCase("Ingresar Alumno")) {
            jp_modificarmaestros.setVisible(false);
            jp_crearAlumno.setVisible(true);
            jp_modalumno.setVisible(false);
            jp_modificarclase.setVisible(false);
            jp_crearclase.setVisible(false);
            jp_crearmaestro.setVisible(false);
            jp_inicioregistro.setVisible(false);
            jp_eliminarmaestro.setVisible(false);
            jp_EliminarAlumno.setVisible(false);
            jp_EliminarClase.setVisible(false);
            jp_crearregistro.setVisible(false);
            jpanel_modregistro.setVisible(false);
            jpanel_elimregistro.setVisible(false);
            jp_asignaralumclase.setVisible(false);
            Jp_asignarmaestroclase.setVisible(false);

            jButton1.setVisible(false);
            jf_numcuentanuevoalumno.setText("");
            jt_useralumnonuevo.setText("");
            jt_rolalumnonuevo.setText("");
            jt_nombrealumnonuevo.setText("");
            jt_contraalumnonuevo.setText("");
            jt_carreranuevoalumno.setText("");
        } else if (ch_alumnos_registro.getSelectedItem().equalsIgnoreCase("Modificar Alumno")) {
            llenarlistamodalumnos();
            jp_inicioregistro.setVisible(false);
            jp_modalumno.setVisible(false);
            jp_crearmaestro.setVisible(false);
            jp_modificarclase.setVisible(false);
            jp_crearAlumno.setVisible(false);
            jp_eliminarmaestro.setVisible(false);
            jp_crearclase.setVisible(false);
            jp_modalumno.setVisible(true);
            jp_EliminarAlumno.setVisible(false);
            jp_EliminarClase.setVisible(false);
            jp_crearregistro.setVisible(false);
            jpanel_modregistro.setVisible(false);
            jpanel_elimregistro.setVisible(false);
            jp_asignaralumclase.setVisible(false);
            Jp_asignarmaestroclase.setVisible(false);

        } else if (ch_alumnos_registro.getSelectedItem().equalsIgnoreCase("Eliminar Alumno")) {
            LlenarListaEliminarAlumno();
            jp_EliminarAlumno.setVisible(true);
            jp_modificarmaestros.setVisible(false);
            jp_modalumno.setVisible(false);
            jp_inicioregistro.setVisible(false);
            jp_crearAlumno.setVisible(false);
            jp_crearmaestro.setVisible(false);
            jp_crearclase.setVisible(false);
            jp_eliminarmaestro.setVisible(false);
            jp_modificarclase.setVisible(false);
            jp_EliminarClase.setVisible(false);
            jp_crearregistro.setVisible(false);
            jpanel_modregistro.setVisible(false);
            jpanel_elimregistro.setVisible(false);
            jp_asignaralumclase.setVisible(false);
            Jp_asignarmaestroclase.setVisible(false);

        } else if (ch_alumnos_registro.getSelectedItem().equalsIgnoreCase("Inicio")) {
            jp_modificarmaestros.setVisible(false);
            jp_modalumno.setVisible(false);
            jp_inicioregistro.setVisible(true);
            jp_crearAlumno.setVisible(false);
            jp_crearmaestro.setVisible(false);
            jp_crearclase.setVisible(false);
            jp_eliminarmaestro.setVisible(false);
            jp_modificarclase.setVisible(false);
            jp_EliminarAlumno.setVisible(false);
            jp_EliminarClase.setVisible(false);
            jp_crearregistro.setVisible(false);
            jpanel_modregistro.setVisible(false);
            jpanel_elimregistro.setVisible(false);
            jp_asignaralumclase.setVisible(false);
            Jp_asignarmaestroclase.setVisible(false);
        }
    }//GEN-LAST:event_ch_alumnos_registroItemStateChanged

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jl_barramaestrosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jl_barramaestrosMouseClicked
        if (jp_menudesp.getX() == 0) {
            desplace.desplazarIzquierda(jp_menudesp, jp_menudesp.getX(), -170, 10, 10);
        } else if (jp_menudesp.getX() == -170) {
            desplace.desplazarDerecha(jp_menudesp, jp_menudesp.getX(), 0, 10, 10);
        }
    }//GEN-LAST:event_jl_barramaestrosMouseClicked

    private void jButton4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton4MouseClicked
        jf_iniciomaestro.setVisible(false);
        cualentra = -1;
        this.setVisible(true);
    }//GEN-LAST:event_jButton4MouseClicked

    private void jl_barramaestros1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jl_barramaestros1MouseClicked
        if (jp_menudespalumno.getX() == 0) {
            desplace2.desplazarIzquierda(jp_menudespalumno, jp_menudespalumno.getX(), -170, 10, 10);
        } else if (jp_menudespalumno.getX() == -170) {
            desplace2.desplazarDerecha(jp_menudespalumno, jp_menudespalumno.getX(), 0, 10, 10);
        }
    }//GEN-LAST:event_jl_barramaestros1MouseClicked

    private void jButton5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton5MouseClicked
        cualentra = -1;
        jf_inicioalumno.setVisible(false);
        this.setVisible(true);
    }//GEN-LAST:event_jButton5MouseClicked

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed

    }//GEN-LAST:event_jButton5ActionPerformed

    private void jb_iniciarsesionMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jb_iniciarsesionMouseClicked
        Registro registro = new Registro("registro", "registro123", "registro");
//        Clase gastro = new Clase(22, 4, 1, 2, new Date(), "Gastronomia", "10:30Pm");
//        Alumno juan  = new Alumno(15521414, "Gastronomia", "Estudia", "juan", "123", "Juan");
//        Maestro marco = new Maestro(19921882, "Gastronomia", "Educa", 2312, "marcos", "1234", "Marcos");
//        gastro.getAlumnosreciben().add(juan);
//        gastro.setMister(marco);
//        juan.getClases().add(gastro);
//        marco.getClasesense().add(gastro);
        au.getUsuarios().add(registro);
//        au.getUsuarios().add(juan);
//        au.getUsuarios().add(marco);
//        ac.getClases().add(gastro);
        String username = tf_user.getText();
        boolean entra = false;
        String clave = new String(pf_clave.getPassword());
        for (int i = 0; i < au.getUsuarios().size(); i++) {
            if (username.equals(au.getUsuarios().get(i).getNombreusuario())) {
                if (clave.equals(au.getUsuarios().get(i).getContra())) {
                    if (au.getUsuarios().get(i) instanceof Alumno) {
                        jf_inicioalumno.setLocationRelativeTo(this);
                        jf_inicioalumno.setExtendedState(MAXIMIZED_BOTH);
                        jf_inicioalumno.setVisible(true);
                        panel_inicioalum.setVisible(true);
                        Examenes_alum.setVisible(false);
                        jp_Verresualu.setVisible(false);
                        jp_cuadroalu.setVisible(false);
                        jf_tareas_alumno.setVisible(false);
                        tf_user.setText("");
                        pf_clave.setText("");
                        this.setVisible(false);
                        cualentra = i;
                        entra = true;
                        jl_usuario1.setText(username);
                        jl_correo1.setText(username + "@unitec.edu.fcb");
                        jl_clave1.setText("< No Visible >");
                    } else if (au.getUsuarios().get(i) instanceof Maestro) {

                        jf_iniciomaestro.setLocationRelativeTo(this);
                        jf_iniciomaestro.setExtendedState(MAXIMIZED_BOTH);
                        jf_iniciomaestro.setVisible(true);
                        tf_user.setText("");
                        pf_clave.setText("");
                        cualentra = i;
                        entra = true;
                        jl_usuario.setText(username);
                        jl_correo.setText(username + "@unitec.edu.fcb");
                        jl_clave.setText("< No Visible >");
                        jp_iniciomaestro.setVisible(true);
                        jp_crearExamen.setVisible(false);
                        Elim_Jp_examen.setVisible(false);
                        Cuadro_Notas.setVisible(false);
                        Resu_cadaex.setVisible(false);
                        crear_tarea.setVisible(false);
                        jf_mod_ex.setVisible(false);
                    } else if (au.getUsuarios().get(i) instanceof Registro) {
                        jf_inicioregistro.setLocationRelativeTo(this);
                        jf_inicioregistro.setExtendedState(MAXIMIZED_BOTH);
                        jf_inicioregistro.setVisible(true);
                        jp_modalumno.setVisible(false);
                        jp_modificarmaestros.setVisible(false);
                        jp_eliminarmaestro.setVisible(false);
                        jp_crearmaestro.setVisible(false);
                        jp_crearAlumno.setVisible(false);
                        jp_modificarclase.setVisible(false);
                        jp_EliminarClase.setVisible(false);
                        jp_crearclase.setVisible(false);
                        jp_crearregistro.setVisible(false);
                        jp_EliminarAlumno.setVisible(false);
                        jp_inicioregistro.setVisible(true);
                        jpanel_modregistro.setVisible(false);
                        jpanel_elimregistro.setVisible(false);
                        jp_asignaralumclase.setVisible(false);
                        Jp_asignarmaestroclase.setVisible(false);
                        tf_user.setText("");
                        pf_clave.setText("");
                        this.setVisible(false);
                        jf_inicioregistro.setLocationRelativeTo(this);
                        jf_inicioregistro.setExtendedState(MAXIMIZED_BOTH);
                        jf_inicioregistro.setVisible(true);
                        this.setVisible(false);
                        tf_user.setText("");
                        pf_clave.setText("");
                        entra = true;

                        jl_usuarioregistro.setText(username);
                        jl_correoregistro.setText(username + "@unitec.edu.fcb");
                        jl_claveregistro.setText("< No Visible >");

                    }
                    this.setVisible(false);

                }
            }
        }
        if (entra == false) {
            JOptionPane.showMessageDialog(this, "Usuario no encontrado", "Error", 2);
        }
        ch_maestros_registro.select(0);
        ch_alumnos_registro.select(0);
        ch_clases_registro.select(0);
        ch_registro_registro.select(0);
    }//GEN-LAST:event_jb_iniciarsesionMouseClicked

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked
        au.CargarArchivo();
        if (jf_idmaestronuevo.getText().isBlank() || jf_Sueldomaestronuevo.getText().isBlank() || jt_profesionmaestronuevo.getText().isBlank() || JT_Rolmaestronuevo.getText().isBlank() || jt_usermaestronuevo.getText().isBlank() || jt_contramaestronuevo.getText().isBlank() || jt_nombremaestronuevo.getText().isBlank()) {
            JOptionPane.showMessageDialog(jf_inicioregistro, "Hay minimo un espacio en blanco y eso no se puede", "Error", 2);
        } else if (jf_idmaestronuevo.getText().length() != 8) {
            JOptionPane.showMessageDialog(jf_inicioregistro, "El ID debe ser de 8 caracteres", "Error", 2);
        } else {
            boolean repe2 = false;
            for (int i = 0; i < au.getUsuarios().size(); i++) {
                if (au.getUsuarios().get(i) instanceof Maestro) {
                    if (Integer.parseInt(jf_idmaestronuevo.getText()) == ((Maestro) au.getUsuarios().get(i)).getId()) {
                        repe2 = true;
                    }
                }
            }
            if (repe2) {
                JOptionPane.showMessageDialog(jf_inicioregistro, "Ya hay un maestro con ese ID", "Error", 2);
                jf_idmaestronuevo.setText("");
            } else {
                int idnewmaestro = Integer.parseInt(jf_idmaestronuevo.getText());
                double Sueldomaestronuevo = Double.parseDouble(jf_Sueldomaestronuevo.getText());
                au.getUsuarios().add(new Maestro(idnewmaestro, jt_profesionmaestronuevo.getText(), JT_Rolmaestronuevo.getText(), Sueldomaestronuevo, jt_usermaestronuevo.getText(), jt_contramaestronuevo.getText(), jt_nombremaestronuevo.getText()));
                au.EscribirArchivo();
                au.CargarArchivo();
                JOptionPane.showMessageDialog(jf_inicioregistro, jt_nombremaestronuevo.getText() + " ha sido contratado");
                jf_idmaestronuevo.setText("");
                jf_Sueldomaestronuevo.setText("");
                jt_profesionmaestronuevo.setText("");
                JT_Rolmaestronuevo.setText("");
                jt_usermaestronuevo.setText("");
                jt_nombremaestronuevo.setText("");
                jt_contramaestronuevo.setText("");
            }

        }
    }//GEN-LAST:event_jButton1MouseClicked

    private void jButton6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton6MouseClicked
        au.CargarArchivo();
        if (jf_numcuentanuevoalumno.getText().isBlank() || jt_nombrealumnonuevo.getText().isBlank() || jt_useralumnonuevo.getText().isBlank() || jt_contraalumnonuevo.getText().isBlank() || jt_rolalumnonuevo.getText().isBlank() || jt_carreranuevoalumno.getText().isBlank()) {
            JOptionPane.showMessageDialog(jf_inicioregistro, "Hay minimo un espacio en blanco y eso no se puede", "Error", 2);
        } else if (jf_numcuentanuevoalumno.getText().length() != 8) {
            JOptionPane.showMessageDialog(jf_inicioregistro, "El numero de cuenta debe ser de 8 caracteres");
        } else {
            boolean repe3 = false;
            for (int i = 0; i < au.getUsuarios().size(); i++) {
                if (au.getUsuarios().get(i) instanceof Alumno) {
                    if (Integer.parseInt(jf_numcuentanuevoalumno.getText()) == ((Alumno) au.getUsuarios().get(i)).getNumcuenta()) {
                        repe3 = true;
                    }
                }
            }
            if (repe3) {
                JOptionPane.showMessageDialog(jf_inicioregistro, "Ya hay un alumno con ese numero de cuenta", "Error", 2);
                jf_numcuentanuevoalumno.setText("");
            } else {
                int numcuentanew = Integer.parseInt(jf_numcuentanuevoalumno.getText());
                au.getUsuarios().add(new Alumno(numcuentanew, jt_carreranuevoalumno.getText(), jt_rolalumnonuevo.getText(), jt_useralumnonuevo.getText(), jt_contraalumnonuevo.getText(), jt_nombrealumnonuevo.getText()));
                au.EscribirArchivo();
                au.CargarArchivo();
                JOptionPane.showMessageDialog(jf_inicioregistro, jt_nombrealumnonuevo.getText() + " ha sido matriculado");
                jf_numcuentanuevoalumno.setText("");
                jt_useralumnonuevo.setText("");
                jt_rolalumnonuevo.setText("");
                jt_nombrealumnonuevo.setText("");
                jt_contraalumnonuevo.setText("");
                jt_carreranuevoalumno.setText("");
            }
        }
    }//GEN-LAST:event_jButton6MouseClicked

    private void jb_cerrarsesionregistroMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jb_cerrarsesionregistroMouseClicked
        jf_inicioregistro.setVisible(false);
        jp_inicioregistro.setVisible(true);
        this.setVisible(true);
    }//GEN-LAST:event_jb_cerrarsesionregistroMouseClicked

    private void jb_crearclasenuevaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jb_crearclasenuevaMouseClicked
        ac.CargarArchivo();
        if (jt_nombreclasenueva.getText().isBlank() || jf_idclasenueva.getText().isBlank() || anioclasenueva.getDate().equals(null)) {
            JOptionPane.showMessageDialog(jf_inicioregistro, "Hay minimo un espacio en blanco", "Error", 2);
        } else {
            boolean repe = false;
            for (int i = 0; i < ac.getClases().size(); i++) {
                if (Integer.parseInt(jf_idclasenueva.getText()) == ac.getClases().get(i).getId()) {
                    repe = true;
                }
            }
            if (repe) {
                JOptionPane.showMessageDialog(jf_inicioregistro, "Ya hay una clase con ese ID", "Error", 2);
                jf_idclasenueva.setText("");
            } else {
                int idclasenew = Integer.parseInt(jf_idclasenueva.getText());
                int hora2 = (Integer) js_horaclasenueva.getValue();
                int minutos2 = (Integer) js_minutoclasenueva.getValue();
                String hour = ((hora2 <= 9 ? "0" : "") + hora2 + ":" + (minutos2 <= 9 ? "0" : "") + minutos2 + " " + (String) jc_tipohoraclasenueva.getSelectedItem());
                ac.getClases().add(new Clase(idclasenew, (Integer) js_uvclasenueva.getValue(), (Integer) js_semestreclasenueva.getValue(), (Integer) js_Periodoclasenueva.getValue(), anioclasenueva.getDate(), jt_nombreclasenueva.getText(), hour));
                ac.EscribirArchivo();
                ac.CargarArchivo();
                JOptionPane.showMessageDialog(jf_inicioregistro, "Se ha añadido la clase " + jt_nombreclasenueva.getText());
                jt_nombreclasenueva.setText("");
                jf_idclasenueva.setText("");
                anioclasenueva.setDate(null);
                js_horaclasenueva.setValue(1);
                js_minutoclasenueva.setValue(0);
                jc_tipohoraclasenueva.setSelectedIndex(0);
                js_semestreclasenueva.setValue(1);
                js_Periodoclasenueva.setValue(1);
                js_uvclasenueva.setValue(1);
            }
        }
    }//GEN-LAST:event_jb_crearclasenuevaMouseClicked

    private void JB_MODIFICARMAESTROMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JB_MODIFICARMAESTROMouseClicked
        au.CargarArchivo();
        if (jl_maestrosamodificar.isSelectionEmpty()) {
            JOptionPane.showMessageDialog(jf_inicioregistro, "Debe elegir a que maestro modificar", "Error", 2);
        } else {
            boolean semodifico = false;
            int cualeligio = jl_maestrosamodificar.getSelectedIndex();
            for (int i = 0; i < au.getUsuarios().size(); i++) {
                if (au.getUsuarios().get(i) instanceof Maestro) {
                    if (((Maestro) au.getUsuarios().get(i)).getId() == maestrosmodificadores.get(cualeligio).getId()) {
                        if (!jt_modificarnombremaestro.getText().isBlank()) {
                            ((Maestro) au.getUsuarios().get(i)).setNombre(jt_modificarnombremaestro.getText());
                            semodifico = true;
                        }
                        if (!jt_modificarusermaestro.getText().isBlank()) {
                            ((Maestro) au.getUsuarios().get(i)).setNombreusuario(jt_modificarusermaestro.getText());
                            semodifico = true;
                        }
                        if (!jt_modificarcontramaestro.getText().isBlank()) {
                            ((Maestro) au.getUsuarios().get(i)).setContra(jt_modificarcontramaestro.getText());
                            semodifico = true;
                        }
                        if (!jf_modificaridmaestro.getText().isBlank()) {
                            if (jf_modificaridmaestro.getText().length() != 8) {
                                JOptionPane.showMessageDialog(jf_inicioregistro, "El ID debe ser de 8 caracteres, se quedara con el mismo", "Error", 2);
                            } else {
                                ((Maestro) au.getUsuarios().get(i)).setId(Integer.parseInt(jf_modificaridmaestro.getText()));
                                semodifico = true;
                            }
                        }
                        if (!jt_ModificarProfesionMaestro.getText().isBlank()) {
                            ((Maestro) au.getUsuarios().get(i)).setProfesion(jt_ModificarProfesionMaestro.getText());
                            semodifico = true;
                        }
                        if (!jt_ModificarRolMaestro.getText().isBlank()) {
                            ((Maestro) au.getUsuarios().get(i)).setRol(jt_ModificarRolMaestro.getText());
                            semodifico = true;
                        }
                        if (!jf_ModificarSueldoMaestro.getText().isBlank()) {
                            ((Maestro) au.getUsuarios().get(i)).setSueldo(Double.parseDouble(jf_ModificarSueldoMaestro.getText()));
                            semodifico = true;
                        }
                    }
                }
            }
            au.EscribirArchivo();
            au.CargarArchivo();
            if (semodifico) {
                jt_modificarnombremaestro.setText("");
                jt_modificarusermaestro.setText("");
                jt_modificarcontramaestro.setText("");
                jf_modificaridmaestro.setText("");
                jt_ModificarProfesionMaestro.setText("");
                jt_ModificarRolMaestro.setText("");
                jf_ModificarSueldoMaestro.setText("");
                llenarlistamodmaestros();
                JOptionPane.showMessageDialog(jf_inicioregistro, "Se modifico correctamente");
            }

        }
    }//GEN-LAST:event_JB_MODIFICARMAESTROMouseClicked

    private void jButton7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton7MouseClicked
        au.CargarArchivo();
        if (jlista_modalumnos.isSelectionEmpty()) {
            JOptionPane.showMessageDialog(jf_inicioregistro, "Debe elegir a que alumno modificar", "Error", 2);
        } else {
            boolean semodifico2 = false;
            int cualeligio2 = jlista_modalumnos.getSelectedIndex();
            for (int i = 0; i < au.getUsuarios().size(); i++) {
                if (au.getUsuarios().get(i) instanceof Alumno) {
                    if (((Alumno) au.getUsuarios().get(i)).getNumcuenta() == alumnosmodificadores.get(cualeligio2).getNumcuenta()) {
                        if (!md_NuevoNombreAlumno.getText().isBlank()) {
                            for (int j = 0; j < ac.getClases().size(); j++) {
                                for (int k = 0; k < ac.getClases().get(j).getAlumnosreciben().size(); k++) {
                                    if (ac.getClases().get(j).getAlumnosreciben().get(k).getNumcuenta() == alumnosmodificadores.get(cualeligio2).getNumcuenta()) {
                                        ((Alumno) ac.getClases().get(j).getAlumnosreciben().get(k)).setNombre(md_NuevoNombreAlumno.getText());
                                    }
                                }
                            }
                            ((Alumno) au.getUsuarios().get(i)).setNombre(md_NuevoNombreAlumno.getText());
                            semodifico2 = true;
                        }
                        if (!md_NuevoUserAlumno.getText().isBlank()) {
                            for (int j = 0; j < ac.getClases().size(); j++) {
                                for (int k = 0; k < ac.getClases().get(j).getAlumnosreciben().size(); k++) {
                                    if (ac.getClases().get(j).getAlumnosreciben().get(k).getNumcuenta() == alumnosmodificadores.get(cualeligio2).getNumcuenta()) {
                                        ((Alumno) ac.getClases().get(j).getAlumnosreciben().get(k)).setNombreusuario(md_NuevoUserAlumno.getText());
                                    }
                                }
                            }
                            ((Alumno) au.getUsuarios().get(i)).setNombreusuario(md_NuevoUserAlumno.getText());
                            semodifico2 = true;
                        }
                        if (!md_NuevaContraAlumno.getText().isBlank()) {
                            for (int j = 0; j < ac.getClases().size(); j++) {
                                for (int k = 0; k < ac.getClases().get(j).getAlumnosreciben().size(); k++) {
                                    if (ac.getClases().get(j).getAlumnosreciben().get(k).getNumcuenta() == alumnosmodificadores.get(cualeligio2).getNumcuenta()) {
                                        ((Alumno) ac.getClases().get(j).getAlumnosreciben().get(k)).setContra(md_NuevaContraAlumno.getText());
                                    }
                                }
                            }
                            ((Alumno) au.getUsuarios().get(i)).setContra(md_NuevaContraAlumno.getText());
                            semodifico2 = true;
                        }
                        if (!md_NuevoNumCuentaAlumno.getText().isBlank()) {
                            if (md_NuevoNumCuentaAlumno.getText().length() != 8) {
                                JOptionPane.showMessageDialog(jf_inicioregistro, "El numero de cuenta debe ser de 8 caracteres, se quedara con el mismo", "Error", 2);
                            } else {
                                for (int j = 0; j < ac.getClases().size(); j++) {
                                    for (int k = 0; k < ac.getClases().get(j).getAlumnosreciben().size(); k++) {
                                        if (ac.getClases().get(j).getAlumnosreciben().get(k).getNumcuenta() == alumnosmodificadores.get(cualeligio2).getNumcuenta()) {
                                            ((Alumno) ac.getClases().get(j).getAlumnosreciben().get(k)).setNumcuenta(Integer.parseInt(md_NuevoNumCuentaAlumno.getText()));
                                        }
                                    }
                                }
                                ((Alumno) au.getUsuarios().get(i)).setNumcuenta(Integer.parseInt(md_NuevoNumCuentaAlumno.getText()));
                                semodifico2 = true;
                            }
                        }
                        if (!md_NuevaCarreraAlumno.getText().isBlank()) {
                            for (int j = 0; j < ac.getClases().size(); j++) {
                                for (int k = 0; k < ac.getClases().get(j).getAlumnosreciben().size(); k++) {
                                    if (ac.getClases().get(j).getAlumnosreciben().get(k).getNumcuenta() == alumnosmodificadores.get(cualeligio2).getNumcuenta()) {
                                        ((Alumno) ac.getClases().get(j).getAlumnosreciben().get(k)).setCarrera(md_NuevaCarreraAlumno.getText());
                                    }
                                }
                            }
                            ((Alumno) au.getUsuarios().get(i)).setCarrera(md_NuevaCarreraAlumno.getText());
                            semodifico2 = true;
                        }
                        if (!md_NuevoRolAlumno.getText().isBlank()) {
                            for (int j = 0; j < ac.getClases().size(); j++) {
                                for (int k = 0; k < ac.getClases().get(j).getAlumnosreciben().size(); k++) {
                                    if (ac.getClases().get(j).getAlumnosreciben().get(k).getNumcuenta() == alumnosmodificadores.get(cualeligio2).getNumcuenta()) {
                                        ((Alumno) ac.getClases().get(j).getAlumnosreciben().get(k)).setRol(md_NuevoRolAlumno.getText());
                                    }
                                }
                            }
                            ((Alumno) au.getUsuarios().get(i)).setRol(md_NuevoRolAlumno.getText());
                            semodifico2 = true;
                        }

                    }
                }
            }
            llenarlistamodalumnos();
            llenarlistadeclases();
            au.EscribirArchivo();
            au.CargarArchivo();
            if (semodifico2) {
                md_NuevaCarreraAlumno.setText("");
                md_NuevaContraAlumno.setText("");
                md_NuevoNombreAlumno.setText("");
                md_NuevoNumCuentaAlumno.setText("");
                md_NuevoRolAlumno.setText("");
                md_NuevoUserAlumno.setText("");
                llenarlistamodalumnos();
                JOptionPane.showMessageDialog(jf_inicioregistro, "Se modifico correctamente");
            }
        }
    }//GEN-LAST:event_jButton7MouseClicked

    private void jb_modificarclaseMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jb_modificarclaseMouseClicked
        ac.CargarArchivo();
        if (jlista_clasesmod.isSelectionEmpty()) {
            JOptionPane.showMessageDialog(jf_inicioregistro, "Debe elegir que clase quiere modificar", "Error", 2);
        } else {
            boolean semodifico3 = false;
            int cualeligio3 = jlista_clasesmod.getSelectedIndex();
            for (int i = 0; i < ac.getClases().size(); i++) {
                if (ac.getClases().get(i).getId() == clasesmodificadoras.get(cualeligio3).getId()) {
                    if (!md1_NombreNuevoClase.getText().isBlank()) {
                        ac.getClases().get(i).setNombreclase(md1_NombreNuevoClase.getText());
                        semodifico3 = true;
                    }
                    if (!md1_IDNuevoClase.getText().isBlank()) {
                        ac.getClases().get(i).setId(Integer.parseInt(md1_IDNuevoClase.getText()));
                        semodifico3 = true;
                    }
                    if (md1_AnioNuevoClase.getDate() != null) {
                        ac.getClases().get(i).setAnio(md1_AnioNuevoClase.getDate());
                    }
                    int hora3 = (Integer) md1_HoraNuevoClase.getValue();
                    int minutos3 = (Integer) md1_MinutosNuevoClase.getValue();
                    String hhh = ((hora3 <= 9 ? "0" : "") + hora3 + ":" + (minutos3 <= 9 ? "0" : "") + minutos3 + " " + (String) md1_TipoHoraNuevoClase.getSelectedItem());
                    ac.getClases().get(i).setHora(hhh);
                    ac.getClases().get(i).setSemestre((Integer) md1_SemestreNuevoClase.getValue());
                    ac.getClases().get(i).setPeriodo((Integer) md1_PeriodoNuevoClase.getValue());
                    ac.getClases().get(i).setUv((Integer) md1_UVNuevoClase.getValue());
                }
            }
            ac.EscribirArchivo();
            ac.CargarArchivo();
            if (semodifico3) {
                md1_NombreNuevoClase.setText("");
                md1_IDNuevoClase.setText("");
                md1_AnioNuevoClase.setDate(null);
                md1_HoraNuevoClase.setValue(1);
                md1_MinutosNuevoClase.setValue(0);
                md1_TipoHoraNuevoClase.setSelectedIndex(0);
                md1_SemestreNuevoClase.setValue(1);
                md1_PeriodoNuevoClase.setValue(1);
                md1_UVNuevoClase.setValue(1);
                llenarlistadeclases();
                JOptionPane.showMessageDialog(jf_inicioregistro, "Se modifico correctamente");
            }
        }
    }//GEN-LAST:event_jb_modificarclaseMouseClicked

    private void jlista_clasesmodMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlista_clasesmodMouseClicked
        if (!jlista_clasesmod.isSelectionEmpty()) {
            int cual = jlista_clasesmod.getSelectedIndex();
            md1_SemestreNuevoClase.setValue(clasesmodificadoras.get(cual).getSemestre());
            md1_PeriodoNuevoClase.setValue(clasesmodificadoras.get(cual).getPeriodo());
            md1_UVNuevoClase.setValue(clasesmodificadoras.get(cual).getUv());
            int hora67 = Integer.parseInt(ac.getClases().get(cual).getHora().charAt(0) + "" + ac.getClases().get(cual).getHora().charAt(1));
            int minuto67 = Integer.parseInt(ac.getClases().get(cual).getHora().charAt(3) + "" + ac.getClases().get(cual).getHora().charAt(4));
            String tipohora67 = ac.getClases().get(cual).getHora().charAt(6) + "" + ac.getClases().get(cual).getHora().charAt(7);
            md1_HoraNuevoClase.setValue(hora67);
            md1_MinutosNuevoClase.setValue(minuto67);
            if (tipohora67.equalsIgnoreCase("AM")) {
                md1_TipoHoraNuevoClase.setSelectedIndex(0);
            } else {
                md1_TipoHoraNuevoClase.setSelectedIndex(1);
            }
        }
    }//GEN-LAST:event_jlista_clasesmodMouseClicked

    private void jb_eliminarMaestroMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jb_eliminarMaestroMouseClicked
        au.CargarArchivo();
        ac.CargarArchivo();
        if (jlista_eliminarmister.isSelectionEmpty()) {
            JOptionPane.showMessageDialog(jf_inicioregistro, "Debe elegir al maestro que quiere eliminar", "Error", 2);
        } else {
            for (int i = 0; i < ac.getClases().size(); i++) {
                if (ac.getClases().get(i).getMister() != null && ac.getClases().get(jlista_eliminarmister.getSelectedIndex()).getMister() != null) {
                    if (ac.getClases().get(i).getMister().getId() == ac.getClases().get(jlista_eliminarmister.getSelectedIndex()).getMister().getId()) {
                        ac.getClases().get(i).setMister(null);
                    }
                }

            }
            for (int i = 0; i < au.getUsuarios().size(); i++) {
                if (au.getUsuarios().get(i) instanceof Alumno) {
                    for (int q = 0; q < ((Alumno) au.getUsuarios().get(i)).getClases().size(); q++) {
                        if (((Alumno) au.getUsuarios().get(i)).getClases().get(q).getMister() == null) {
                        } else {
                            if (((Alumno) au.getUsuarios().get(i)).getClases().get(q).getMister().getId() == maestrosmodificadores.get(jlista_eliminarmister.getSelectedIndex()).getId()) {
                                ((Alumno) au.getUsuarios().get(i)).getClases().get(q).setMister(null);
                            }
                        }
                    }
                }
            }
            for (int i = 0; i < au.getUsuarios().size(); i++) {
                if (au.getUsuarios().get(i) instanceof Maestro) {
                    if (((Maestro) au.getUsuarios().get(i)).getId() == maestrosmodificadores.get(jlista_eliminarmister.getSelectedIndex()).getId()) {
                        for (int j = 0; j < ((Maestro) au.getUsuarios().get(i)).getClasesense().size(); j++) {
                            ((Maestro) au.getUsuarios().get(i)).getClasesense().get(j).setMister(null);
                        }
                        au.getUsuarios().remove(i);
                    }
                }
            }

            LlenarListaElimMaestro();
            llenarlistamodalumnos();
            llenarlistamodmaestros();
            LlenarListaEliminarAlumno();
            LlenarListaElimClase();
            llenarlistadeclases();
            au.EscribirArchivo();
            au.CargarArchivo();
            ac.EscribirArchivo();
            ac.CargarArchivo();
            JOptionPane.showMessageDialog(jf_inicioregistro, "Se elimino el maestro correctamente");
        }
    }//GEN-LAST:event_jb_eliminarMaestroMouseClicked

    private void jb_eliminarMaestro1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jb_eliminarMaestro1MouseClicked
        au.CargarArchivo();
        ac.CargarArchivo();
        if (jlista_eliminarAlumno.isSelectionEmpty()) {
            JOptionPane.showMessageDialog(jf_inicioregistro, "Debe elegir al alumno que quiere eliminar", "Error", 2);
        } else {
            for (int i = 0; i < au.getUsuarios().size(); i++) {
                if (au.getUsuarios().get(i) instanceof Maestro) {
                    for (int j = 0; j < ((Maestro) au.getUsuarios().get(i)).getClasesense().size(); j++) {
                        for (int k = 0; k < ((Maestro) au.getUsuarios().get(i)).getClasesense().get(j).getAlumnosreciben().size(); k++) {
                            if (((Maestro) au.getUsuarios().get(i)).getClasesense().get(j).getAlumnosreciben().get(k).getNumcuenta() == alumnosmodificadores.get(jlista_eliminarAlumno.getSelectedIndex()).getNumcuenta()) {
                                ((Maestro) au.getUsuarios().get(i)).getClasesense().get(j).getAlumnosreciben().remove(k);
                            }
                        }
                    }
                }
            }
            for (int i = 0; i < ac.getClases().size(); i++) {
                for (int j = 0; j < ac.getClases().get(i).getAlumnosreciben().size(); j++) {
                    if (ac.getClases().get(i).getAlumnosreciben().get(j).getNumcuenta() == alumnosmodificadores.get(jlista_eliminarAlumno.getSelectedIndex()).getNumcuenta()) {
                        ac.getClases().get(i).getAlumnosreciben().remove(j);
                    }
                }
            }
            for (int i = 0; i < au.getUsuarios().size(); i++) {
                if (au.getUsuarios().get(i) instanceof Alumno) {
                    if (((Alumno) au.getUsuarios().get(i)).getNumcuenta() == alumnosmodificadores.get(jlista_eliminarAlumno.getSelectedIndex()).getNumcuenta()) {
                        for (int j = 0; j < ((Alumno) au.getUsuarios().get(i)).getClases().size(); j++) {
                            for (int k = 0; k < ((Alumno) au.getUsuarios().get(i)).getClases().get(j).getAlumnosreciben().size(); k++) {
                                if (((Alumno) au.getUsuarios().get(i)).getNumcuenta() == ((Alumno) au.getUsuarios().get(i)).getClases().get(j).getAlumnosreciben().get(k).getNumcuenta()) {
                                    ((Alumno) au.getUsuarios().get(i)).getClases().get(j).getAlumnosreciben().remove(k);
                                }
                            }
                        }
                        au.getUsuarios().remove(i);
                    }
                }
            }

            LlenarListaElimMaestro();
            llenarlistamodalumnos();
            LlenarListaEliminarAlumno();
            llenarlistamodmaestros();
            LlenarListaElimClase();
            llenarlistadeclases();
            au.EscribirArchivo();
            au.CargarArchivo();
            ac.EscribirArchivo();
            ac.CargarArchivo();
            JOptionPane.showMessageDialog(jf_inicioregistro, "Se elimino el alumno correctamente");
        }
    }//GEN-LAST:event_jb_eliminarMaestro1MouseClicked

    private void jb_eliminarMaestro2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jb_eliminarMaestro2MouseClicked
        au.CargarArchivo();
        ac.CargarArchivo();
        if (jlista_eliminarClase.isSelectionEmpty()) {
            JOptionPane.showMessageDialog(jf_inicioregistro, "Debe elegir la clase que quiere eliminar", "Error", 2);
        } else {
            for (int i = 0; i < au.getUsuarios().size(); i++) {
                if (au.getUsuarios().get(i) instanceof Alumno) {
                    for (int j = 0; j < ((Alumno) au.getUsuarios().get(i)).getClases().size(); j++) {
                        if (((Alumno) au.getUsuarios().get(i)).getClases().get(j).getId() == clasesmodificadoras.get(jlista_eliminarClase.getSelectedIndex()).getId()) {
                            ((Alumno) au.getUsuarios().get(i)).getClases().remove(j);
                        }
                    }
                } else if (au.getUsuarios().get(i) instanceof Maestro) {
                    for (int j = 0; j < ((Maestro) au.getUsuarios().get(i)).getClasesense().size(); j++) {
                        if (((Maestro) au.getUsuarios().get(i)).getClasesense().get(j).getId() == clasesmodificadoras.get(jlista_eliminarClase.getSelectedIndex()).getId()) {
                            ((Maestro) au.getUsuarios().get(i)).getClasesense().remove(j);
                        }
                    }
                }
            }
            for (int i = 0; i < ac.getClases().size(); i++) {
                if (ac.getClases().get(i).getId() == clasesmodificadoras.get(jlista_eliminarClase.getSelectedIndex()).getId()) {
                    ac.getClases().remove(i);
                }
            }

            LlenarListaElimMaestro();
            llenarlistamodalumnos();
            LlenarListaEliminarAlumno();
            llenarlistamodmaestros();
            llenarlistadeclases();
            LlenarListaElimClase();
            au.EscribirArchivo();
            au.CargarArchivo();
            ac.EscribirArchivo();
            ac.CargarArchivo();
            JOptionPane.showMessageDialog(jf_inicioregistro, "Se elimino la clase correctamente");
        }
    }//GEN-LAST:event_jb_eliminarMaestro2MouseClicked

    private void ch_registro_registroItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_ch_registro_registroItemStateChanged
        ch_maestros_registro.select(0);
        ch_alumnos_registro.select(0);
        ch_clases_registro.select(0);
        if (ch_registro_registro.getSelectedItem().equalsIgnoreCase("Ingresar Registrante")) {
            jp_crearregistro.setVisible(true);
            jp_eliminarmaestro.setVisible(false);
            jp_inicioregistro.setVisible(false);
            jp_modificarmaestros.setVisible(false);
            jp_modalumno.setVisible(false);
            jp_crearmaestro.setVisible(false);
            jp_crearAlumno.setVisible(false);
            jp_crearclase.setVisible(false);
            jp_modificarclase.setVisible(false);
            jp_EliminarAlumno.setVisible(false);
            jp_EliminarClase.setVisible(false);
            jpanel_modregistro.setVisible(false);
            jpanel_elimregistro.setVisible(false);
            Jp_asignarmaestroclase.setVisible(false);

            jButton1.setVisible(true);
            jt_userregistronuevo.setText("");
            jt_contraregistronuevo.setText("");
            jt_nombreregistronuevo.setText("");

        } else if (ch_registro_registro.getSelectedItem().equalsIgnoreCase("Modificar Registrante")) {
            jp_crearregistro.setVisible(false);
            jp_eliminarmaestro.setVisible(false);
            jp_inicioregistro.setVisible(false);
            jp_modalumno.setVisible(false);
            jp_crearmaestro.setVisible(false);
            jp_crearAlumno.setVisible(false);
            jp_modificarclase.setVisible(false);
            jp_crearclase.setVisible(false);
            llenarlistamodregistro();
            jp_modificarmaestros.setVisible(false);
            jp_EliminarAlumno.setVisible(false);
            jp_EliminarClase.setVisible(false);
            jpanel_elimregistro.setVisible(false);
            jpanel_modregistro.setVisible(true);
            Jp_asignarmaestroclase.setVisible(false);

        } else if (ch_registro_registro.getSelectedItem().equalsIgnoreCase("Eliminar Registrante")) {
            LlenarListaElimRegistro();
            jpanel_elimregistro.setVisible(true);
            jp_crearregistro.setVisible(false);
            jp_eliminarmaestro.setVisible(false);
            jp_inicioregistro.setVisible(false);
            jp_modificarmaestros.setVisible(false);
            jp_modalumno.setVisible(false);
            jp_modificarclase.setVisible(false);
            jp_crearmaestro.setVisible(false);
            jp_crearAlumno.setVisible(false);
            jp_crearclase.setVisible(false);
            jp_EliminarAlumno.setVisible(false);
            jp_EliminarClase.setVisible(false);
            jpanel_modregistro.setVisible(false);
            Jp_asignarmaestroclase.setVisible(false);

        } else if (ch_registro_registro.getSelectedItem().equalsIgnoreCase("Inicio")) {
            jp_crearregistro.setVisible(false);
            jp_eliminarmaestro.setVisible(false);
            jp_inicioregistro.setVisible(true);
            jp_modificarmaestros.setVisible(false);
            jp_modalumno.setVisible(false);
            jp_modificarclase.setVisible(false);
            jp_crearmaestro.setVisible(false);
            jp_crearAlumno.setVisible(false);
            jp_crearclase.setVisible(false);
            jp_EliminarAlumno.setVisible(false);
            jp_EliminarClase.setVisible(false);
            jpanel_modregistro.setVisible(false);
            jpanel_elimregistro.setVisible(false);
            Jp_asignarmaestroclase.setVisible(false);
        }
    }//GEN-LAST:event_ch_registro_registroItemStateChanged

    private void jb_crearregistroMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jb_crearregistroMouseClicked
        au.CargarArchivo();
        boolean habra = false;
        for (int i = 0; i < au.getUsuarios().size(); i++) {
            if (au.getUsuarios().get(i).getNombreusuario().equals(jt_userregistronuevo.getText())) {
                habra = true;
            }
        }
        if (habra) {
            JOptionPane.showMessageDialog(jf_inicioregistro, "Ya hay un usuario con ese username", "Error", 2);
        } else {
            au.getUsuarios().add(new Registro(jt_userregistronuevo.getText(), jt_contraregistronuevo.getText(), jt_nombreregistronuevo.getText()));
            au.EscribirArchivo();
            au.CargarArchivo();
            JOptionPane.showMessageDialog(jf_inicioregistro, "Usuario de registro ingresado");
            jt_userregistronuevo.setText("");
            jt_contraregistronuevo.setText("");
            jt_nombreregistronuevo.setText("");
        }

    }//GEN-LAST:event_jb_crearregistroMouseClicked

    private void jb_crearregistro1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jb_crearregistro1MouseClicked
        au.CargarArchivo();
        if (jlista_ModificarRegistro.isSelectionEmpty()) {
            JOptionPane.showMessageDialog(jf_inicioregistro, "Debe elegir que usuario de registro quiere modificar", "Error", 2);
        } else {
            boolean semodifico4 = false;
            int cualeligio4 = jlista_ModificarRegistro.getSelectedIndex();
            for (int i = 0; i < au.getUsuarios().size(); i++) {
                if (au.getUsuarios().get(i) instanceof Registro) {
                    if ((au.getUsuarios().get(i).getNombreusuario().equals(registrosmodificadores.get(cualeligio4).getNombreusuario()))) {
                        if (!jt_nombreregistromod.getText().isBlank()) {
                            au.getUsuarios().get(i).setNombre(jt_nombreregistromod.getText());
                            semodifico4 = true;
                        }
                        if (!jt_userregistromod.getText().isBlank()) {
                            boolean hay = false;
                            for (int j = 0; j < au.getUsuarios().size(); j++) {
                                if (au.getUsuarios().get(j).getNombreusuario().equals(jt_userregistromod.getText())) {
                                    hay = true;
                                }
                            }
                            if (hay) {
                                JOptionPane.showMessageDialog(jf_inicioregistro, "Ya hay un usuario con ese username, se quedara con el actual", "Error", 2);
                            } else {
                                au.getUsuarios().get(i).setNombreusuario(jt_userregistromod.getText());
                                semodifico4 = true;
                            }
                        }
                        if (!jt_contraregistromod.getText().isBlank()) {
                            au.getUsuarios().get(i).setContra(jt_contraregistromod.getText());
                            semodifico4 = true;
                        }
                    }
                }
            }
            au.EscribirArchivo();
            au.CargarArchivo();
            if (semodifico4) {
                jt_nombreregistromod.setText("");
                jt_userregistromod.setText("");
                jt_contraregistromod.setText("");
                llenarlistamodregistro();
                JOptionPane.showMessageDialog(jf_inicioregistro, "Se modifico correctamente");
            }
        }
    }//GEN-LAST:event_jb_crearregistro1MouseClicked

    private void jb_eliminarRegistroMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jb_eliminarRegistroMouseClicked
        au.CargarArchivo();
        if (jlista_eliminarRegistro.isSelectionEmpty()) {
            JOptionPane.showMessageDialog(jf_inicioregistro, "Debe elegir al usuario que quiere eliminar", "Error", 2);
        } else {
            boolean siesta = false;
            if (registrosmodificadores.get(jlista_eliminarRegistro.getSelectedIndex()).getNombreusuario().equals(jl_usuarioregistro.getText())) {
                siesta = true;
            }
            for (int i = 0; i < au.getUsuarios().size(); i++) {
                if (au.getUsuarios().get(i) instanceof Registro) {
                    if (au.getUsuarios().get(i).getNombreusuario().equals(registrosmodificadores.get(jlista_eliminarRegistro.getSelectedIndex()).getNombreusuario())) {
                        au.getUsuarios().remove(i);
                    }
                }
            }
            LlenarListaElimRegistro();
            if (siesta) {
                jf_inicioregistro.setVisible(false);
                this.setVisible(true);
                JOptionPane.showMessageDialog(jf_inicioregistro, "Lo siento, se borro su cuenta, bye");
            }

            JOptionPane.showMessageDialog(jf_inicioregistro, "Se elimino el usuario correctamente");
            au.EscribirArchivo();
            au.CargarArchivo();

        }
    }//GEN-LAST:event_jb_eliminarRegistroMouseClicked

    private void jlista_clasesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlista_clasesMouseClicked
        if (!jlista_clases.isSelectionEmpty()) {
            DefaultTableModel modelotabla = (DefaultTableModel) jtable_alumnosenclase.getModel();
            modelotabla.getDataVector().removeAllElements();
            jtable_alumnosenclase.updateUI();
            llenarlistadeclases();
            llenarlistamodalumnos();
            for (int i = 0; i < ac.getClases().get(jlista_clases.getSelectedIndex()).getAlumnosreciben().size(); i++) {
                String[] info = {"" + ac.getClases().get(jlista_clases.getSelectedIndex()).getAlumnosreciben().get(i).getNumcuenta(),
                    ac.getClases().get(jlista_clases.getSelectedIndex()).getAlumnosreciben().get(i).getNombre(),
                    ac.getClases().get(jlista_clases.getSelectedIndex()).getAlumnosreciben().get(i).getCarrera(),
                    ac.getClases().get(jlista_clases.getSelectedIndex()).getAlumnosreciben().get(i).getNombreusuario()};
                modelotabla.addRow(info);
            }
        }
    }//GEN-LAST:event_jlista_clasesMouseClicked

    private void jButton3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton3MouseClicked
        au.CargarArchivo();
        ac.CargarArchivo();

        if (jlista_alumnosag.isSelectionEmpty()) {
            JOptionPane.showMessageDialog(jf_inicioregistro, "Debe elegir un alumno", "Error", 2);
        } else if (jlista_clases.isSelectionEmpty()) {
            JOptionPane.showMessageDialog(jf_inicioregistro, "Debe elegir una clase", "Error", 2);
        } else {
            boolean yaesta = false;
            for (int i = 0; i < ac.getClases().get(jlista_clases.getSelectedIndex()).getAlumnosreciben().size(); i++) {
                if (ac.getClases().get(jlista_clases.getSelectedIndex()).getAlumnosreciben().get(i).getNumcuenta() == alumnosmodificadores.get(jlista_alumnosag.getSelectedIndex()).getNumcuenta()) {
                    yaesta = true;
                }
            }
            if (yaesta) {
                JOptionPane.showMessageDialog(jf_inicioregistro, "Este alumno ya esta en la clase", "Error", 2);
            } else {
                for (int i = 0; i < au.getUsuarios().size(); i++) {
                    if (au.getUsuarios().get(i) instanceof Alumno) {
                        if (((Alumno) au.getUsuarios().get(i)).getNumcuenta() == alumnosmodificadores.get(jlista_alumnosag.getSelectedIndex()).getNumcuenta()) {
                            ((Alumno) au.getUsuarios().get(i)).getClases().add(ac.getClases().get(jlista_clases.getSelectedIndex()));
                        }
                    }
                }
                ac.getClases().get(jlista_clases.getSelectedIndex()).getAlumnosreciben().add(alumnosmodificadores.get(jlista_alumnosag.getSelectedIndex()));
                DefaultTableModel modelotabla = (DefaultTableModel) jtable_alumnosenclase.getModel();
                modelotabla.getDataVector().removeAllElements();
                jtable_alumnosenclase.updateUI();
                for (int i = 0; i < ac.getClases().get(jlista_clases.getSelectedIndex()).getAlumnosreciben().size(); i++) {
                    String[] info = {"" + ac.getClases().get(jlista_clases.getSelectedIndex()).getAlumnosreciben().get(i).getNumcuenta(),
                        ac.getClases().get(jlista_clases.getSelectedIndex()).getAlumnosreciben().get(i).getNombre(),
                        ac.getClases().get(jlista_clases.getSelectedIndex()).getAlumnosreciben().get(i).getCarrera(),
                        ac.getClases().get(jlista_clases.getSelectedIndex()).getAlumnosreciben().get(i).getNombreusuario()};
                    modelotabla.addRow(info);
                }
            }
            LlenarListaElimMaestro();
            llenarlistamodalumnos();
            LlenarListaEliminarAlumno();
            llenarlistamodmaestros();
            llenarlistadeclases();
            LlenarListaElimClase();
            au.EscribirArchivo();
            au.CargarArchivo();
            ac.EscribirArchivo();
            ac.CargarArchivo();
        }
    }//GEN-LAST:event_jButton3MouseClicked

    private void jlista_maestroasigMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlista_maestroasigMouseClicked
        if (!jlista_maestroasig.isSelectionEmpty()) {
            DefaultTableModel modelotablilla2 = (DefaultTableModel) jtable_maestroenclase.getModel();
            modelotablilla2.getDataVector().removeAllElements();
            jtable_maestroenclase.updateUI();
            for (int i = 0; i < maestrosmodificadores.get(jlista_maestroasig.getSelectedIndex()).getClasesense().size(); i++) {
                String[] data = {"" + maestrosmodificadores.get(jlista_maestroasig.getSelectedIndex()).getClasesense().get(i).getId(),
                    maestrosmodificadores.get(jlista_maestroasig.getSelectedIndex()).getClasesense().get(i).getNombreclase(),
                    "" + maestrosmodificadores.get(jlista_maestroasig.getSelectedIndex()).getClasesense().get(i).getUv(),
                    maestrosmodificadores.get(jlista_maestroasig.getSelectedIndex()).getClasesense().get(i).getHora()};
                modelotablilla2.addRow(data);
            }
        }

    }//GEN-LAST:event_jlista_maestroasigMouseClicked

    private void jButton8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton8MouseClicked
        au.CargarArchivo();
        ac.CargarArchivo();

        if (jlista_maestroasig.isSelectionEmpty()) {
            JOptionPane.showMessageDialog(jf_inicioregistro, "Debe elegir un maestro", "Error", 2);
        } else if (jlista_metermaestroclase.isSelectionEmpty()) {
            JOptionPane.showMessageDialog(jf_inicioregistro, "Debe elegir una clase", "Error", 2);
        } else {
            boolean yaesta2 = false;
            for (int i = 0; i < maestrosmodificadores.get(jlista_maestroasig.getSelectedIndex()).getClasesense().size(); i++) {
                if (maestrosmodificadores.get(jlista_maestroasig.getSelectedIndex()).getClasesense().get(i).getId() == ac.getClases().get(jlista_metermaestroclase.getSelectedIndex()).getId()) {
                    yaesta2 = true;
                }
            }
            if (yaesta2) {
                JOptionPane.showMessageDialog(jf_inicioregistro, "Este maestro ya esta en la clase", "Error", 2);
            } else {

                if (ac.getClases().get(jlista_metermaestroclase.getSelectedIndex()).getMister() == null) {
                    for (int i = 0; i < au.getUsuarios().size(); i++) {
                        if (au.getUsuarios().get(i) instanceof Maestro) {
                            if (((Maestro) au.getUsuarios().get(i)).getId() == maestrosmodificadores.get(jlista_maestroasig.getSelectedIndex()).getId()) {
                                ((Maestro) au.getUsuarios().get(i)).getClasesense().add(ac.getClases().get(jlista_metermaestroclase.getSelectedIndex()));
                            }
                        }
                    }
                    ac.getClases().get(jlista_metermaestroclase.getSelectedIndex()).setMister(maestrosmodificadores.get(jlista_maestroasig.getSelectedIndex()));
                    JOptionPane.showMessageDialog(jf_inicioregistro, "Se agrego el maestro perfectamente");
                    DefaultTableModel modelotablilla = (DefaultTableModel) jtable_maestroenclase.getModel();
                    modelotablilla.getDataVector().removeAllElements();
                    llenarlistamodmaestros();
                    jtable_maestroenclase.updateUI();
                    for (int i = 0; i < maestrosmodificadores.get(jlista_maestroasig.getSelectedIndex()).getClasesense().size(); i++) {
                        String[] data = {"" + maestrosmodificadores.get(jlista_maestroasig.getSelectedIndex()).getClasesense().get(i).getId(),
                            maestrosmodificadores.get(jlista_maestroasig.getSelectedIndex()).getClasesense().get(i).getNombreclase(),
                            "" + maestrosmodificadores.get(jlista_maestroasig.getSelectedIndex()).getClasesense().get(i).getUv(),
                            maestrosmodificadores.get(jlista_maestroasig.getSelectedIndex()).getClasesense().get(i).getHora()};
                        modelotablilla.addRow(data);
                    }
                } else {
                    JOptionPane.showMessageDialog(jf_inicioregistro, "Esta clase ya tiene maestro", "Error", 2);
                }
                LlenarListaElimMaestro();
                llenarlistamodalumnos();
                LlenarListaEliminarAlumno();
                llenarlistamodmaestros();
                llenarlistadeclases();
                LlenarListaElimClase();
                au.EscribirArchivo();
                au.CargarArchivo();
                ac.EscribirArchivo();
                ac.CargarArchivo();
            }
        }
    }//GEN-LAST:event_jButton8MouseClicked

    private void md_NuevoRolAlumnoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_md_NuevoRolAlumnoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_md_NuevoRolAlumnoActionPerformed

    private void jt_tituloexamenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jt_tituloexamenActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jt_tituloexamenActionPerformed

    private void jl_crearexamenMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jl_crearexamenMouseClicked
        DefaultListModel modelolista20 = (DefaultListModel) lista_clasesmaestro.getModel();
        modelolista20.removeAllElements();
        for (Clase c : ((Maestro) au.getUsuarios().get(cualentra)).getClasesense()) {
            modelolista20.addElement(c);
        }
        lista_clasesmaestro.setModel(modelolista20);
        jp_crearExamen.setVisible(true);
        jp_iniciomaestro.setVisible(false);
        Elim_Jp_examen.setVisible(false);
        Resu_cadaex.setVisible(false);
        Cuadro_Notas.setVisible(false);
        crear_tarea.setVisible(false);
        jf_mod_ex.setVisible(false);
        jf_mod_ex.setVisible(false);
    }//GEN-LAST:event_jl_crearexamenMouseClicked

    private void jl_homemaestrosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jl_homemaestrosMouseClicked
        jp_crearExamen.setVisible(false);
        Elim_Jp_examen.setVisible(false);
        jp_iniciomaestro.setVisible(true);
        Resu_cadaex.setVisible(false);
        Cuadro_Notas.setVisible(false);
        crear_tarea.setVisible(false);
    }//GEN-LAST:event_jl_homemaestrosMouseClicked

    private void jButton9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton9MouseClicked
        if (lista_clasesmaestro.isSelectionEmpty()) {
            JOptionPane.showMessageDialog(jp_crearExamen, "Debe elegir a que clase asignarlo", "Error", 2);
        } else if (jt_tituloexamen.getText().isBlank() || (Integer) sp_minutosexamen.getValue() == 0 || jd_fechaexamen.getDate() == null) {
            JOptionPane.showMessageDialog(jp_crearExamen, "No puede haber ni un espacio en blanco, ni el tiempo en 0", "Error", 2);
        } else {
            questions = new ArrayList();
            respcosm = new ArrayList();
            respdispsm = new ArrayList();
            respcoEnu = new ArrayList();
//            jd_preguntasex.setUndecorated(true);
            jd_preguntasex.setModal(true);
            jd_preguntasex.setLocationRelativeTo(jp_crearExamen);
            jd_preguntasex.setVisible(true);
        }
    }//GEN-LAST:event_jButton9MouseClicked

    private void jLabel151MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel151MouseClicked
        if (questions.isEmpty()) {
            JOptionPane.showMessageDialog(jd_preguntasex, "Debe haber minimo una pregunta", "Error", 2);
        } else {
            au.CargarArchivo();
            ac.CargarArchivo();
            int horita = (Integer) sp_horaexamenab.getValue();
            int minutito = (Integer) sp_minutoexamenab.getValue();
            String time = ((horita <= 9 ? "0" : "") + horita + ":" + (minutito <= 9 ? "0" : "") + minutito);
            int notatotalex = 0;
            for (int i = 0; i < questions.size(); i++) {
                notatotalex += questions.get(i).getPuntuacion();
            }
            Examen ex = new Examen(jt_tituloexamen.getText(), jd_fechaexamen.getDate(), time, (Integer) sp_minutosexamen.getValue(), notatotalex);
            ex.setPreguntas(questions);
            ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(lista_clasesmaestro.getSelectedIndex()).getExamenes().add(ex);
//            JOptionPane.showMessageDialog(this, ((Maestro) au.getUsuarios().get(cualentra)).getNombre()+" "+((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(lista_clasesmaestro.getSelectedIndex()).getExamenes().get(((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(lista_clasesmaestro.getSelectedIndex()).getExamenes().size()-1).getNota());
            for (Clase s : ac.getClases()) {
                if (((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(lista_clasesmaestro.getSelectedIndex()).getId() == s.getId()) {
                    s.getExamenes().add(ex);
//                        JOptionPane.showMessageDialog(this, s.getNombreclase()+" "+s.getExamenes().get(s.getExamenes().size()-1).getNota());
                }
            }
            for (Usuario u : au.getUsuarios()) {
                if (u instanceof Alumno) {
                    for (Clase c : ((Alumno) u).getClases()) {
                        if (c.getId() == ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(lista_clasesmaestro.getSelectedIndex()).getId()) {
                            c.getExamenes().add(new Examen(jt_tituloexamen.getText(), jd_fechaexamen.getDate(), time, (Integer) sp_minutosexamen.getValue(), 0));
                            for (int i = 0; i < questions.size(); i++) {
                                c.getExamenes().get(c.getExamenes().size() - 1).getPreguntas().add(questions.get(i));
                            }
                            c.getExamenes().get(c.getExamenes().size() - 1).setNota(0);
//                                JOptionPane.showMessageDialog(this, u.getNombre()+" "+c.getExamenes().get(c.getExamenes().size()-1).getNota());
                        }
                    }
                }
            }
            LlenarListaElimMaestro();
            llenarlistamodalumnos();
            LlenarListaEliminarAlumno();
            llenarlistamodmaestros();
            llenarlistadeclases();
            LlenarListaElimClase();
            jd_preguntasex.setVisible(false);
            jf_iniciomaestro.setVisible(true);
            questions = new ArrayList();
            respcosm = new ArrayList();
            respdispsm = new ArrayList();
            respcoEnu = new ArrayList();
            JOptionPane.showMessageDialog(jd_preguntasex, "Se agrego el examen correctamente");
            ac.EscribirArchivo();
            ac.CargarArchivo();
            au.EscribirArchivo();
            au.CargarArchivo();
        }

    }//GEN-LAST:event_jLabel151MouseClicked

    private void jButton10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton10MouseClicked
        if ((jb_false.isSelected() || jb_true.isSelected()) && !ja_preguntavf.getText().isBlank()) {
            if (jb_true.isSelected()) {
                questions.add(new VerdaderoFalso(true, ja_preguntavf.getText(), (Integer) puntuacionVF.getValue()));
                ja_preguntavf.setText("");
            } else if (jb_false.isSelected()) {
                questions.add(new VerdaderoFalso(false, ja_preguntavf.getText(), (Integer) puntuacionVF.getValue()));
                ja_preguntavf.setText("");
                JOptionPane.showMessageDialog(jd_preguntasex, "Se agrego la pregunta tipo Verdadero o Falso");
            }
        } else {
            JOptionPane.showMessageDialog(jd_preguntasex, "No puede haber ni pregunta vacia ni respuesta vacia", "Error", 2);
        }

    }//GEN-LAST:event_jButton10MouseClicked

    private void jb_AgregarrespdispsmMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jb_AgregarrespdispsmMouseClicked
        if (tab_respdispsm.getText().isBlank()) {
            JOptionPane.showMessageDialog(jd_preguntasex, "Debe escribir la respuesta disponible", "Error", 2);
        } else {
            respdispsm.add(tab_respdispsm.getText());
            DefaultComboBoxModel modelito = (DefaultComboBoxModel) jc_respsssss.getModel();
            modelito.addElement(tab_respdispsm.getText());
            tab_respdispsm.setText("");
        }
    }//GEN-LAST:event_jb_AgregarrespdispsmMouseClicked

    private void jButton12MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton12MouseClicked
        if (ja_pregunta2.getText().isBlank()) {
            JOptionPane.showMessageDialog(jd_preguntasex, "Debe escribir la pregunta", "Error", 2);
        } else if (respdispsm.isEmpty()) {
            JOptionPane.showMessageDialog(jd_preguntasex, "No hay ni una respuesta disponible", "Error", 2);
        } else {
            respcosm.add((String) jc_respsssss.getSelectedItem());
            DefaultComboBoxModel m = (DefaultComboBoxModel) jc_respsssss.getModel();
            m.removeAllElements();
            jc_respsssss.setModel(m);
            questions.add(new SeleccionMultiple(ja_pregunta2.getText(), (Integer) puntuacionSM.getValue()));
            ((SeleccionMultiple) questions.get(questions.size() - 1)).setRespcorrectas(respcosm);
            ((SeleccionMultiple) questions.get(questions.size() - 1)).setRespdisp(respdispsm);
            JOptionPane.showMessageDialog(jd_preguntasex, "Se agrego la pregunta tipo Seleccion Multiple");
            ja_pregunta2.setText("");
//            tab_respcosm.setText("");
            tab_respdispsm.setText("");
            respcosm = new ArrayList();
            respdispsm = new ArrayList();
        }
    }//GEN-LAST:event_jButton12MouseClicked

    private void jButton14MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton14MouseClicked
        if (tab2_respcoEnu.getText().isBlank()) {
            JOptionPane.showMessageDialog(jd_preguntasex, "Debe escribir la respuesta disponible", "Error", 2);
        } else {
            respcoEnu.add(tab2_respcoEnu.getText());
            tab2_respcoEnu.setText("");
        }
    }//GEN-LAST:event_jButton14MouseClicked

    private void jButton15MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton15MouseClicked
        if (ja_enu.getText().isBlank()) {
            JOptionPane.showMessageDialog(jd_preguntasex, "Debe escribir la pregunta", "Error", 2);
        } else if (respcoEnu.isEmpty()) {
            JOptionPane.showMessageDialog(jd_preguntasex, "No hay ni una respuesta correcta", "Error", 2);
        } else {
            questions.add(new Enumeracion(ja_enu.getText(), (Integer) puntuacionENU.getValue()));
            ((Enumeracion) questions.get(questions.size() - 1)).setRespcorrectas(respcoEnu);
            System.out.println(((Enumeracion) questions.get(questions.size() - 1)).getRespcorrectas());
            JOptionPane.showMessageDialog(jd_preguntasex, "Se agrego la pregunta tipo Enumeracion");
            ja_enu.setText("");
            tab2_respcoEnu.setText("");
            System.out.println(questions.size());
            respcoEnu = new ArrayList();
        }
    }//GEN-LAST:event_jButton15MouseClicked

    private void jl_eliminarexamenMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jl_eliminarexamenMouseClicked
        DefaultListModel modelolista200 = (DefaultListModel) elim_Lista_Elejirclase.getModel();
        modelolista200.removeAllElements();
        for (Clase c : ((Maestro) au.getUsuarios().get(cualentra)).getClasesense()) {
            modelolista200.addElement(c);
        }
        DefaultListModel me = (DefaultListModel) elim_Lista_Elejirexamen.getModel();
        me.removeAllElements();
        elim_Lista_Elejirexamen.setModel(me);
        elim_Lista_Elejirclase.setModel(modelolista200);
        Cuadro_Notas.setVisible(false);
        Elim_Jp_examen.setVisible(true);
        jp_crearExamen.setVisible(false);
        jp_iniciomaestro.setVisible(false);
        Resu_cadaex.setVisible(false);
        jp_Verresualu.setVisible(false);
        jp_cuadroalu.setVisible(false);
        crear_tarea.setVisible(false);
        jf_mod_ex.setVisible(false);
    }//GEN-LAST:event_jl_eliminarexamenMouseClicked

    private void elim_Lista_ElejirclaseMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_elim_Lista_ElejirclaseMouseClicked
        DefaultListModel modelolista50 = (DefaultListModel) elim_Lista_Elejirexamen.getModel();
        modelolista50.removeAllElements();
        for (Examen e : ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(elim_Lista_Elejirclase.getSelectedIndex()).getExamenes()) {
            modelolista50.addElement(e);
        }
        elim_Lista_Elejirexamen.setModel(modelolista50);
    }//GEN-LAST:event_elim_Lista_ElejirclaseMouseClicked

    private void elim_Lista_ElejirexamenMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_elim_Lista_ElejirexamenMouseClicked

    }//GEN-LAST:event_elim_Lista_ElejirexamenMouseClicked

    private void jButton11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton11MouseClicked
        if (elim_Lista_Elejirclase.isSelectionEmpty() || elim_Lista_Elejirexamen.isSelectionEmpty()) {
            JOptionPane.showMessageDialog(jf_iniciomaestro, "Debe elegir en las dos listas", "Error", 2);
        } else {
            au.CargarArchivo();
            ac.CargarArchivo();
            ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(elim_Lista_Elejirclase.getSelectedIndex()).getExamenes().remove(elim_Lista_Elejirexamen.getSelectedIndex());
            for (Clase s : ac.getClases()) {
                if (((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(elim_Lista_Elejirclase.getSelectedIndex()).getId() == s.getId()) {
                    s.getExamenes().remove(elim_Lista_Elejirexamen.getSelectedIndex());
                }
            }
            for (Usuario u : au.getUsuarios()) {
                if (u instanceof Alumno) {
                    for (Clase c : ((Alumno) u).getClases()) {
                        if (c.getId() == ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(elim_Lista_Elejirclase.getSelectedIndex()).getId()) {
                            c.getExamenes().remove(elim_Lista_Elejirexamen.getSelectedIndex());
                        }
                    }
                }
            }
            DefaultListModel modelolista50 = (DefaultListModel) elim_Lista_Elejirexamen.getModel();
            modelolista50.removeAllElements();
            for (Examen e : ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(elim_Lista_Elejirclase.getSelectedIndex()).getExamenes()) {
                modelolista50.addElement(e);
            }
            elim_Lista_Elejirexamen.setModel(modelolista50);
            JOptionPane.showMessageDialog(jf_iniciomaestro, "Se elimino el examen correctamente");
            LlenarListaElimMaestro();
            llenarlistamodalumnos();
            LlenarListaEliminarAlumno();
            llenarlistamodmaestros();
            llenarlistadeclases();
            LlenarListaElimClase();
            ac.EscribirArchivo();
            ac.CargarArchivo();
            au.EscribirArchivo();
            au.CargarArchivo();
        }
    }//GEN-LAST:event_jButton11MouseClicked

    private void jl_vernotaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jl_vernotaMouseClicked
        DefaultListModel modelolisa0 = (DefaultListModel) verresu_listaclase.getModel();
        modelolisa0.removeAllElements();
        for (Clase c : ((Maestro) au.getUsuarios().get(cualentra)).getClasesense()) {
            modelolisa0.addElement(c);
        }
        DefaultListModel md = (DefaultListModel) verresu_listaexa.getModel();
        md.removeAllElements();
        verresu_listaexa.setModel(md);

        DefaultTableModel mt = (DefaultTableModel) tabla_verresu.getModel();
        mt.getDataVector().removeAllElements();
        tabla_verresu.updateUI();
        tabla_verresu.setModel(mt);
        verresu_listaclase.setModel(modelolisa0);
        Cuadro_Notas.setVisible(false);
        Elim_Jp_examen.setVisible(false);
        jp_crearExamen.setVisible(false);
        jp_iniciomaestro.setVisible(false);
        jp_Verresualu.setVisible(false);
        Resu_cadaex.setVisible(true);
        jp_cuadroalu.setVisible(false);
        crear_tarea.setVisible(false);
        jf_mod_ex.setVisible(false);
    }//GEN-LAST:event_jl_vernotaMouseClicked

    private void verresu_listaclaseMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_verresu_listaclaseMouseClicked
        DefaultListModel modelolista51 = (DefaultListModel) verresu_listaexa.getModel();
        modelolista51.removeAllElements();
        for (Examen e : ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(verresu_listaclase.getSelectedIndex()).getExamenes()) {
            modelolista51.addElement(e);
        }
        verresu_listaexa.setModel(modelolista51);
    }//GEN-LAST:event_verresu_listaclaseMouseClicked

    private void verresu_listaexaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_verresu_listaexaMouseClicked
        DefaultTableModel modelotablilla2 = (DefaultTableModel) tabla_verresu.getModel();
        modelotablilla2.getDataVector().removeAllElements();
//        llenarlistamodmaestros();
        tabla_verresu.updateUI();
        int queclase = -1;
        for (int j = 0; j < ac.getClases().size(); j++) {
            if (((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(verresu_listaclase.getSelectedIndex()).getId() == ac.getClases().get(j).getId()) {
                queclase = j;
            }
        }
        for (int i = 0; i < ac.getClases().get(queclase).getAlumnosreciben().size(); i++) {
            for (int j = 0; j < au.getUsuarios().size(); j++) {
                if (au.getUsuarios().get(j) instanceof Alumno) {
                    if (((Alumno) au.getUsuarios().get(j)).getNumcuenta() == ac.getClases().get(queclase).getAlumnosreciben().get(i).getNumcuenta()) {
                        for (int k = 0; k < ((Alumno) au.getUsuarios().get(j)).getClases().size(); k++) {
                            if (((Alumno) au.getUsuarios().get(j)).getClases().get(k).getId() == ac.getClases().get(queclase).getId()) {
                                String[] data2 = {"" + ac.getClases().get(queclase).getAlumnosreciben().get(i).getNumcuenta(),
                                    ac.getClases().get(queclase).getAlumnosreciben().get(i).getNombre(),
                                    ac.getClases().get(queclase).getAlumnosreciben().get(i).getNombreusuario(),
                                    "" + (((Alumno) au.getUsuarios().get(j)).getClases().get(k).getExamenes().get(verresu_listaexa.getSelectedIndex()).getNota())};
                                modelotablilla2.addRow(data2);
                            }
                        }

                    }
                }

            }
        }

        tabla_verresu.setModel(modelotablilla2);
    }//GEN-LAST:event_verresu_listaexaMouseClicked

    private void cn_tablaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cn_tablaMouseClicked
        au.CargarArchivo();
        ac.CargarArchivo();
        DefaultTableModel modelotablita = new DefaultTableModel();
        int queclase = -1;
        int cont = 0;
        Alumno prueba = new Alumno();
        for (int j = 0; j < ac.getClases().size(); j++) {
            if (((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(cn_tabla.getSelectedIndex()).getId() == ac.getClases().get(j).getId()) {
                queclase = j;
                for (int z = 0; z < au.getUsuarios().size(); z++) {
                    if (au.getUsuarios().get(z) instanceof Alumno) {
                        for (int k = 0; k < ac.getClases().get(queclase).getAlumnosreciben().size(); k++) {
                            if (ac.getClases().get(queclase).getAlumnosreciben().get(k).getNumcuenta() == ((Alumno) au.getUsuarios().get(z)).getNumcuenta()) {
                                prueba = (Alumno) au.getUsuarios().get(z);
                            }
                        }

                    }
                }

                int cualclase = -1;
                for (int f = 0; f < prueba.getClases().size(); f++) {
                    if (prueba.getClases().get(f).getId() == ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(cn_tabla.getSelectedIndex()).getId()) {
                        cualclase = f;
                        if (ac.getClases().get(queclase).getExamenes().isEmpty()) {
                            modelotablita.addColumn("Numero de Cuenta");
                            modelotablita.addColumn("Nombre del Alumno");
                            modelotablita.addColumn("Total");
                            Alumno pre = new Alumno();
                            for (int i = 0; i < ac.getClases().get(queclase).getAlumnosreciben().size(); i++) {
                                for (int v = 0; v < au.getUsuarios().size(); v++) {
                                    if (au.getUsuarios().get(v) instanceof Alumno) {
                                        if (((Alumno) au.getUsuarios().get(v)).getNumcuenta() == ac.getClases().get(queclase).getAlumnosreciben().get(i).getNumcuenta()) {
                                            pre = (Alumno) au.getUsuarios().get(v);
                                        }
                                    }
                                }
                                int queclasealu = -1;
                                for (int k = 0; k < pre.getClases().size(); k++) {
                                    if (pre.getClases().get(k).getId() == ac.getClases().get(queclase).getId()) {
                                        queclasealu = k;
                                    }
                                }
                                String[] info = {"" + pre.getNumcuenta(),
                                    pre.getNombre(),
                                    "0/0"
                                };
                                modelotablita.addRow(info);
                            }

                        } else {
                            modelotablita.addColumn("Numero de Cuenta");
                            modelotablita.addColumn("Nombre del Alumno");
                            for (int y = 0; y < ac.getClases().get(queclase).getExamenes().size(); y++) {
                                modelotablita.addColumn(ac.getClases().get(queclase).getExamenes().get(y).getTitulo());
                            }
                            modelotablita.addColumn("Total");
                            String[] data2 = new String[ac.getClases().get(queclase).getExamenes().size() + 3];
                            for (int i = 0; i < ac.getClases().get(queclase).getAlumnosreciben().size(); i++) {
                                for (int v = 0; v < au.getUsuarios().size(); v++) {
                                    if (au.getUsuarios().get(v) instanceof Alumno) {
                                        if (((Alumno) au.getUsuarios().get(v)).getNumcuenta() == ac.getClases().get(queclase).getAlumnosreciben().get(i).getNumcuenta()) {

                                            int queclasealu = -1;
                                            for (int k = 0; k < ((Alumno) au.getUsuarios().get(v)).getClases().size(); k++) {
                                                if (((Alumno) au.getUsuarios().get(v)).getClases().get(k).getId() == ac.getClases().get(queclase).getId()) {
                                                    queclasealu = k;
                                                }
                                            }
                                            int suma = 0;
                                            int sumatodo = 0;
                                            data2[0] = "" + ac.getClases().get(queclase).getAlumnosreciben().get(i).getNumcuenta();
                                            data2[1] = ac.getClases().get(queclase).getAlumnosreciben().get(i).getNombre();
                                            for (int k = 0; k < ac.getClases().get(queclase).getExamenes().size(); k++) {
                                                data2[k + 2] = "" + ((Alumno) au.getUsuarios().get(v)).getClases().get(queclasealu).getExamenes().get(k).getNota() + "/" + ac.getClases().get(queclase).getExamenes().get(k).getNota();
                                                suma += ((Alumno) au.getUsuarios().get(v)).getClases().get(queclasealu).getExamenes().get(k).getNota();
                                                sumatodo += ac.getClases().get(queclase).getExamenes().get(k).getNota();
                                            }
                                            data2[ac.getClases().get(queclase).getExamenes().size() + 2] = suma + "/" + sumatodo;
                                            modelotablita.addRow(data2);
                                        }
                                    }
                                }

                            }
                        }
                        tabla_cuadro.setModel(modelotablita);

//                        for (int j = 0; j < ac.getClases().get(queclase).getAlumnosreciben().size(); j++) {
//                            String[] data2 = {"" + ac.getClases().get(queclase).getAlumnosreciben().get(j).getNumcuenta(),
//                                ac.getClases().get(queclase).getAlumnosreciben().get(j).getNombre(),
//                                ac.getClases().get(queclase).getAlumnosreciben().get(j).getNombreusuario(),
//                                "" + (prueba.getClases().get(cualclase).getExamenes().get(verresu_listaexa.getSelectedIndex()).getNota())};
//                            modelotablilla2.addRow(data2);
//                        }
                    }
                }
            }
        }

    }//GEN-LAST:event_cn_tablaMouseClicked

    private void jl_cuadrodenotasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jl_cuadrodenotasMouseClicked
        DefaultListModel modelolista201 = (DefaultListModel) cn_tabla.getModel();
        modelolista201.removeAllElements();
        for (Clase c : ((Maestro) au.getUsuarios().get(cualentra)).getClasesense()) {
            modelolista201.addElement(c);
        }
        DefaultTableModel mt = (DefaultTableModel) tabla_cuadro.getModel();
        mt.getDataVector().removeAllElements();
        tabla_cuadro.updateUI();
        tabla_cuadro.setModel(mt);
        cn_tabla.setModel(modelolista201);
        Cuadro_Notas.setVisible(true);
        Elim_Jp_examen.setVisible(false);
        jp_crearExamen.setVisible(false);
        jp_iniciomaestro.setVisible(false);
        Resu_cadaex.setVisible(false);
        jp_Verresualu.setVisible(false);
        jp_cuadroalu.setVisible(false);
        crear_tarea.setVisible(false);
        jf_mod_ex.setVisible(false);
    }//GEN-LAST:event_jl_cuadrodenotasMouseClicked

    private void jl_resexamenMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jl_resexamenMouseClicked
        DefaultListModel modelolista = (DefaultListModel) lista_alum_clases.getModel();
        modelolista.removeAllElements();
        for (int i = 0; i < ((Alumno) au.getUsuarios().get(cualentra)).getClases().size(); i++) {
            modelolista.addElement(((Alumno) au.getUsuarios().get(cualentra)).getClases().get(i));
        }
        DefaultListModel modelolista2 = (DefaultListModel) lista_exa_clase.getModel();
        modelolista2.removeAllElements();
        lista_exa_clase.setModel(modelolista2);
        lista_alum_clases.setModel(modelolista);
//        panel_inicioalum.setVisible(false);
        Examenes_alum.setVisible(true);
        jp_Verresualu.setVisible(false);
        jp_cuadroalu.setVisible(false);
        jf_tareas_alumno.setVisible(false);
        panel_inicioalum.setVisible(false);
    }//GEN-LAST:event_jl_resexamenMouseClicked

    private void jl_homemaestros1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jl_homemaestros1MouseClicked
        Examenes_alum.setVisible(false);
        jp_Verresualu.setVisible(false);
        jp_cuadroalu.setVisible(false);
        jf_tareas_alumno.setVisible(false);
        panel_inicioalum.setVisible(true);
    }//GEN-LAST:event_jl_homemaestros1MouseClicked

    private void jButton17MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton17MouseClicked
        tf_user.setText("juan");
        pf_clave.setText("123");
    }//GEN-LAST:event_jButton17MouseClicked

    private void lista_alum_clasesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lista_alum_clasesMouseClicked
        DefaultListModel modeloexa = (DefaultListModel) lista_exa_clase.getModel();
        modeloexa.removeAllElements();
        for (int i = 0; i < ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().size(); i++) {
            modeloexa.addElement(((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(i));
        }
        lista_exa_clase.setModel(modeloexa);
    }//GEN-LAST:event_lista_alum_clasesMouseClicked

    private void jButton16MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton16MouseClicked
        if (lista_alum_clases.isSelectionEmpty() || lista_exa_clase.isSelectionEmpty()) {
            JOptionPane.showMessageDialog(jf_inicioalumno, "Deben estar las dos listas llenas", "Error", 2);
        } else {
            if (((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getIntento()!=0) {
                JOptionPane.showMessageDialog(jf_inicioalumno, "Ya hizo este examen", "Error", 2);
            }else{
                Date actualidad = new Date();
                String horaex = ""+((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getHoraab().charAt(0)+""+((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getHoraab().charAt(1);
                String minex= ""+((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getHoraab().charAt(3)+""+((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getHoraab().charAt(4);;
                System.out.println(horaex+" "+minex);
                Date exa = ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getFecha();
                exa.setHours(Integer.parseInt(horaex));
                exa.setMinutes(Integer.parseInt(minex));
                if(actualidad.before(exa)){
                    JOptionPane.showMessageDialog(jf_inicioalumno, "Lo siento, este examen no ha abierto", "Error", 2);
                }else{
                    ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).setNota(0);
                    jp_mostrarex.removeAll();
                    jp_mostrarex.setPreferredSize(new Dimension(930, 580));
                    jp_mostrarex.setBackground(new Color(255, 153, 153));
                    titulo.setText(((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getTitulo());
                    JPanel panel;
                    paneles = new ArrayList();
                    int x = jl_tituloexamen.getX() + 100;
                    int y = jl_tituloexamen.getY() + 20;
                    JF_EXAMEN.setVisible(true);
                    JF_EXAMEN.setLocationRelativeTo(jf_inicioalumno);
                    System.out.println("Cant Preguntas en examen elegido: " + "" + ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().size());
                    for (int i = 0; i < ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().size(); i++) {
                        panel = new JPanel();
                        panel.setBorder(BorderFactory.createLineBorder(Color.black));
                        panel.setLayout(new GridLayout(0, 1));
                        panel.setBackground(new Color(204, 255, 204));
                        JTextArea pregunta = new JTextArea(((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i).getPregunta());
                        pregunta.setEditable(false);
                        if (((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i) instanceof VerdaderoFalso) {
                            panel.add(pregunta);
                            ButtonGroup grupobotones = new ButtonGroup();
                            JRadioButton verdadero = new JRadioButton("Verdadero");
                            JRadioButton falso = new JRadioButton("Falso");
                            grupobotones.add(verdadero);
                            grupobotones.add(falso);
                            panel.add(verdadero);
                            panel.add(falso);
                            panel.setSize(new Dimension(725, 120));
                            panel.setLocation(x, y);
                            y += 150;
                            paneles.add(panel);
                            try {
                                jp_mostrarex.add(panel);
                            } catch (Exception e) {
                            }
                            panel.setVisible(true);

                        } else if (((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i) instanceof SeleccionMultiple) {
                            panel.add(pregunta);
                            ButtonGroup grupobotones2 = new ButtonGroup();
                            for (int j = 0; j < ((SeleccionMultiple) ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i)).getRespdisp().size(); j++) {
                                JRadioButton op = new JRadioButton(((SeleccionMultiple) ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i)).getRespdisp().get(j));
                                grupobotones2.add(op);
                                panel.add(op);
                            }
                            panel.setSize(new Dimension(725, 120));
                            panel.setLocation(x, y);
                            y += 150;
                            paneles.add(panel);
                            try {
                                jp_mostrarex.add(panel);
                            } catch (Exception e) {
                            }
                            panel.setVisible(true);
                        } else if (((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i) instanceof Enumeracion) {
                            panel.add(pregunta);
                            System.out.println(((Enumeracion) ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i)).getRespcorrectas().size());
                            System.out.println(((Enumeracion) ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i)).getRespcorrectas());
                            for (int j = 0; j < ((Enumeracion) ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i)).getRespcorrectas().size(); j++) {
                                JTextField resps = new JTextField();
                                resps.setBackground(Color.white);
                                resps.setBorder(jl_tituloexamen.getBorder());
                                resps.setSize(new Dimension(60, 10));
                                resps.setText("");
                                panel.add(resps);
                            }
                            panel.setSize(new Dimension(725, 120));
                            panel.setLocation(x, y);
                            y += 150;
                            paneles.add(panel);
                            try {
                                jp_mostrarex.add(panel);
                            } catch (Exception e) {
                            }
                            panel.setVisible(true);

                        }
                        if (i == ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().size() - 1) {
                            JLabel suerte = new JLabel("Suerte");
                            suerte.setFont(jl_tituloexamen.getFont());
                            suerte.setHorizontalAlignment((int) CENTER_ALIGNMENT);
                            suerte.setVerticalAlignment((int) TOP_ALIGNMENT);
                            suerte.setPreferredSize(new Dimension(300, 120));
                            suerte.setSize(new Dimension(725, 120));
                            suerte.setLocation(x, y - 30);
                            try {
                                jp_mostrarex.add(suerte);
                            } catch (Exception e) {
                            }

                        }
                        jp_mostrarex.setPreferredSize(new Dimension(x, y + 80));
                    }
                    tiempotransc=0;
                    tiempoex = ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getTiempo();
                    timer_ex = new Timer(60000, sumar);
                    timer_ex.start();
                    boton_entregarex.setVisible(true);
                    JF_EXAMEN.setLocationRelativeTo(jf_inicioalumno);
                    JF_EXAMEN.setVisible(true);
                }   
            }
        }
    }//GEN-LAST:event_jButton16MouseClicked

    private void boton_entregarexMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_boton_entregarexMouseClicked
        au.CargarArchivo();
        int notaex = 0;
        for (int i = 0; i < paneles.size(); i++) {
            int cuantasbuenas = 0;
            if (((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i) instanceof Enumeracion) {
                cuantasbuenas = 0;
                int notaporbuena = ((Enumeracion) ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i)).getPuntuacion() / ((Enumeracion) ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i)).getRespcorrectas().size();
                for (int j = 0; j < ((Enumeracion) ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i)).getCOPIARESP().size(); j++) {
                    ((Enumeracion) ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i)).getCOPIARESP().remove(j);
                }
                for (int j = 0; j < ((Enumeracion) ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i)).getRespcorrectas().size(); j++) {
                    ((Enumeracion) ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i)).getCOPIARESP().add(((Enumeracion) ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i)).getRespcorrectas().get(j));
                }
                System.out.println("Cant resp correctas: " + ((Enumeracion) ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i)).getRespcorrectas().size());
                for (int j = 0; j < ((Enumeracion) ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i)).getRespcorrectas().size(); j++) {
                    System.out.println("Resp correctas " + ((Enumeracion) ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i)).getRespcorrectas());
                    System.out.println("Copia Resp correctas " + ((Enumeracion) ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i)).getCOPIARESP());
                    if (((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i).evaluar(paneles.get(i), ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i)) == true) {
                        cuantasbuenas++;
                    }
                }
                notaex += notaporbuena * cuantasbuenas;
                if (cuantasbuenas == 0) {
                    JLabel sim = new JLabel(new javax.swing.ImageIcon(getClass().getResource("Imagenes/incorrecta.png")));
                    sim.setPreferredSize(new Dimension(36, 36));
                    sim.setSize(new Dimension(36, 36));
                    paneles.get(i).add(sim);
                    paneles.get(i).setBackground(Color.red);
                    String lcor = "Las respuestas correctas son ";
                    for (int j = 0; j < ((Enumeracion) ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i)).getRespcorrectas().size(); j++) {
                        lcor += ((Enumeracion) ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i)).getRespcorrectas().get(j) + " ";
                    }
                    paneles.get(i).add(new JLabel(lcor));
                } else if (cuantasbuenas == ((Enumeracion) ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i)).getRespcorrectas().size()) {
                    JLabel sim = new JLabel(new javax.swing.ImageIcon(getClass().getResource("Imagenes/buena+(1).png")));
                    sim.setPreferredSize(new Dimension(35, 37));
                    sim.setSize(new Dimension(35, 37));
                    paneles.get(i).add(sim);
                    paneles.get(i).setBackground(Color.green);
                } else {
                    JLabel sim = new JLabel(new javax.swing.ImageIcon(getClass().getResource("Imagenes/maso.png")));
                    sim.setPreferredSize(new Dimension(35, 37));
                    sim.setSize(new Dimension(35, 37));
                    paneles.get(i).add(sim);
                    paneles.get(i).setBackground(Color.yellow);
                    String lcor = "Las respuestas correctas son ";
                    for (int j = 0; j < ((Enumeracion) ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i)).getRespcorrectas().size(); j++) {
                        lcor += ((Enumeracion) ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i)).getRespcorrectas().get(j) + " ";
                    }
                    paneles.get(i).add(new JLabel(lcor));
                }
                System.out.println(cuantasbuenas + " buenas");
                cuantasbuenas = 0;
            } else {
                if (((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i).evaluar(paneles.get(i), ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i)) == true) {
                    notaex += (((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i)).getPuntuacion();
                }
                System.out.println(((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i));
                System.out.println(((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i).evaluar(paneles.get(i), ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getPreguntas().get(i)));
                paneles.get(i).remove(paneles.get(i).getComponentCount() - 1);
            }
        }
        System.out.println("nota" + notaex);

        ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).setNota(notaex);
        ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).setIntento(1);
        for (int i = 0; i < au.getUsuarios().size(); i++) {
            if (au.getUsuarios().get(i) instanceof Alumno) {
                ((Alumno) au.getUsuarios().get(i)).getClases().get(lista_alum_clases.getSelectedIndex()).getExamenes().get(lista_exa_clase.getSelectedIndex()).getNota();
            }
        }
        timer_ex.stop();
        tiempotransc=0;
        boton_entregarex.setVisible(false);
//        JF_EXAMEN.setVisible(false);
        au.EscribirArchivo();
        au.CargarArchivo();
    }//GEN-LAST:event_boton_entregarexMouseClicked

    private void jd_preguntasexMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jd_preguntasexMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jd_preguntasexMouseClicked

    private void listaexaalumMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_listaexaalumMouseClicked
        DefaultTableModel tabla = (DefaultTableModel) tablaresualu.getModel();
        tabla.getDataVector().removeAllElements();
        tablaresualu.updateUI();
        int cualclase = -1;
        for (int i = 0; i < ac.getClases().size(); i++) {
            if (ac.getClases().get(i).getId() == ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(listaclasesalum.getSelectedIndex()).getId()) {
                cualclase = i;
            }
        }
        String[] data = {
            "" + ((Alumno) au.getUsuarios().get(cualentra)).getNumcuenta(),
            ((Alumno) au.getUsuarios().get(cualentra)).getNombre(),
            ((Alumno) au.getUsuarios().get(cualentra)).getNombreusuario(),
            "" + ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(listaclasesalum.getSelectedIndex()).getExamenes().get(listaexaalum.getSelectedIndex()).getNota() + "/" + ac.getClases().get(cualclase).getExamenes().get(listaexaalum.getSelectedIndex()).getNota()
        };
        tabla.addRow(data);
        tablaresualu.setModel(tabla);
    }//GEN-LAST:event_listaexaalumMouseClicked

    private void jl_vernotaalumMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jl_vernotaalumMouseClicked
//        panel_inicioalum.setVisible(true);
        Examenes_alum.setVisible(false);
        jp_Verresualu.setVisible(true);
        jp_cuadroalu.setVisible(false);
        jf_tareas_alumno.setVisible(false);
        panel_inicioalum.setVisible(false);
        DefaultListModel mod = (DefaultListModel) listaclasesalum.getModel();
        mod.removeAllElements();
        for (int i = 0; i < ((Alumno) au.getUsuarios().get(cualentra)).getClases().size(); i++) {
            mod.addElement(((Alumno) au.getUsuarios().get(cualentra)).getClases().get(i));
        }
        listaclasesalum.setModel(mod);

        DefaultListModel ma = (DefaultListModel) listaexaalum.getModel();
        ma.removeAllElements();
        listaexaalum.setModel(ma);

        DefaultTableModel mt = (DefaultTableModel) tablaresualu.getModel();
        mt.getDataVector().removeAllElements();
        tablaresualu.updateUI();
        tablaresualu.setModel(mt);
    }//GEN-LAST:event_jl_vernotaalumMouseClicked

    private void listaclasesalumMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_listaclasesalumMouseClicked
        DefaultListModel mod2 = (DefaultListModel) listaexaalum.getModel();
        mod2.removeAllElements();
        for (int i = 0; i < ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(listaclasesalum.getSelectedIndex()).getExamenes().size(); i++) {
            mod2.addElement(((Alumno) au.getUsuarios().get(cualentra)).getClases().get(listaclasesalum.getSelectedIndex()).getExamenes().get(i));
        }
        listaexaalum.setModel(mod2);
    }//GEN-LAST:event_listaclasesalumMouseClicked

    private void lista2222222222MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lista2222222222MouseClicked
        DefaultTableModel mtabla = new DefaultTableModel();
        for (int i = 0; i < ac.getClases().size(); i++) {
            if (ac.getClases().get(i).getId() == ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista2222222222.getSelectedIndex()).getId()) {
                if (ac.getClases().get(i).getExamenes().isEmpty()) {
                    mtabla.addColumn("ID");
                    mtabla.addColumn("Nombre de la Clase");
                    mtabla.addColumn("Hora");
                    mtabla.addColumn("Unidades Valorativas(UV)");
                    mtabla.addColumn("Total");
                    String[] data = {"" + ac.getClases().get(i).getId(),
                        ac.getClases().get(i).getNombreclase(),
                        ac.getClases().get(i).getHora(),
                        "" + ac.getClases().get(i).getUv(),
                        "0/0"
                    };
                    mtabla.addRow(data);
                } else {
                    mtabla.addColumn("ID");
                    mtabla.addColumn("Nombre de la Clase");
                    mtabla.addColumn("Hora");
                    mtabla.addColumn("Unidades Valorativas(UV)");
                    for (int j = 0; j < ac.getClases().get(i).getExamenes().size(); j++) {
                        mtabla.addColumn(ac.getClases().get(i).getExamenes().get(j).getTitulo());
                    }
                    mtabla.addColumn("Total");
                    String[] data2 = new String[ac.getClases().get(i).getExamenes().size() + 5];
                    data2[0] = "" + ac.getClases().get(i).getId();
                    data2[1] = ac.getClases().get(i).getNombreclase();
                    data2[2] = ac.getClases().get(i).getHora();
                    data2[3] = "" + ac.getClases().get(i).getUv();
                    int suma = 0;
                    int sumatodo = 0;
                    for (int j = 0; j < ac.getClases().get(i).getExamenes().size(); j++) {
                        data2[j + 4] = "" + ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista2222222222.getSelectedIndex()).getExamenes().get(j).getNota() + "/" + ac.getClases().get(i).getExamenes().get(j).getNota();
                        suma += ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista2222222222.getSelectedIndex()).getExamenes().get(j).getNota();
                        sumatodo += ac.getClases().get(i).getExamenes().get(j).getNota();
                    }
                    data2[ac.getClases().get(i).getExamenes().size() + 4] = suma + "/" + sumatodo;
                    mtabla.addRow(data2);
                }
                tabla.setModel(mtabla);
            }
        }
//                                            int suma = 0;
//                                            int sumatodo = 0;
//                                            data2[0] = "" + ac.getClases().get(queclase).getAlumnosreciben().get(i).getNumcuenta();
//                                            data2[1] = ac.getClases().get(queclase).getAlumnosreciben().get(i).getNombre();
//                                            for (int k = 0; k < ac.getClases().get(queclase).getExamenes().size(); k++) {
//                                                data2[k + 2] = "" + ((Alumno) au.getUsuarios().get(v)).getClases().get(queclasealu).getExamenes().get(k).getNota() + "/" + ac.getClases().get(queclase).getExamenes().get(k).getNota();
//                                                suma += ((Alumno) au.getUsuarios().get(v)).getClases().get(queclasealu).getExamenes().get(k).getNota();
//                                                sumatodo += ac.getClases().get(queclase).getExamenes().get(k).getNota();
//                                            }
//                                            data2[ac.getClases().get(queclase).getAlumnosreciben().size() + ac.getClases().get(queclase).getExamenes().size() - 1] = suma + "/" + sumatodo;
//                                            modelotablita.addRow(data2);
//                                        }
//                                    }
//                                }
//
//                            }
//                        }
    }//GEN-LAST:event_lista2222222222MouseClicked

    private void jl_cuadrodenotasalumMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jl_cuadrodenotasalumMouseClicked
        Examenes_alum.setVisible(false);
        jp_Verresualu.setVisible(false);
        jp_cuadroalu.setVisible(true);
        jf_tareas_alumno.setVisible(false);
        panel_inicioalum.setVisible(false);
        DefaultListModel mod2 = (DefaultListModel) lista2222222222.getModel();
        mod2.removeAllElements();
        for (int i = 0; i < ((Alumno) au.getUsuarios().get(cualentra)).getClases().size(); i++) {
            mod2.addElement(((Alumno) au.getUsuarios().get(cualentra)).getClases().get(i));
        }
        lista2222222222.setModel(mod2);
        DefaultTableModel m1 = (DefaultTableModel) tabla.getModel();
        m1.getDataVector().removeAllElements();
        tabla.updateUI();
        tabla.setModel(m1);
    }//GEN-LAST:event_jl_cuadrodenotasalumMouseClicked

    private void jb_crearTareaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jb_crearTareaMouseClicked
        au.CargarArchivo();
        ac.CargarArchivo();
        if (lista_clases_tarea.isSelectionEmpty()) {
            JOptionPane.showMessageDialog(jf_iniciomaestro, "Debe elejir a que clase asignarla", "Error", 2);
        } else if (jt_nombretarea.getText().isEmpty() || jdc_fechacierre.getDate() == null || jdc_fechaentrega.getDate() == null) {
            JOptionPane.showMessageDialog(jf_iniciomaestro, "No puede haber ni un solo espacio en blanco", "Error", 2);
        } else {
            Date f1 = jdc_fechaentrega.getDate();
            Date f2 = jdc_fechacierre.getDate();
            f1.setHours((Integer) hora_tarea_emp.getValue());
            f1.setMinutes((Integer) minuto_tarea_emp.getValue());
            f2.setHours((Integer) hora_tarea_cierre.getValue());
            f2.setMinutes((Integer) minuto_tarea_cierre.getValue());
            ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(lista_clases_tarea.getSelectedIndex()).getTareas().add((new Tarea(jt_nombretarea.getText(), (String) jcb_tipo.getSelectedItem(), f1, f2, false, (Integer) puntaje_tarea.getValue())));
            for (int i = 0; i < ac.getClases().size(); i++) {
                if (ac.getClases().get(i).getId() == ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(lista_clases_tarea.getSelectedIndex()).getId()) {
                    ac.getClases().get(i).getTareas().add(new Tarea(jt_nombretarea.getText(), (String) jcb_tipo.getSelectedItem(), f1, f2, false, (Integer) puntaje_tarea.getValue()));
                }
            }
            for (int i = 0; i < au.getUsuarios().size(); i++) {
                if (au.getUsuarios().get(i) instanceof Alumno) {
                    for (int j = 0; j < ((Alumno) au.getUsuarios().get(i)).getClases().size(); j++) {
                        if (((Alumno) au.getUsuarios().get(i)).getClases().get(j).getId() == ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(lista_clases_tarea.getSelectedIndex()).getId()) {
                            ((Alumno) au.getUsuarios().get(i)).getClases().get(j).getTareas().add(new Tarea(jt_nombretarea.getText(), (String) jcb_tipo.getSelectedItem(), f1, f2, false, 0));
                        }
                    }
                }
            }
            JOptionPane.showMessageDialog(jf_iniciomaestro, "Se agrego la tarea excitosamente");
            au.EscribirArchivo();
            ac.EscribirArchivo();
            au.CargarArchivo();
            ac.CargarArchivo();
        }
    }//GEN-LAST:event_jb_crearTareaMouseClicked

    private void jl_creartareaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jl_creartareaMouseClicked
        DefaultListModel m = (DefaultListModel) lista_clases_tarea.getModel();
        m.removeAllElements();
        for (int i = 0; i < ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().size(); i++) {
            m.addElement(((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(i));
        }
        lista_clases_tarea.setModel(m);
        crear_tarea.setVisible(true);
        Examenes_alum.setVisible(false);
        Cuadro_Notas.setVisible(false);
        Elim_Jp_examen.setVisible(false);
        jp_crearExamen.setVisible(false);
        jp_iniciomaestro.setVisible(false);
        Resu_cadaex.setVisible(false);
        jp_Verresualu.setVisible(false);
        jp_cuadroalu.setVisible(false);
        jf_mod_ex.setVisible(false);
    }//GEN-LAST:event_jl_creartareaMouseClicked

    private void jl_creartareaalumMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jl_creartareaalumMouseClicked
        DefaultListModel m = (DefaultListModel) lista_clases_alum.getModel();
        m.removeAllElements();
        for (int i = 0; i < ((Alumno) au.getUsuarios().get(cualentra)).getClases().size(); i++) {
            m.addElement(((Alumno) au.getUsuarios().get(cualentra)).getClases().get(i));
        }
        lista_clases_alum.setModel(m);
        Examenes_alum.setVisible(false);
        jp_Verresualu.setVisible(false);
        jp_cuadroalu.setVisible(false);
        jf_tareas_alumno.setVisible(true);
        panel_inicioalum.setVisible(false);
        jLabel206.setVisible(false);
        jLabel206.setText("");
        entregartarea.setVisible(false);
        tarea_entregada.setVisible(false);
    }//GEN-LAST:event_jl_creartareaalumMouseClicked

    private void lista_clases_alumMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lista_clases_alumMouseClicked
        DefaultListModel m2 = (DefaultListModel) lista_tareas_alumno2.getModel();
        m2.removeAllElements();
        for (int i = 0; i < ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_clases_alum.getSelectedIndex()).getTareas().size(); i++) {
            m2.addElement(((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_clases_alum.getSelectedIndex()).getTareas().get(i));
        }
        lista_tareas_alumno2.setModel(m2);
    }//GEN-LAST:event_lista_clases_alumMouseClicked

    private void jl_modificarexamenMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jl_modificarexamenMouseClicked
        Cuadro_Notas.setVisible(false);
        Elim_Jp_examen.setVisible(false);
        jp_crearExamen.setVisible(false);
        jp_iniciomaestro.setVisible(false);
        Resu_cadaex.setVisible(false);
        jp_Verresualu.setVisible(false);
        jp_cuadroalu.setVisible(false);
        crear_tarea.setVisible(false);
        jf_mod_ex.setVisible(true);

        DefaultListModel m = (DefaultListModel) listalista_clases.getModel();
        m.removeAllElements();
        for (int i = 0; i < ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().size(); i++) {
            m.addElement(((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(i));
        }
        listalista_clases.setModel(m);
    }//GEN-LAST:event_jl_modificarexamenMouseClicked

    private void jButton19MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton19MouseClicked
        if (lista2lista_exa.isSelectionEmpty() || listalista_clases.isSelectionEmpty()) {
            JOptionPane.showMessageDialog(jf_iniciomaestro, "Se debe elejir la clase y el examen a modificar", "Error", 2);
        } else {
            DefaultListModel modelito = (DefaultListModel) lista_preguntas.getModel();
            modelito.removeAllElements();
            for (int i = 0; i < ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getExamenes().get(lista2lista_exa.getSelectedIndex()).getPreguntas().size(); i++) {
                modelito.addElement(((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getExamenes().get(lista2lista_exa.getSelectedIndex()).getPreguntas().get(i));
            }
            lista_preguntas.setModel(modelito);
            jf_elegir_preguntas.setLocationRelativeTo(jf_iniciomaestro);
            jf_elegir_preguntas.setVisible(true);
        }
    }//GEN-LAST:event_jButton19MouseClicked

    private void jb_modexMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jb_modexMouseClicked
        ac.CargarArchivo();
        au.CargarArchivo();
        if (lista2lista_exa.isSelectionEmpty() || listalista_clases.isSelectionEmpty()) {
            JOptionPane.showMessageDialog(jf_iniciomaestro, "Se debe elejir la clase y el examen a modificar", "Error", 2);
        } else {
            int hora2 = (Integer) sp_newhora.getValue();
            int minutos2 = (Integer) sp_newminute.getValue();
            String nuevahora = ((hora2 <= 9 ? "0" : "") + hora2 + ":" + (minutos2 <= 9 ? "0" : "") + minutos2 + " " + (String) jc_tipohoraclasenueva.getSelectedItem());
            ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getExamenes().get(lista2lista_exa.getSelectedIndex()).setTiempo((Integer) sp_newtimeex.getValue());
            ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getExamenes().get(lista2lista_exa.getSelectedIndex()).setHoraab(nuevahora);
            if (jd_fechaexamenmod.getDate() != null) {
                ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getExamenes().get(lista2lista_exa.getSelectedIndex()).setFecha(jd_fechaexamenmod.getDate());
            }
            for (int i = 0; i < au.getUsuarios().size(); i++) {
                if (au.getUsuarios().get(i) instanceof Alumno) {
                    for (int j = 0; j < ((Alumno) au.getUsuarios().get(i)).getClases().size(); j++) {
                        if (((Alumno) au.getUsuarios().get(i)).getClases().get(j).getId() == ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getId()) {
                            for (int k = 0; k < ((Alumno) au.getUsuarios().get(i)).getClases().get(j).getExamenes().size(); k++) {
                                if (((Alumno) au.getUsuarios().get(i)).getClases().get(j).getExamenes().get(k).getTitulo().equals(((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getExamenes().get(lista2lista_exa.getSelectedIndex()).getTitulo())) {
                                    ((Alumno) au.getUsuarios().get(i)).getClases().get(j).getExamenes().get(k).setTiempo((Integer) sp_newtimeex.getValue());
                                    ((Alumno) au.getUsuarios().get(i)).getClases().get(j).getExamenes().get(k).setHoraab(nuevahora);
                                    if (jd_fechaexamenmod.getDate() != null) {
                                        ((Alumno) au.getUsuarios().get(i)).getClases().get(j).getExamenes().get(k).setFecha(jd_fechaexamenmod.getDate());
                                    }
                                }
                            }
                        }
                    }
                }
            }

            for (int i = 0; i < ac.getClases().size(); i++) {
                if (ac.getClases().get(i).getId() == ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getId()) {
                    for (int j = 0; j < ac.getClases().get(i).getExamenes().size(); j++) {
                        if (ac.getClases().get(i).getExamenes().get(j).getTitulo().equals(((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getExamenes().get(lista2lista_exa.getSelectedIndex()).getTitulo())) {
                            ac.getClases().get(i).getExamenes().get(j).setHoraab(nuevahora);
                            ac.getClases().get(i).getExamenes().get(j).setTiempo((Integer) sp_newtimeex.getValue());
                            if (jd_fechaexamenmod.getDate() != null) {
                                ac.getClases().get(i).getExamenes().get(j).setFecha(jd_fechaexamenmod.getDate());
                            }
                        }
                    }
                }
            }
            jd_fechaexamenmod.setDate(null);
            ac.EscribirArchivo();
            au.EscribirArchivo();
            ac.CargarArchivo();
            au.CargarArchivo();
            JOptionPane.showMessageDialog(jf_iniciomaestro, "Se modifico el examen perfectamente");
        }
    }//GEN-LAST:event_jb_modexMouseClicked

    private void listalista_clasesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_listalista_clasesMouseClicked
        DefaultListModel m2 = (DefaultListModel) lista2lista_exa.getModel();
        m2.removeAllElements();
        for (int i = 0; i < ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getExamenes().size(); i++) {
            m2.addElement(((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getExamenes().get(i));
        }
        lista2lista_exa.setModel(m2);
    }//GEN-LAST:event_listalista_clasesMouseClicked

    private void lista2lista_exaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lista2lista_exaMouseClicked
        if (!lista2lista_exa.isSelectionEmpty()) {
            sp_newtimeex.setValue(((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getExamenes().get(lista2lista_exa.getSelectedIndex()).getTiempo());
            String hs = ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getExamenes().get(lista2lista_exa.getSelectedIndex()).getHoraab().charAt(0) + "" + ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getExamenes().get(lista2lista_exa.getSelectedIndex()).getHoraab().charAt(1);
            String ms = ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getExamenes().get(lista2lista_exa.getSelectedIndex()).getHoraab().charAt(3) + "" + ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getExamenes().get(lista2lista_exa.getSelectedIndex()).getHoraab().charAt(4);
            int hora = Integer.parseInt(hs);
            int minu = Integer.parseInt(ms);
            sp_newhora.setValue(hora);
            sp_newminute.setValue(minu);
        }
    }//GEN-LAST:event_lista2lista_exaMouseClicked

    private void jButton20MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton20MouseClicked
        if (lista_preguntas.isSelectionEmpty()) {
            JOptionPane.showMessageDialog(jf_elegir_preguntas, "Debe elegir la pregunta a modificar", "Error", 2);
        } else {
            if (((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getExamenes().get(lista2lista_exa.getSelectedIndex()).getPreguntas().get(lista_preguntas.getSelectedIndex()) instanceof VerdaderoFalso) {
                jf_modvf.setVisible(true);
                jf_modvf.setLocationRelativeTo(jf_elegir_preguntas);
//                jf_elegir_preguntas.setVisible(false);
            } else if (((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getExamenes().get(lista2lista_exa.getSelectedIndex()).getPreguntas().get(lista_preguntas.getSelectedIndex()) instanceof SeleccionMultiple) {
                respdispsm = new ArrayList();
                respcosm = new ArrayList();
                for (int i = 0; i < ((SeleccionMultiple) ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getExamenes().get(lista2lista_exa.getSelectedIndex()).getPreguntas().get(lista_preguntas.getSelectedIndex())).getRespcorrectas().size(); i++) {
                    ((SeleccionMultiple) ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getExamenes().get(lista2lista_exa.getSelectedIndex()).getPreguntas().get(lista_preguntas.getSelectedIndex())).getRespcorrectas().remove(i);
                }
                for (int i = 0; i < ((SeleccionMultiple) ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getExamenes().get(lista2lista_exa.getSelectedIndex()).getPreguntas().get(lista_preguntas.getSelectedIndex())).getRespdisp().size(); i++) {
                    ((SeleccionMultiple) ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getExamenes().get(lista2lista_exa.getSelectedIndex()).getPreguntas().get(lista_preguntas.getSelectedIndex())).getRespdisp().remove(i);
                }
                for (int i = 0; i < au.getUsuarios().size(); i++) {
                    if (au.getUsuarios().get(i) instanceof Alumno) {
                        for (int j = 0; j < ((Alumno) au.getUsuarios().get(i)).getClases().size(); j++) {
                            if (((Alumno) au.getUsuarios().get(i)).getClases().get(j).getId() == ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getId()) {
                                for (int k = 0; k < ((Alumno) au.getUsuarios().get(i)).getClases().get(j).getExamenes().size(); k++) {
                                    if (((Alumno) au.getUsuarios().get(i)).getClases().get(j).getExamenes().get(k).getTitulo().equals(((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getExamenes().get(lista2lista_exa.getSelectedIndex()).getTitulo())) {
                                        for (int l = 0; l < ((SeleccionMultiple) ((Alumno) au.getUsuarios().get(i)).getClases().get(j).getExamenes().get(k).getPreguntas().get(lista_preguntas.getSelectedIndex())).getRespcorrectas().size(); l++) {
                                            ((SeleccionMultiple) ((Alumno) au.getUsuarios().get(i)).getClases().get(j).getExamenes().get(k).getPreguntas().get(lista_preguntas.getSelectedIndex())).getRespcorrectas().remove(l);
                                        }
                                        for (int l = 0; l < ((SeleccionMultiple) ((Alumno) au.getUsuarios().get(i)).getClases().get(j).getExamenes().get(k).getPreguntas().get(lista_preguntas.getSelectedIndex())).getRespdisp().size(); l++) {
                                            ((SeleccionMultiple) ((Alumno) au.getUsuarios().get(i)).getClases().get(j).getExamenes().get(k).getPreguntas().get(lista_preguntas.getSelectedIndex())).getRespdisp().remove(l);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                for (int i = 0; i < ac.getClases().size(); i++) {
                    if (ac.getClases().get(i).getId() == ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getId()) {
                        for (int j = 0; j < ac.getClases().get(i).getExamenes().size(); j++) {
                            if (ac.getClases().get(i).getExamenes().get(j).getTitulo().equals(((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getExamenes().get(lista2lista_exa.getSelectedIndex()).getTitulo())) {
                                for (int k = 0; k < ((SeleccionMultiple) ac.getClases().get(i).getExamenes().get(j).getPreguntas().get(lista_preguntas.getSelectedIndex())).getRespcorrectas().size(); k++) {
                                    ((SeleccionMultiple) ac.getClases().get(i).getExamenes().get(j).getPreguntas().get(lista_preguntas.getSelectedIndex())).getRespcorrectas().remove(k);
                                }
                                for (int k = 0; k < ((SeleccionMultiple) ac.getClases().get(i).getExamenes().get(j).getPreguntas().get(lista_preguntas.getSelectedIndex())).getRespdisp().size(); k++) {
                                    ((SeleccionMultiple) ac.getClases().get(i).getExamenes().get(j).getPreguntas().get(lista_preguntas.getSelectedIndex())).getRespdisp().remove(k);
                                }
                            }
                        }
                    }
                }
                jf_modsm.setVisible(true);
                jf_modsm.setLocationRelativeTo(jf_elegir_preguntas);
            } else if (((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getExamenes().get(lista2lista_exa.getSelectedIndex()).getPreguntas().get(lista_preguntas.getSelectedIndex()) instanceof Enumeracion) {
                respcoEnu = new ArrayList();
                jf_modEnu.setLocationRelativeTo(jf_elegir_preguntas);
                jf_modEnu.setVisible(true);
            }
        }
    }//GEN-LAST:event_jButton20MouseClicked

    private void jButton21MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton21MouseClicked
        au.CargarArchivo();
        ac.CargarArchivo();
        if (jta_newpreguntavfmod.getText().isBlank() || (!jr_truemod.isSelected() && !jr_falsemod.isSelected())) {
            JOptionPane.showMessageDialog(jf_modvf, "Debe escribir la pregunta y elegir la respuesta", "Error", 2);
        } else {
            ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getExamenes().get(lista2lista_exa.getSelectedIndex()).getPreguntas().get(lista_preguntas.getSelectedIndex()).setPregunta(jta_newpreguntavfmod.getText());
            if (jr_truemod.isSelected()) {
                ((VerdaderoFalso) ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getExamenes().get(lista2lista_exa.getSelectedIndex()).getPreguntas().get(lista_preguntas.getSelectedIndex())).setRespcorrecta(true);
            } else {
                ((VerdaderoFalso) ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getExamenes().get(lista2lista_exa.getSelectedIndex()).getPreguntas().get(lista_preguntas.getSelectedIndex())).setRespcorrecta(false);
            }
            ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getExamenes().get(lista2lista_exa.getSelectedIndex()).getPreguntas().get(lista_preguntas.getSelectedIndex()).setPuntuacion((Integer) jSpinner1.getValue());

            for (int i = 0; i < au.getUsuarios().size(); i++) {
                if (au.getUsuarios().get(i) instanceof Alumno) {
                    for (int j = 0; j < ((Alumno) au.getUsuarios().get(i)).getClases().size(); j++) {
                        if (((Alumno) au.getUsuarios().get(i)).getClases().get(j).getId() == ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getId()) {
                            for (int k = 0; k < ((Alumno) au.getUsuarios().get(i)).getClases().get(j).getExamenes().size(); k++) {
                                if (((Alumno) au.getUsuarios().get(i)).getClases().get(j).getExamenes().get(k).getTitulo().equals(((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getExamenes().get(lista2lista_exa.getSelectedIndex()).getTitulo())) {
                                    ((Alumno) au.getUsuarios().get(i)).getClases().get(j).getExamenes().get(k).getPreguntas().get(lista_preguntas.getSelectedIndex()).setPregunta(jta_newpreguntavfmod.getText());
                                    ((Alumno) au.getUsuarios().get(i)).getClases().get(j).getExamenes().get(k).getPreguntas().get(lista_preguntas.getSelectedIndex()).setPuntuacion((Integer) jSpinner1.getValue());
                                    if (jr_truemod.isSelected()) {
                                        ((VerdaderoFalso) ((Alumno) au.getUsuarios().get(i)).getClases().get(j).getExamenes().get(k).getPreguntas().get(lista_preguntas.getSelectedIndex())).setRespcorrecta(true);
                                    } else {
                                        ((VerdaderoFalso) ((Alumno) au.getUsuarios().get(i)).getClases().get(j).getExamenes().get(k).getPreguntas().get(lista_preguntas.getSelectedIndex())).setRespcorrecta(false);
                                    }
                                }
                            }
                        }
                    }
                }
            }

            for (int i = 0; i < ac.getClases().size(); i++) {
                if (ac.getClases().get(i).getId() == ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getId()) {
                    for (int j = 0; j < ac.getClases().get(i).getExamenes().size(); j++) {
                        if (ac.getClases().get(i).getExamenes().get(j).getTitulo().equals(((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getExamenes().get(lista2lista_exa.getSelectedIndex()).getTitulo())) {
                            ac.getClases().get(i).getExamenes().get(j).getPreguntas().get(lista_preguntas.getSelectedIndex()).setPregunta(jta_newpreguntavfmod.getText());
                            ac.getClases().get(i).getExamenes().get(j).getPreguntas().get(lista_preguntas.getSelectedIndex()).setPuntuacion((Integer) jSpinner1.getValue());
                            if (jr_truemod.isSelected()) {
                                ((VerdaderoFalso) ac.getClases().get(i).getExamenes().get(j).getPreguntas().get(lista_preguntas.getSelectedIndex())).setRespcorrecta(true);
                            } else {
                                ((VerdaderoFalso) ac.getClases().get(i).getExamenes().get(j).getPreguntas().get(lista_preguntas.getSelectedIndex())).setRespcorrecta(false);
                            }
                        }
                    }
                }
            }
            int suma = 0;
            for (int i = 0; i < ac.getClases().size(); i++) {
                if (ac.getClases().get(i).getId() == ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getId()) {
                    for (int j = 0; j < ac.getClases().get(i).getExamenes().size(); j++) {
                        if (ac.getClases().get(i).getExamenes().get(j).getTitulo().equals(((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getExamenes().get(lista2lista_exa.getSelectedIndex()).getTitulo())) {
                            for (int k = 0; k < ac.getClases().get(i).getExamenes().get(j).getPreguntas().size(); k++) {
                                suma += ac.getClases().get(i).getExamenes().get(j).getPreguntas().get(k).getPuntuacion();
                            }
                            ac.getClases().get(i).getExamenes().get(j).setNota(suma);
                        }
                    }
                }
            }

            DefaultListModel modelito = (DefaultListModel) lista_preguntas.getModel();
            modelito.removeAllElements();
            for (int i = 0; i < ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getExamenes().get(lista2lista_exa.getSelectedIndex()).getPreguntas().size(); i++) {
                modelito.addElement(((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getExamenes().get(lista2lista_exa.getSelectedIndex()).getPreguntas().get(i));
            }
            lista_preguntas.setModel(modelito);
            jf_modvf.setVisible(false);
            jta_newpreguntavfmod.setText(tiempoactual);
            jr_truemod.setSelected(false);
            jr_falsemod.setSelected(false);
            jSpinner1.setValue(1);
            JOptionPane.showMessageDialog(jf_modvf, "Se modifico la pregunta correctamente");
            ac.EscribirArchivo();
            au.EscribirArchivo();
            ac.CargarArchivo();
            au.CargarArchivo();
        }

    }//GEN-LAST:event_jButton21MouseClicked

    private void jb_Agregarrespdispsm1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jb_Agregarrespdispsm1MouseClicked
        if (linea_respdisp.getText().isBlank()) {
            JOptionPane.showMessageDialog(jf_modsm, "Debe escribir una respuesta", "Error", 2);
        } else {
            respdispsm.add(linea_respdisp.getText());
            DefaultComboBoxModel m = (DefaultComboBoxModel) linea_respco.getModel();
            m.addElement(linea_respdisp.getText());
            linea_respdisp.setText("");
            JOptionPane.showMessageDialog(jf_modsm, "Se agrego la respuesta");
        }

    }//GEN-LAST:event_jb_Agregarrespdispsm1MouseClicked

    private void jButton22MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton22MouseClicked
        au.CargarArchivo();
        ac.CargarArchivo();
        if (jta2_newquestionsm.getText().isBlank() || respdispsm.isEmpty()) {
            JOptionPane.showMessageDialog(jf_modsm, "Debe haber pregunta y respuestas", "Error", 2);
        } else {
            respcosm.add((String) linea_respco.getSelectedItem());
            ((SeleccionMultiple) ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getExamenes().get(lista2lista_exa.getSelectedIndex()).getPreguntas().get(lista_preguntas.getSelectedIndex())).setPregunta(jta2_newquestionsm.getText());
            ((SeleccionMultiple) ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getExamenes().get(lista2lista_exa.getSelectedIndex()).getPreguntas().get(lista_preguntas.getSelectedIndex())).setRespdisp(respdispsm);
            ((SeleccionMultiple) ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getExamenes().get(lista2lista_exa.getSelectedIndex()).getPreguntas().get(lista_preguntas.getSelectedIndex())).setRespcorrectas(respcosm);
            ((SeleccionMultiple) ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getExamenes().get(lista2lista_exa.getSelectedIndex()).getPreguntas().get(lista_preguntas.getSelectedIndex())).setPuntuacion((Integer) jSpinner2.getValue());
            for (int i = 0; i < au.getUsuarios().size(); i++) {
                if (au.getUsuarios().get(i) instanceof Alumno) {
                    for (int j = 0; j < ((Alumno) au.getUsuarios().get(i)).getClases().size(); j++) {
                        if (((Alumno) au.getUsuarios().get(i)).getClases().get(j).getId() == ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getId()) {
                            for (int k = 0; k < ((Alumno) au.getUsuarios().get(i)).getClases().get(j).getExamenes().size(); k++) {
                                if (((Alumno) au.getUsuarios().get(i)).getClases().get(j).getExamenes().get(k).getTitulo().equals(((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getExamenes().get(lista2lista_exa.getSelectedIndex()).getTitulo())) {
                                    ((SeleccionMultiple) ((Alumno) au.getUsuarios().get(i)).getClases().get(j).getExamenes().get(k).getPreguntas().get(lista_preguntas.getSelectedIndex())).setPregunta(jta2_newquestionsm.getText());
                                    ((SeleccionMultiple) ((Alumno) au.getUsuarios().get(i)).getClases().get(j).getExamenes().get(k).getPreguntas().get(lista_preguntas.getSelectedIndex())).setRespdisp(respdispsm);
                                    ((SeleccionMultiple) ((Alumno) au.getUsuarios().get(i)).getClases().get(j).getExamenes().get(k).getPreguntas().get(lista_preguntas.getSelectedIndex())).setRespcorrectas(respcosm);
                                    ((SeleccionMultiple) ((Alumno) au.getUsuarios().get(i)).getClases().get(j).getExamenes().get(k).getPreguntas().get(lista_preguntas.getSelectedIndex())).setPuntuacion((Integer) jSpinner2.getValue());
                                }
                            }
                        }
                    }
                }
            }

            for (int i = 0; i < ac.getClases().size(); i++) {
                if (ac.getClases().get(i).getId() == ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getId()) {
                    for (int j = 0; j < ac.getClases().get(i).getExamenes().size(); j++) {
                        if (ac.getClases().get(i).getExamenes().get(j).getTitulo().equals(((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getExamenes().get(lista2lista_exa.getSelectedIndex()).getTitulo())) {
                            ((SeleccionMultiple) ac.getClases().get(i).getExamenes().get(j).getPreguntas().get(lista_preguntas.getSelectedIndex())).setPregunta(jta2_newquestionsm.getText());
                            ((SeleccionMultiple) ac.getClases().get(i).getExamenes().get(j).getPreguntas().get(lista_preguntas.getSelectedIndex())).setRespdisp(respdispsm);
                            ((SeleccionMultiple) ac.getClases().get(i).getExamenes().get(j).getPreguntas().get(lista_preguntas.getSelectedIndex())).setRespcorrectas(respcosm);
                            ((SeleccionMultiple) ac.getClases().get(i).getExamenes().get(j).getPreguntas().get(lista_preguntas.getSelectedIndex())).setPuntuacion((Integer) jSpinner2.getValue());
                        }
                    }
                }
            }
            respcosm = new ArrayList();
            respdispsm = new ArrayList();
            JOptionPane.showMessageDialog(jf_modsm, "Se modifico la pregunta");
            jta2_newquestionsm.setText("");
            linea_respdisp.setText("");
            DefaultComboBoxModel m = (DefaultComboBoxModel) linea_respco.getModel();
            m.removeAllElements();
            linea_respco.setModel(m);
            jf_modsm.setVisible(false);
            ac.EscribirArchivo();
            au.EscribirArchivo();
            ac.CargarArchivo();
            au.CargarArchivo();
        }
    }//GEN-LAST:event_jButton22MouseClicked

    private void jButton23MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton23MouseClicked
        if (textf_respcomodenu.getText().isBlank()) {
            JOptionPane.showMessageDialog(jf_elegir_preguntas, "Debe escribir la respuesta disponible", "Error", 2);
        } else {
            respcoEnu.add(textf_respcomodenu.getText());
            textf_respcomodenu.setText("");
            JOptionPane.showMessageDialog(jf_elegir_preguntas, "Se añadio la respuesta");
        }
    }//GEN-LAST:event_jButton23MouseClicked

    private void jButton24MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton24MouseClicked
        au.CargarArchivo();
        ac.CargarArchivo();
        if (ja_modenu.getText().isBlank() || respcoEnu.isEmpty()) {
            JOptionPane.showMessageDialog(jf_elegir_preguntas, "Debe haber una pregunta y sus respuestas", "Error", 2);
        } else {
            ((Enumeracion) ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getExamenes().get(lista2lista_exa.getSelectedIndex()).getPreguntas().get(lista_preguntas.getSelectedIndex())).setPregunta(ja_modenu.getText());
            ((Enumeracion) ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getExamenes().get(lista2lista_exa.getSelectedIndex()).getPreguntas().get(lista_preguntas.getSelectedIndex())).setRespcorrectas(respcoEnu);
            ((Enumeracion) ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getExamenes().get(lista2lista_exa.getSelectedIndex()).getPreguntas().get(lista_preguntas.getSelectedIndex())).setPuntuacion((Integer) jSpinner3.getValue());

            for (int i = 0; i < au.getUsuarios().size(); i++) {
                if (au.getUsuarios().get(i) instanceof Alumno) {
                    for (int j = 0; j < ((Alumno) au.getUsuarios().get(i)).getClases().size(); j++) {
                        if (((Alumno) au.getUsuarios().get(i)).getClases().get(j).getId() == ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getId()) {
                            for (int k = 0; k < ((Alumno) au.getUsuarios().get(i)).getClases().get(j).getExamenes().size(); k++) {
                                if (((Alumno) au.getUsuarios().get(i)).getClases().get(j).getExamenes().get(k).getTitulo().equals(((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getExamenes().get(lista2lista_exa.getSelectedIndex()).getTitulo())) {
                                    ((Enumeracion) ((Alumno) au.getUsuarios().get(i)).getClases().get(j).getExamenes().get(k).getPreguntas().get(lista_preguntas.getSelectedIndex())).setPregunta(ja_modenu.getText());
                                    ((Enumeracion) ((Alumno) au.getUsuarios().get(i)).getClases().get(j).getExamenes().get(k).getPreguntas().get(lista_preguntas.getSelectedIndex())).setRespcorrectas(respcoEnu);
                                    ((Enumeracion) ((Alumno) au.getUsuarios().get(i)).getClases().get(j).getExamenes().get(k).getPreguntas().get(lista_preguntas.getSelectedIndex())).setPuntuacion((Integer) jSpinner3.getValue());

                                }
                            }
                        }
                    }
                }
            }

            for (int i = 0; i < ac.getClases().size(); i++) {
                if (ac.getClases().get(i).getId() == ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getId()) {
                    for (int j = 0; j < ac.getClases().get(i).getExamenes().size(); j++) {
                        if (ac.getClases().get(i).getExamenes().get(j).getTitulo().equals(((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(listalista_clases.getSelectedIndex()).getExamenes().get(lista2lista_exa.getSelectedIndex()).getTitulo())) {
                            ((Enumeracion) ac.getClases().get(i).getExamenes().get(j).getPreguntas().get(lista_preguntas.getSelectedIndex())).setPregunta(ja_modenu.getText());
                            ((Enumeracion) ac.getClases().get(i).getExamenes().get(j).getPreguntas().get(lista_preguntas.getSelectedIndex())).setRespcorrectas(respcoEnu);
                            ((Enumeracion) ac.getClases().get(i).getExamenes().get(j).getPreguntas().get(lista_preguntas.getSelectedIndex())).setPuntuacion((Integer) jSpinner3.getValue());

                        }
                    }
                }
            }
            respcoEnu = new ArrayList();
            ja_modenu.setText("");
            textf_respcomodenu.setText("");
            JOptionPane.showMessageDialog(jf_modEnu, "Se modifico la pregunta");
            jf_modEnu.setVisible(false);
            ac.EscribirArchivo();
            au.EscribirArchivo();
            ac.CargarArchivo();
            au.CargarArchivo();
        }
    }//GEN-LAST:event_jButton24MouseClicked

    private void jButton18MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton18MouseClicked
        if (lista_clases_tarea.isSelectionEmpty()) {
            JOptionPane.showMessageDialog(jf_iniciomaestro, "Eliga primero la clase", "Error", 2);
        } else {
            jf_revisartarea.setLocationRelativeTo(jf_iniciomaestro);
            jf_revisartarea.setVisible(true);
            DefaultListModel listam = (DefaultListModel) jl_tarea.getModel();
            listam.removeAllElements();
            for (int i = 0; i < ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(lista_clases_tarea.getSelectedIndex()).getTareas().size(); i++) {
                listam.addElement(((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(lista_clases_tarea.getSelectedIndex()).getTareas().get(i));
            }

        }
    }//GEN-LAST:event_jButton18MouseClicked

    private void jl_tareaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jl_tareaMouseClicked
        DefaultTreeModel m = (DefaultTreeModel) arbol.getModel();
        DefaultMutableTreeNode raiz = (DefaultMutableTreeNode) m.getRoot();
        DefaultMutableTreeNode si = (DefaultMutableTreeNode) raiz.getChildAt(0);
        DefaultMutableTreeNode no = (DefaultMutableTreeNode) raiz.getChildAt(1);
        si.removeAllChildren();
        no.removeAllChildren();
        for (int i = 0; i < au.getUsuarios().size(); i++) {
            if (au.getUsuarios().get(i) instanceof Alumno) {
            }
        }
        for (int i = 0; i < au.getUsuarios().size(); i++) {
            if (au.getUsuarios().get(i) instanceof Alumno) {
                for (int j = 0; j < ((Alumno) au.getUsuarios().get(i)).getClases().size(); j++) {
                    if (((Alumno) au.getUsuarios().get(i)).getClases().get(j).getId() == ((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(lista_clases_tarea.getSelectedIndex()).getId()) {
                        for (int k = 0; k < ((Alumno) au.getUsuarios().get(i)).getClases().get(j).getTareas().size(); k++) {
                            if (((Alumno) au.getUsuarios().get(i)).getClases().get(j).getTareas().get(k).getTitulo().equals(((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(lista_clases_tarea.getSelectedIndex()).getTareas().get(jl_tarea.getSelectedIndex()).getTitulo())) {
                                DefaultMutableTreeNode nodo = new DefaultMutableTreeNode(((Alumno) au.getUsuarios().get(i)));
                                if (((Alumno) au.getUsuarios().get(i)).getClases().get(j).getTareas().get(k).isEntrega() == true) {
                                    si.add(nodo);
                                    System.out.println(((Alumno) au.getUsuarios().get(i)).getClases().get(j).getTareas().get(k));
                                } else {
                                    no.add(nodo);
                                    System.out.println(((Alumno) au.getUsuarios().get(i)).getClases().get(j).getTareas().get(k));
                                }
                            }
                        }
                    }
                }
            }
        }
        m.reload();
    }//GEN-LAST:event_jl_tareaMouseClicked

    private void jButton25MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton25MouseClicked

        for (int i = 0; i < ((Alumno) nodo_sele.getUserObject()).getClases().size(); i++) {
            if (((Alumno) nodo_sele.getUserObject()).getClases().get(i).getNombreclase().equals(((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(lista_clases_tarea.getSelectedIndex()).getNombreclase())) {
                if (((Alumno) nodo_sele.getUserObject()).getClases().get(i).getTareas().get(jl_tarea.getSelectedIndex()).getTitulo().equals(((Maestro) au.getUsuarios().get(cualentra)).getClasesense().get(lista_clases_tarea.getSelectedIndex()).getTareas().get(jl_tarea.getSelectedIndex()).getTitulo())) {
                    ((Alumno) nodo_sele.getUserObject()).getClases().get(i).getTareas().get(jl_tarea.getSelectedIndex()).setNota((Integer) nota_tarea.getValue());
                }
            }
        }
    }//GEN-LAST:event_jButton25MouseClicked

    private void arbolMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_arbolMouseClicked
        int row = arbol.getClosestRowForLocation(evt.getX(), evt.getY());
        arbol.setSelectionRow(row);
        Object v1 = arbol.getSelectionPath().getLastPathComponent();
        nodo_sele = (DefaultMutableTreeNode) v1;
    }//GEN-LAST:event_arbolMouseClicked

    private void jButton26MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton26MouseClicked
        if (lista_clases_alum.isSelectionEmpty() || lista_tareas_alumno2.isSelectionEmpty()) {
            JOptionPane.showMessageDialog(jf_inicioalumno, "Antes de subirlo eliga la clase y la tarea", "Advertencia", 2);
        } else {
            archivo = null;
            FileInputStream entrada = null;
            ObjectInputStream objeto = null;
            try {
                JFileChooser jfc = new JFileChooser();
                FileNameExtensionFilter filtro = new FileNameExtensionFilter("Bayern Munchen", "txt", "pdf", "ppt", "pdp", "svg", "doc", "docx", "xls", "mp3", "mp4");
                jfc.setFileFilter(filtro);
                int elegir = jfc.showOpenDialog(this);
                if (elegir == JFileChooser.APPROVE_OPTION) {
                    archivo = jfc.getSelectedFile();
                    jLabel206.setText(archivo.getName() + ".FCB");
                    jLabel206.setVisible(true);
                    entregartarea.setVisible(true);
                }
            } catch (Exception e) {
            }

        }
    }//GEN-LAST:event_jButton26MouseClicked

    private void entregartareaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_entregartareaMouseClicked
        au.CargarArchivo();
        ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_clases_alum.getSelectedIndex()).getTareas().get(lista_tareas_alumno2.getSelectedIndex()).setArchivo(archivo);
        ((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_clases_alum.getSelectedIndex()).getTareas().get(lista_tareas_alumno2.getSelectedIndex()).setEntrega(true);
        sba.setVisible(false);
        jLabel206.setVisible(false);
        jSeparator57.setVisible(false);
        jButton26.setVisible(false);
        entregartarea.setVisible(false);
        tarea_entregada.setVisible(true);
        JOptionPane.showMessageDialog(jf_inicioalumno, "Se entrego la tarea correctamente");
        au.EscribirArchivo();
        au.CargarArchivo();
    }//GEN-LAST:event_entregartareaMouseClicked

    private void lista_tareas_alumno2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lista_tareas_alumno2MouseClicked
        Date fechita = new Date();
        if (fechita.before(((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_clases_alum.getSelectedIndex()).getTareas().get(lista_tareas_alumno2.getSelectedIndex()).getFechadeentrega())) {
            JOptionPane.showMessageDialog(jf_inicioalumno, "Esta tarea aun no esta habilitada", "Error", 2);
            tarea_entregada.setVisible(false);
            jLabel206.setVisible(false);
            sba.setVisible(true);
            jLabel206.setVisible(false);
            jSeparator57.setVisible(true);
            jButton26.setVisible(true);
        } else if (fechita.after(((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_clases_alum.getSelectedIndex()).getTareas().get(lista_tareas_alumno2.getSelectedIndex()).getFechadecierre())) {
            JOptionPane.showMessageDialog(jf_inicioalumno, "Esta tarea ya vencio", "Error", 2);
            jLabel206.setVisible(false);
            tarea_entregada.setVisible(false);
            sba.setVisible(true);
            jSeparator57.setVisible(true);
            jButton26.setVisible(true);
        } else {
            if (((Alumno) au.getUsuarios().get(cualentra)).getClases().get(lista_clases_alum.getSelectedIndex()).getTareas().get(lista_tareas_alumno2.getSelectedIndex()).isEntrega() == true) {
                sba.setVisible(false);
                jLabel206.setVisible(false);
                jSeparator57.setVisible(false);
                jButton26.setVisible(false);
                entregartarea.setVisible(false);
                tarea_entregada.setVisible(true);
            } else {
                tarea_entregada.setVisible(false);
                sba.setVisible(true);
                jLabel206.setVisible(true);
                jSeparator57.setVisible(true);
                jButton26.setVisible(true);
            }
        }
    }//GEN-LAST:event_lista_tareas_alumno2MouseClicked

    private void jButton13MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton13MouseClicked
        tf_user.setText("registro");
        pf_clave.setText("registro123");
    }//GEN-LAST:event_jButton13MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Principal().setVisible(true);
            }
        });
    }

    private void llenarchoices() {

        ch_maestros_registro.add("Inicio");
        ch_maestros_registro.add("Ingresar Maestro");
        ch_maestros_registro.add("Modificar Maestro");
        ch_maestros_registro.add("Eliminar Maestro");
        ch_maestros_registro.select(0);

        ch_alumnos_registro.add("Inicio");
        ch_alumnos_registro.add("Ingresar Alumno");
        ch_alumnos_registro.add("Modificar Alumno");
        ch_alumnos_registro.add("Eliminar Alumno");
        ch_alumnos_registro.select(0);

        ch_clases_registro.add("Inicio");
        ch_clases_registro.add("Ingresar Clase");
        ch_clases_registro.add("Modificar Clase");
        ch_clases_registro.add("Agregar Maestro A Clases");
        ch_clases_registro.add("Agregar Alumno A Clases");
        ch_clases_registro.add("Eliminar Clase");
        ch_clases_registro.select(0);

        ch_registro_registro.add("Inicio");
        ch_registro_registro.add("Ingresar Registrante");
        ch_registro_registro.add("Modificar Registrante");
        ch_registro_registro.add("Eliminar Registrante");
        ch_registro_registro.select(0);
    }

    private void llenarlistamodmaestros() {
        DefaultListModel modelo = (DefaultListModel) jl_maestrosamodificar.getModel();
        modelo.removeAllElements();
        maestrosmodificadores = new ArrayList();
        for (int i = 0; i < au.getUsuarios().size(); i++) {
            if (au.getUsuarios().get(i) instanceof Maestro) {
                modelo.addElement(au.getUsuarios().get(i));
                maestrosmodificadores.add((Maestro) au.getUsuarios().get(i));
            }
        }
        jl_maestrosamodificar.setModel(modelo);
    }

    private void llenarlistamodalumnos() {
        DefaultListModel modelo2 = (DefaultListModel) jlista_modalumnos.getModel();
        modelo2.removeAllElements();
        alumnosmodificadores = new ArrayList();
        for (int i = 0; i < au.getUsuarios().size(); i++) {
            if (au.getUsuarios().get(i) instanceof Alumno) {
                modelo2.addElement(au.getUsuarios().get(i));
                alumnosmodificadores.add((Alumno) au.getUsuarios().get(i));
            }
        }
        jlista_modalumnos.setModel(modelo2);
    }

    private void llenarlistadeclases() {
        DefaultListModel modelo3 = (DefaultListModel) jlista_clasesmod.getModel();
        modelo3.removeAllElements();
        clasesmodificadoras = new ArrayList();
        for (int i = 0; i < ac.getClases().size(); i++) {
            modelo3.addElement(ac.getClases().get(i));
            clasesmodificadoras.add(ac.getClases().get(i));
        }
        jlista_clasesmod.setModel(modelo3);
    }

    private void LlenarListaElimMaestro() {
        DefaultListModel modelolistaelimmister = (DefaultListModel) jlista_eliminarmister.getModel();
        modelolistaelimmister.removeAllElements();
        maestrosmodificadores = new ArrayList();
        for (int i = 0; i < au.getUsuarios().size(); i++) {
            if (au.getUsuarios().get(i) instanceof Maestro) {
                modelolistaelimmister.addElement(au.getUsuarios().get(i));
                maestrosmodificadores.add((Maestro) au.getUsuarios().get(i));
            }
        }
        jlista_eliminarmister.setModel(modelolistaelimmister);
    }

    private void LlenarListaEliminarAlumno() {
        DefaultListModel modelolistaelimalum = (DefaultListModel) jlista_eliminarAlumno.getModel();
        modelolistaelimalum.removeAllElements();
        alumnosmodificadores = new ArrayList();
        for (int i = 0; i < au.getUsuarios().size(); i++) {
            if (au.getUsuarios().get(i) instanceof Alumno) {
                modelolistaelimalum.addElement(au.getUsuarios().get(i));
                alumnosmodificadores.add((Alumno) au.getUsuarios().get(i));
            }
        }
        jlista_eliminarAlumno.setModel(modelolistaelimalum);
    }

    private void LlenarListaElimClase() {
        DefaultListModel modelolistaelimclase = (DefaultListModel) jlista_eliminarClase.getModel();
        modelolistaelimclase.removeAllElements();
        clasesmodificadoras = new ArrayList();
        for (int i = 0; i < ac.getClases().size(); i++) {
            modelolistaelimclase.addElement(ac.getClases().get(i));
            clasesmodificadoras.add(ac.getClases().get(i));
        }
        jlista_eliminarClase.setModel(modelolistaelimclase);
        ac.EscribirArchivo();
        ac.CargarArchivo();
    }

    private void llenarlistamodregistro() {
        DefaultListModel modelolistamodreg = (DefaultListModel) jlista_ModificarRegistro.getModel();
        modelolistamodreg.removeAllElements();
        registrosmodificadores = new ArrayList();
        for (int i = 0; i < au.getUsuarios().size(); i++) {
            if (au.getUsuarios().get(i) instanceof Registro) {
                modelolistamodreg.addElement(au.getUsuarios().get(i));
                registrosmodificadores.add((Registro) au.getUsuarios().get(i));
            }
        }
        jlista_ModificarRegistro.setModel(modelolistamodreg);
    }

    private void LlenarListaElimRegistro() {
        DefaultListModel modelo500 = (DefaultListModel) jlista_eliminarRegistro.getModel();
        modelo500.removeAllElements();
        registrosmodificadores = new ArrayList();
        for (int i = 0; i < au.getUsuarios().size(); i++) {
            if (au.getUsuarios().get(i) instanceof Registro) {
                modelo500.addElement(au.getUsuarios().get(i));
                registrosmodificadores.add((Registro) au.getUsuarios().get(i));
            }
        }
        jlista_eliminarRegistro.setModel(modelo500);
    }

    private void actualizartiempo() {
        momentoactual = new Date();
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Cuadro_Notas;
    private javax.swing.JPanel Elim_Jp_examen;
    private javax.swing.JPanel Examenes_alum;
    private javax.swing.JButton JB_MODIFICARMAESTRO;
    private javax.swing.JFrame JF_EXAMEN;
    private javax.swing.JTextField JT_Rolmaestronuevo;
    private javax.swing.JPanel Jp_asignarmaestroclase;
    private javax.swing.JPanel Resu_cadaex;
    private com.toedter.calendar.JDateChooser anioclasenueva;
    private javax.swing.JTree arbol;
    private javax.swing.ButtonGroup bg_vfmod;
    private javax.swing.JButton boton_entregarex;
    private java.awt.Choice ch_alumnos_registro;
    private java.awt.Choice ch_clases_registro;
    private java.awt.Choice ch_maestros_registro;
    private java.awt.Choice ch_registro_registro;
    private javax.swing.JList<String> cn_tabla;
    private javax.swing.JPanel crear_tarea;
    private javax.swing.JList<String> elim_Lista_Elejirclase;
    private javax.swing.JList<String> elim_Lista_Elejirexamen;
    private javax.swing.JButton entregartarea;
    private javax.swing.JLabel esconder1;
    private javax.swing.JTextArea esconder2;
    private javax.swing.JTextArea esconder3;
    private javax.swing.JSpinner hora_tarea_cierre;
    private javax.swing.JSpinner hora_tarea_emp;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton17;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton19;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton20;
    private javax.swing.JButton jButton21;
    private javax.swing.JButton jButton22;
    private javax.swing.JButton jButton23;
    private javax.swing.JButton jButton24;
    private javax.swing.JButton jButton25;
    private javax.swing.JButton jButton26;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jL_fondomenudesp;
    private javax.swing.JLabel jL_fondomenudesp1;
    private javax.swing.JLabel jL_fondomenudesp2;
    private javax.swing.JLabel jL_fondomenudesp3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel100;
    private javax.swing.JLabel jLabel101;
    private javax.swing.JLabel jLabel102;
    private javax.swing.JLabel jLabel103;
    private javax.swing.JLabel jLabel104;
    private javax.swing.JLabel jLabel105;
    private javax.swing.JLabel jLabel106;
    private javax.swing.JLabel jLabel107;
    private javax.swing.JLabel jLabel108;
    private javax.swing.JLabel jLabel109;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel110;
    private javax.swing.JLabel jLabel111;
    private javax.swing.JLabel jLabel112;
    private javax.swing.JLabel jLabel113;
    private javax.swing.JLabel jLabel114;
    private javax.swing.JLabel jLabel115;
    private javax.swing.JLabel jLabel116;
    private javax.swing.JLabel jLabel117;
    private javax.swing.JLabel jLabel118;
    private javax.swing.JLabel jLabel119;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel120;
    private javax.swing.JLabel jLabel121;
    private javax.swing.JLabel jLabel122;
    private javax.swing.JLabel jLabel123;
    private javax.swing.JLabel jLabel124;
    private javax.swing.JLabel jLabel125;
    private javax.swing.JLabel jLabel126;
    private javax.swing.JLabel jLabel127;
    private javax.swing.JLabel jLabel128;
    private javax.swing.JLabel jLabel129;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel130;
    private javax.swing.JLabel jLabel131;
    private javax.swing.JLabel jLabel132;
    private javax.swing.JLabel jLabel133;
    private javax.swing.JLabel jLabel134;
    private javax.swing.JLabel jLabel135;
    private javax.swing.JLabel jLabel136;
    private javax.swing.JLabel jLabel137;
    private javax.swing.JLabel jLabel138;
    private javax.swing.JLabel jLabel139;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel140;
    private javax.swing.JLabel jLabel141;
    private javax.swing.JLabel jLabel142;
    private javax.swing.JLabel jLabel143;
    private javax.swing.JLabel jLabel144;
    private javax.swing.JLabel jLabel145;
    private javax.swing.JLabel jLabel146;
    private javax.swing.JLabel jLabel147;
    private javax.swing.JLabel jLabel148;
    private javax.swing.JLabel jLabel149;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel150;
    private javax.swing.JLabel jLabel151;
    private javax.swing.JLabel jLabel152;
    private javax.swing.JLabel jLabel153;
    private javax.swing.JLabel jLabel154;
    private javax.swing.JLabel jLabel155;
    private javax.swing.JLabel jLabel156;
    private javax.swing.JLabel jLabel157;
    private javax.swing.JLabel jLabel158;
    private javax.swing.JLabel jLabel159;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel160;
    private javax.swing.JLabel jLabel161;
    private javax.swing.JLabel jLabel162;
    private javax.swing.JLabel jLabel163;
    private javax.swing.JLabel jLabel164;
    private javax.swing.JLabel jLabel165;
    private javax.swing.JLabel jLabel166;
    private javax.swing.JLabel jLabel167;
    private javax.swing.JLabel jLabel168;
    private javax.swing.JLabel jLabel169;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel170;
    private javax.swing.JLabel jLabel171;
    private javax.swing.JLabel jLabel172;
    private javax.swing.JLabel jLabel173;
    private javax.swing.JLabel jLabel174;
    private javax.swing.JLabel jLabel175;
    private javax.swing.JLabel jLabel176;
    private javax.swing.JLabel jLabel177;
    private javax.swing.JLabel jLabel178;
    private javax.swing.JLabel jLabel179;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel180;
    private javax.swing.JLabel jLabel181;
    private javax.swing.JLabel jLabel182;
    private javax.swing.JLabel jLabel183;
    private javax.swing.JLabel jLabel184;
    private javax.swing.JLabel jLabel185;
    private javax.swing.JLabel jLabel186;
    private javax.swing.JLabel jLabel187;
    private javax.swing.JLabel jLabel188;
    private javax.swing.JLabel jLabel189;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel190;
    private javax.swing.JLabel jLabel191;
    private javax.swing.JLabel jLabel192;
    private javax.swing.JLabel jLabel193;
    private javax.swing.JLabel jLabel194;
    private javax.swing.JLabel jLabel195;
    private javax.swing.JLabel jLabel196;
    private javax.swing.JLabel jLabel197;
    private javax.swing.JLabel jLabel198;
    private javax.swing.JLabel jLabel199;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel200;
    private javax.swing.JLabel jLabel201;
    private javax.swing.JLabel jLabel202;
    private javax.swing.JLabel jLabel203;
    private javax.swing.JLabel jLabel204;
    private javax.swing.JLabel jLabel205;
    private javax.swing.JLabel jLabel206;
    private javax.swing.JLabel jLabel207;
    private javax.swing.JLabel jLabel208;
    private javax.swing.JLabel jLabel209;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel210;
    private javax.swing.JLabel jLabel211;
    private javax.swing.JLabel jLabel212;
    private javax.swing.JLabel jLabel213;
    private javax.swing.JLabel jLabel214;
    private javax.swing.JLabel jLabel215;
    private javax.swing.JLabel jLabel216;
    private javax.swing.JLabel jLabel217;
    private javax.swing.JLabel jLabel218;
    private javax.swing.JLabel jLabel219;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel220;
    private javax.swing.JLabel jLabel221;
    private javax.swing.JLabel jLabel222;
    private javax.swing.JLabel jLabel223;
    private javax.swing.JLabel jLabel224;
    private javax.swing.JLabel jLabel225;
    private javax.swing.JLabel jLabel226;
    private javax.swing.JLabel jLabel227;
    private javax.swing.JLabel jLabel228;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel72;
    private javax.swing.JLabel jLabel73;
    private javax.swing.JLabel jLabel74;
    private javax.swing.JLabel jLabel75;
    private javax.swing.JLabel jLabel76;
    private javax.swing.JLabel jLabel77;
    private javax.swing.JLabel jLabel78;
    private javax.swing.JLabel jLabel79;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel80;
    private javax.swing.JLabel jLabel81;
    private javax.swing.JLabel jLabel82;
    private javax.swing.JLabel jLabel83;
    private javax.swing.JLabel jLabel84;
    private javax.swing.JLabel jLabel85;
    private javax.swing.JLabel jLabel86;
    private javax.swing.JLabel jLabel87;
    private javax.swing.JLabel jLabel88;
    private javax.swing.JLabel jLabel89;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabel90;
    private javax.swing.JLabel jLabel91;
    private javax.swing.JLabel jLabel92;
    private javax.swing.JLabel jLabel93;
    private javax.swing.JLabel jLabel94;
    private javax.swing.JLabel jLabel95;
    private javax.swing.JLabel jLabel96;
    private javax.swing.JLabel jLabel97;
    private javax.swing.JLabel jLabel98;
    private javax.swing.JLabel jLabel99;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JScrollPane jScrollPane12;
    private javax.swing.JScrollPane jScrollPane13;
    private javax.swing.JScrollPane jScrollPane14;
    private javax.swing.JScrollPane jScrollPane15;
    private javax.swing.JScrollPane jScrollPane16;
    private javax.swing.JScrollPane jScrollPane17;
    private javax.swing.JScrollPane jScrollPane18;
    private javax.swing.JScrollPane jScrollPane19;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane20;
    private javax.swing.JScrollPane jScrollPane21;
    private javax.swing.JScrollPane jScrollPane22;
    private javax.swing.JScrollPane jScrollPane23;
    private javax.swing.JScrollPane jScrollPane24;
    private javax.swing.JScrollPane jScrollPane25;
    private javax.swing.JScrollPane jScrollPane26;
    private javax.swing.JScrollPane jScrollPane27;
    private javax.swing.JScrollPane jScrollPane28;
    private javax.swing.JScrollPane jScrollPane29;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane30;
    private javax.swing.JScrollPane jScrollPane31;
    private javax.swing.JScrollPane jScrollPane32;
    private javax.swing.JScrollPane jScrollPane33;
    private javax.swing.JScrollPane jScrollPane34;
    private javax.swing.JScrollPane jScrollPane35;
    private javax.swing.JScrollPane jScrollPane36;
    private javax.swing.JScrollPane jScrollPane37;
    private javax.swing.JScrollPane jScrollPane38;
    private javax.swing.JScrollPane jScrollPane39;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane40;
    private javax.swing.JScrollPane jScrollPane41;
    private javax.swing.JScrollPane jScrollPane42;
    private javax.swing.JScrollPane jScrollPane43;
    private javax.swing.JScrollPane jScrollPane44;
    private javax.swing.JScrollPane jScrollPane45;
    private javax.swing.JScrollPane jScrollPane46;
    private javax.swing.JScrollPane jScrollPane47;
    private javax.swing.JScrollPane jScrollPane48;
    private javax.swing.JScrollPane jScrollPane49;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane50;
    private javax.swing.JScrollPane jScrollPane51;
    private javax.swing.JScrollPane jScrollPane53;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator10;
    private javax.swing.JSeparator jSeparator11;
    private javax.swing.JSeparator jSeparator12;
    private javax.swing.JSeparator jSeparator13;
    private javax.swing.JSeparator jSeparator14;
    private javax.swing.JSeparator jSeparator15;
    private javax.swing.JSeparator jSeparator16;
    private javax.swing.JSeparator jSeparator17;
    private javax.swing.JSeparator jSeparator18;
    private javax.swing.JSeparator jSeparator19;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator20;
    private javax.swing.JSeparator jSeparator21;
    private javax.swing.JSeparator jSeparator22;
    private javax.swing.JSeparator jSeparator23;
    private javax.swing.JSeparator jSeparator24;
    private javax.swing.JSeparator jSeparator25;
    private javax.swing.JSeparator jSeparator26;
    private javax.swing.JSeparator jSeparator27;
    private javax.swing.JSeparator jSeparator28;
    private javax.swing.JSeparator jSeparator29;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator30;
    private javax.swing.JSeparator jSeparator31;
    private javax.swing.JSeparator jSeparator32;
    private javax.swing.JSeparator jSeparator33;
    private javax.swing.JSeparator jSeparator34;
    private javax.swing.JSeparator jSeparator35;
    private javax.swing.JSeparator jSeparator36;
    private javax.swing.JSeparator jSeparator37;
    private javax.swing.JSeparator jSeparator38;
    private javax.swing.JSeparator jSeparator39;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator40;
    private javax.swing.JSeparator jSeparator41;
    private javax.swing.JSeparator jSeparator42;
    private javax.swing.JSeparator jSeparator43;
    private javax.swing.JSeparator jSeparator44;
    private javax.swing.JSeparator jSeparator45;
    private javax.swing.JSeparator jSeparator46;
    private javax.swing.JSeparator jSeparator47;
    private javax.swing.JSeparator jSeparator48;
    private javax.swing.JSeparator jSeparator49;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator50;
    private javax.swing.JSeparator jSeparator51;
    private javax.swing.JSeparator jSeparator52;
    private javax.swing.JSeparator jSeparator53;
    private javax.swing.JSeparator jSeparator54;
    private javax.swing.JSeparator jSeparator55;
    private javax.swing.JSeparator jSeparator56;
    private javax.swing.JSeparator jSeparator57;
    private javax.swing.JSeparator jSeparator58;
    private javax.swing.JSeparator jSeparator59;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JSeparator jSeparator60;
    private javax.swing.JSeparator jSeparator61;
    private javax.swing.JSeparator jSeparator7;
    private javax.swing.JSeparator jSeparator8;
    private javax.swing.JSeparator jSeparator9;
    private javax.swing.JSpinner jSpinner1;
    private javax.swing.JSpinner jSpinner2;
    private javax.swing.JSpinner jSpinner3;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextArea jTextArea2;
    private javax.swing.JTextArea jTextArea3;
    private javax.swing.JTextArea jTextArea4;
    private javax.swing.JTextArea jTextArea5;
    private javax.swing.JTextArea jTextArea6;
    private javax.swing.JTextArea ja_enu;
    private javax.swing.JTextArea ja_modenu;
    private javax.swing.JTextArea ja_pregunta2;
    private javax.swing.JTextArea ja_preguntavf;
    private javax.swing.JButton jb_Agregarrespdispsm;
    private javax.swing.JButton jb_Agregarrespdispsm1;
    private javax.swing.JButton jb_cerrarsesionregistro;
    private javax.swing.JButton jb_crearTarea;
    private javax.swing.JButton jb_crearclasenueva;
    private javax.swing.JButton jb_crearregistro;
    private javax.swing.JButton jb_crearregistro1;
    private javax.swing.JButton jb_eliminarMaestro;
    private javax.swing.JButton jb_eliminarMaestro1;
    private javax.swing.JButton jb_eliminarMaestro2;
    private javax.swing.JButton jb_eliminarRegistro;
    private javax.swing.JRadioButton jb_false;
    private javax.swing.JButton jb_iniciarsesion;
    private javax.swing.JButton jb_modex;
    private javax.swing.JButton jb_modificarclase;
    private javax.swing.JRadioButton jb_true;
    private javax.swing.JComboBox<String> jc_respsssss;
    private javax.swing.JComboBox<String> jc_tipohoraclasenueva;
    private javax.swing.JComboBox<String> jcb_tipo;
    private com.toedter.calendar.JDateChooser jd_fechaexamen;
    private com.toedter.calendar.JDateChooser jd_fechaexamenmod;
    private javax.swing.JDialog jd_preguntasex;
    private com.toedter.calendar.JDateChooser jdc_fechacierre;
    private com.toedter.calendar.JDateChooser jdc_fechaentrega;
    private javax.swing.JFormattedTextField jf_ModificarSueldoMaestro;
    private javax.swing.JFormattedTextField jf_Sueldomaestronuevo;
    private javax.swing.JFrame jf_elegir_preguntas;
    private javax.swing.JFormattedTextField jf_idclasenueva;
    private javax.swing.JFormattedTextField jf_idmaestronuevo;
    private javax.swing.JFrame jf_inicioalumno;
    private javax.swing.JFrame jf_iniciomaestro;
    private javax.swing.JFrame jf_inicioregistro;
    private javax.swing.JFrame jf_modEnu;
    private javax.swing.JPanel jf_mod_ex;
    private javax.swing.JFormattedTextField jf_modificaridmaestro;
    private javax.swing.JFrame jf_modsm;
    private javax.swing.JFrame jf_modvf;
    private javax.swing.JFormattedTextField jf_numcuentanuevoalumno;
    private javax.swing.JFrame jf_revisartarea;
    private javax.swing.JPanel jf_tareas_alumno;
    private javax.swing.JLabel jl_barramaestros;
    private javax.swing.JLabel jl_barramaestros1;
    private javax.swing.JLabel jl_clave;
    private javax.swing.JLabel jl_clave1;
    private javax.swing.JLabel jl_claveregistro;
    private javax.swing.JLabel jl_correo;
    private javax.swing.JLabel jl_correo1;
    private javax.swing.JLabel jl_correoregistro;
    private javax.swing.JLabel jl_crearexamen;
    private javax.swing.JLabel jl_creartarea;
    private javax.swing.JLabel jl_creartareaalum;
    private javax.swing.JLabel jl_cuadrodenotas;
    private javax.swing.JLabel jl_cuadrodenotasalum;
    private javax.swing.JLabel jl_eliminarexamen;
    private javax.swing.JLabel jl_fondo;
    private javax.swing.JLabel jl_homemaestros;
    private javax.swing.JLabel jl_homemaestros1;
    private javax.swing.JList<String> jl_maestrosamodificar;
    private javax.swing.JLabel jl_modificarexamen;
    private javax.swing.JLabel jl_resexamen;
    private javax.swing.JList<String> jl_tarea;
    private javax.swing.JLabel jl_tituloexamen;
    private javax.swing.JLabel jl_usuario;
    private javax.swing.JLabel jl_usuario1;
    private javax.swing.JLabel jl_usuarioregistro;
    private javax.swing.JLabel jl_vernota;
    private javax.swing.JLabel jl_vernotaalum;
    private javax.swing.JList<String> jlista_ModificarRegistro;
    private javax.swing.JList<String> jlista_alumnosag;
    private javax.swing.JList<String> jlista_clases;
    private javax.swing.JList<String> jlista_clasesmod;
    private javax.swing.JList<String> jlista_eliminarAlumno;
    private javax.swing.JList<String> jlista_eliminarClase;
    private javax.swing.JList<String> jlista_eliminarRegistro;
    private javax.swing.JList<String> jlista_eliminarmister;
    private javax.swing.JList<String> jlista_maestroasig;
    private javax.swing.JList<String> jlista_metermaestroclase;
    private javax.swing.JList<String> jlista_modalumnos;
    private javax.swing.JPanel jp_EliminarAlumno;
    private javax.swing.JPanel jp_EliminarClase;
    private javax.swing.JPanel jp_Verresualu;
    private javax.swing.JPanel jp_asignaralumclase;
    private javax.swing.JPanel jp_crearAlumno;
    private javax.swing.JPanel jp_crearExamen;
    private javax.swing.JPanel jp_crearclase;
    private javax.swing.JPanel jp_crearmaestro;
    private javax.swing.JPanel jp_crearregistro;
    private javax.swing.JPanel jp_cuadroalu;
    private javax.swing.JPanel jp_eliminarmaestro;
    private javax.swing.JPanel jp_iniciomaestro;
    private javax.swing.JPanel jp_inicioregistro;
    private javax.swing.JPanel jp_menudesp;
    private javax.swing.JPanel jp_menudespalumno;
    private javax.swing.JPanel jp_modalumno;
    private javax.swing.JPanel jp_modificarclase;
    private javax.swing.JPanel jp_modificarmaestros;
    private javax.swing.JPanel jp_mostrarex;
    private javax.swing.JPanel jp_todoregistro;
    private javax.swing.JPanel jpanel_elimregistro;
    private javax.swing.JPanel jpanel_modregistro;
    private javax.swing.JRadioButton jr_falsemod;
    private javax.swing.JRadioButton jr_truemod;
    private javax.swing.JSpinner js_Periodoclasenueva;
    private javax.swing.JSpinner js_horaclasenueva;
    private javax.swing.JSpinner js_minutoclasenueva;
    private javax.swing.JSpinner js_semestreclasenueva;
    private javax.swing.JSpinner js_uvclasenueva;
    private javax.swing.JTextField jt_ModificarProfesionMaestro;
    private javax.swing.JTextField jt_ModificarRolMaestro;
    private javax.swing.JTextField jt_carreranuevoalumno;
    private javax.swing.JTextField jt_contraalumnonuevo;
    private javax.swing.JTextField jt_contramaestronuevo;
    private javax.swing.JTextField jt_contraregistromod;
    private javax.swing.JTextField jt_contraregistronuevo;
    private javax.swing.JTextField jt_modificarcontramaestro;
    private javax.swing.JTextField jt_modificarnombremaestro;
    private javax.swing.JTextField jt_modificarusermaestro;
    private javax.swing.JTextField jt_nombrealumnonuevo;
    private javax.swing.JTextField jt_nombreclasenueva;
    private javax.swing.JTextField jt_nombremaestronuevo;
    private javax.swing.JTextField jt_nombreregistromod;
    private javax.swing.JTextField jt_nombreregistronuevo;
    private javax.swing.JTextField jt_nombretarea;
    private javax.swing.JTextField jt_profesionmaestronuevo;
    private javax.swing.JTextField jt_rolalumnonuevo;
    private javax.swing.JTextField jt_tituloexamen;
    private javax.swing.JTextField jt_useralumnonuevo;
    private javax.swing.JTextField jt_usermaestronuevo;
    private javax.swing.JTextField jt_userregistromod;
    private javax.swing.JTextField jt_userregistronuevo;
    private javax.swing.JTextArea jta2_newquestionsm;
    private javax.swing.JTextArea jta_newpreguntavfmod;
    private javax.swing.JTable jtable_alumnosenclase;
    private javax.swing.JTable jtable_maestroenclase;
    private javax.swing.JComboBox<String> linea_respco;
    private javax.swing.JTextField linea_respdisp;
    private javax.swing.JList<String> lista2222222222;
    private javax.swing.JList<String> lista2lista_exa;
    private javax.swing.JList<String> lista_alum_clases;
    private javax.swing.JList<String> lista_clases_alum;
    private javax.swing.JList<String> lista_clases_tarea;
    private javax.swing.JList<String> lista_clasesmaestro;
    private javax.swing.JList<String> lista_exa_clase;
    private javax.swing.JList<String> lista_preguntas;
    private javax.swing.JList<String> lista_tareas_alumno2;
    private javax.swing.JList<String> listaclasesalum;
    private javax.swing.JList<String> listaexaalum;
    private javax.swing.JList<String> listalista_clases;
    private com.toedter.calendar.JDateChooser md1_AnioNuevoClase;
    private javax.swing.JSpinner md1_HoraNuevoClase;
    private javax.swing.JFormattedTextField md1_IDNuevoClase;
    private javax.swing.JSpinner md1_MinutosNuevoClase;
    private javax.swing.JTextField md1_NombreNuevoClase;
    private javax.swing.JSpinner md1_PeriodoNuevoClase;
    private javax.swing.JSpinner md1_SemestreNuevoClase;
    private javax.swing.JComboBox<String> md1_TipoHoraNuevoClase;
    private javax.swing.JSpinner md1_UVNuevoClase;
    private javax.swing.JTextField md_NuevaCarreraAlumno;
    private javax.swing.JTextField md_NuevaContraAlumno;
    private javax.swing.JTextField md_NuevoNombreAlumno;
    private javax.swing.JFormattedTextField md_NuevoNumCuentaAlumno;
    private javax.swing.JTextField md_NuevoRolAlumno;
    private javax.swing.JTextField md_NuevoUserAlumno;
    private javax.swing.JSpinner minuto_tarea_cierre;
    private javax.swing.JSpinner minuto_tarea_emp;
    private javax.swing.JSpinner nota_tarea;
    private javax.swing.JPanel panel_inicioalum;
    private javax.swing.JPasswordField pf_clave;
    private javax.swing.JSpinner puntaje_tarea;
    private javax.swing.JSpinner puntuacionENU;
    private javax.swing.JSpinner puntuacionSM;
    private javax.swing.JSpinner puntuacionVF;
    private javax.swing.ButtonGroup respcoSM;
    private javax.swing.JLabel sba;
    private javax.swing.JLabel sba1;
    private javax.swing.JSpinner sp_horaexamenab;
    private javax.swing.JSpinner sp_minutoexamenab;
    private javax.swing.JSpinner sp_minutosexamen;
    private javax.swing.JSpinner sp_newhora;
    private javax.swing.JSpinner sp_newminute;
    private javax.swing.JSpinner sp_newtimeex;
    private javax.swing.JTextField tab2_respcoEnu;
    private javax.swing.JTextField tab_respdispsm;
    private javax.swing.JTable tabla;
    private javax.swing.JTable tabla_cuadro;
    private javax.swing.JTable tabla_verresu;
    private javax.swing.JTable tablaresualu;
    private javax.swing.JPanel tarea_entregada;
    private javax.swing.JTextField textf_respcomodenu;
    private javax.swing.JTextField tf_user;
    private javax.swing.JLabel titulo;
    private javax.swing.ButtonGroup trueorfalse;
    private javax.swing.JList<String> verresu_listaclase;
    private javax.swing.JList<String> verresu_listaexa;
    // End of variables declaration//GEN-END:variables
    ArrayList<Maestro> maestrosmodificadores;
    ArrayList<Alumno> alumnosmodificadores;
    ArrayList<Registro> registrosmodificadores;
    ArrayList<Clase> clasesmodificadoras;
    AdministrarUsuarios au = new AdministrarUsuarios("./Usuarios.cbm");
    AdministrarClases ac = new AdministrarClases("./Clases.cbm");
    int cualentra = -1;
    Desface desplace;
    Desface desplace2;
    ArrayList<Pregunta> questions = new ArrayList();
    ArrayList<String> respcosm = new ArrayList();
    ArrayList<String> respdispsm = new ArrayList();
    ArrayList<String> respcoEnu = new ArrayList();
    ArrayList<JPanel> paneles;
    Timer timer_ex;
    Date momentoactual;
    String tiempoactual = "";
    Timer time;
    int tiempotransc = 0;
    DefaultMutableTreeNode nodo_sele;
    File archivo;
    int tiempoex;
}
