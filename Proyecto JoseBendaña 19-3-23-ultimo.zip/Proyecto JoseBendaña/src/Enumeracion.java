
import java.awt.Color;
import java.awt.Dimension;
import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Enumeracion extends Pregunta {

    private ArrayList<String> respcorrectas = new ArrayList();
    private ArrayList<String> COPIARESP = new ArrayList();

    public Enumeracion() {
    }

    public Enumeracion(String pregunta, int puntuacion) {
        super(pregunta, puntuacion);
    }

    public ArrayList<String> getCOPIARESP() {
        return COPIARESP;
    }

    public void setCOPIARESP(ArrayList<String> COPIARESP) {
        this.COPIARESP = COPIARESP;
    }

    public ArrayList<String> getRespcorrectas() {
        return respcorrectas;
    }

    public void setRespcorrectas(ArrayList<String> respcorrectas) {
        this.respcorrectas = respcorrectas;
    }

    @Override
    public String toString() {
        return "Enumeracion{" + "respcorrectas=" + respcorrectas + '}';
    }

    @Override
    public boolean evaluar(JPanel panel, Pregunta pregunta) {
        boolean llena = false;
        for (int i = 1; i < respcorrectas.size() + 1; i++) {
            if (!((JTextField) panel.getComponent(i)).getText().isBlank()) {
                llena = true;
            }
        }
        if (llena) {
            for (int i = 0; i < COPIARESP.size(); i++) {
                for (int j = 1; j < panel.getComponentCount(); j++) {
                    if (!((JTextField) panel.getComponent(j)).getText().isBlank()) {
                        if (((JTextField) panel.getComponent(j)).getText().equalsIgnoreCase(COPIARESP.get(i))) {
                            COPIARESP.remove(i);
                            return true;
                        }
                    } else {
                        return false;
                    }
                }

            }
        } else {
            return false;
            
        }
        return false;
    }
}
