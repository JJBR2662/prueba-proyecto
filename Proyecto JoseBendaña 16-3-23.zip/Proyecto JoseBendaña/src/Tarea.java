
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;

class Tarea implements Serializable{
    private ArrayList<Nota> notasdealumnos = new ArrayList();
    private String tipodefile;
    private Date fechadeentrega;
    private static final long serialVersionUID = 1232236752342346732L;

    public Tarea() {
    }

    public Tarea(String tipodefile, Date fechadeentrega) {
        this.tipodefile = tipodefile;
        this.fechadeentrega = fechadeentrega;
    }

    public ArrayList<Nota> getNotasdealumnos() {
        return notasdealumnos;
    }

    public void setNotasdealumnos(ArrayList<Nota> notasdealumnos) {
        this.notasdealumnos = notasdealumnos;
    }

    public String getTipodefile() {
        return tipodefile;
    }

    public void setTipodefile(String tipodefile) {
        this.tipodefile = tipodefile;
    }

    public Date getFechadeentrega() {
        return fechadeentrega;
    }

    public void setFechadeentrega(Date fechadeentrega) {
        this.fechadeentrega = fechadeentrega;
    }

    @Override
    public String toString() {
        return "Tarea{" + "notasdealumnos=" + notasdealumnos + ", tipodefile=" + tipodefile + ", fechadeentrega=" + fechadeentrega + '}';
    }
    
    
}
