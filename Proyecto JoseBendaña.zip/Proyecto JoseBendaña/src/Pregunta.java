
class Pregunta {
    protected String pregunta;
    protected int puntuacion;
    // metodo poli para revisar;

    public Pregunta() {
    }

    public Pregunta(String pregunta, int puntuacion) {
        this.pregunta = pregunta;
        this.puntuacion = puntuacion;
    }

    public int getPuntuacion() {
        return puntuacion;
    }

    public void setPuntuacion(int puntuacion) {
        this.puntuacion = puntuacion;
    }

    public String getPregunta() {
        return pregunta;
    }

    public void setPregunta(String pregunta) {
        this.pregunta = pregunta;
    }

    @Override
    public String toString() {
        return pregunta ;
    }
    
    
}
