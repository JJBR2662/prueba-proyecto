
import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;

class Tarea implements Serializable{
    private ArrayList<Nota> notasdealumnos = new ArrayList();
    private String tipodefile, titulo;
    private Date fechadeentrega;
    private Date fechadecierre;
    private File archivo = null;
    private boolean entrega;
    private int nota;
    private static final long serialVersionUID = 1239234677234732L;

    public Tarea() {
    }

    public Tarea(String titulo, String tipodefile, Date fechadeentrega, Date fechadecierre, boolean entrega, int nota) {
        this.tipodefile = tipodefile;
        this.fechadeentrega = fechadeentrega;
        this.titulo = titulo;
        this.fechadecierre = fechadecierre;
        this.entrega = entrega;
        this.nota = nota;
    }
    
    

    public File getArchivo() {
        return archivo;
    }

    public void setArchivo(File archivo) {
        this.archivo = archivo;
    }

    public boolean isEntrega() {
        return entrega;
    }

    public void setEntrega(boolean entrega) {
        this.entrega = entrega;
    }

    public int getNota() {
        return nota;
    }

    public void setNota(int nota) {
        this.nota = nota;
    }
    
    public void crearArchivo(String path){
        archivo = new File(path);
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public Date getFechadecierre() {
        return fechadecierre;
    }

    public void setFechadecierre(Date fechadecierre) {
        this.fechadecierre = fechadecierre;
    }

    public ArrayList<Nota> getNotasdealumnos() {
        return notasdealumnos;
    }

    public void setNotasdealumnos(ArrayList<Nota> notasdealumnos) {
        this.notasdealumnos = notasdealumnos;
    }

    public String getTipodefile() {
        return tipodefile;
    }

    public void setTipodefile(String tipodefile) {
        this.tipodefile = tipodefile;
    }

    public Date getFechadeentrega() {
        return fechadeentrega;
    }

    public void setFechadeentrega(Date fechadeentrega) {
        this.fechadeentrega = fechadeentrega;
    }

    @Override
    public String toString() {
        return titulo;
    }
    
    
}
