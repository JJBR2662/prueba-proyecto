
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

public class VerdaderoFalso extends Pregunta {

    private boolean respcorrecta;

    public VerdaderoFalso() {
    }

    public VerdaderoFalso(boolean respcorrecta, String pregunta, int puntuacion) {
        super(pregunta, puntuacion);
        this.respcorrecta = respcorrecta;
    }

    public boolean isRespcorrecta() {
        return respcorrecta;
    }

    public void setRespcorrecta(boolean respcorrecta) {
        this.respcorrecta = respcorrecta;
    }

    @Override
    public String toString() {
        return "VerdaderoFalso: "+super.pregunta;
    }

    @Override
    public boolean evaluar(JPanel panel, Pregunta pregunta) {
        if ((!((JRadioButton) panel.getComponent(1)).isSelected()) && (!((JRadioButton) panel.getComponent(2)).isSelected())) {
            JLabel sim = new JLabel(new javax.swing.ImageIcon(getClass().getResource("Imagenes/incorrecta.png")));
            sim.setPreferredSize(new Dimension(36, 36));
            sim.setSize(new Dimension(36, 36));
            panel.add(sim);
            panel.setBackground(Color.red);
            return false;
        } else {
            if (respcorrecta == true) {
                if (((JRadioButton) panel.getComponent(1)).isSelected()) {
                    JLabel sim = new JLabel(new javax.swing.ImageIcon(getClass().getResource("Imagenes/buena+(1).png")));
                    sim.setPreferredSize(new Dimension(35, 37));
                    sim.setSize(new Dimension(35, 37));
                    panel.add(sim);
                    panel.setBackground(Color.green);
                    return true;
                } else {
                    JLabel sim = new JLabel(new javax.swing.ImageIcon(getClass().getResource("Imagenes/incorrecta.png")));
                    sim.setPreferredSize(new Dimension(36, 36));
                    sim.setSize(new Dimension(36, 36));
                    panel.add(sim);
                    panel.setBackground(Color.red);
                    return false;
                }
            } else if (respcorrecta == false) {
                if (((JRadioButton) panel.getComponent(2)).isSelected()) {
                    JLabel sim = new JLabel(new javax.swing.ImageIcon(getClass().getResource("Imagenes/buena+(1).png")));
                    sim.setPreferredSize(new Dimension(35, 37));
                    sim.setSize(new Dimension(35, 37));
                    panel.add(sim);
                    panel.setBackground(Color.green);
                    return true;
                } else {
                    JLabel sim = new JLabel(new javax.swing.ImageIcon(getClass().getResource("Imagenes/incorrecta.png")));
                    sim.setPreferredSize(new Dimension(36, 36));
                    sim.setSize(new Dimension(36, 36));
                    panel.add(sim);
                    panel.setBackground(Color.red);
                    return false;
                }
            }
        }
        return false;
    }

}
