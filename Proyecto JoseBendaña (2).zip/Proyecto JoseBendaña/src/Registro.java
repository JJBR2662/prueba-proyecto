
public class Registro extends Usuario{

    public Registro() {
    }

    public Registro(String nombreusuario, String contra, String nombre) {
        super(nombreusuario, contra, nombre);
    }
}
