
import java.util.ArrayList;


public class Enumeracion extends Pregunta{
    private ArrayList<String> respcorrectas = new ArrayList();

    public Enumeracion() {
    }

    public Enumeracion(String pregunta, int puntuacion) {
        super(pregunta, puntuacion);
    }

    
    
    
    public ArrayList<String> getRespcorrectas() {
        return respcorrectas;
    }

    public void setRespcorrectas(ArrayList<String> respcorrectas) {
        this.respcorrectas = respcorrectas;
    }

    @Override
    public String toString() {
        return "Enumeracion{" + "respcorrectas=" + respcorrectas + '}';
    }
}
