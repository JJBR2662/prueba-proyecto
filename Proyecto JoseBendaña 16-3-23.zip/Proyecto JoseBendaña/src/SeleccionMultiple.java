
import java.util.ArrayList;
import javax.swing.JPanel;


public class SeleccionMultiple extends Pregunta{
    private ArrayList<String> respdisp = new ArrayList();
    private ArrayList<String> respcorrectas = new ArrayList();

    public SeleccionMultiple() {
    }

    public SeleccionMultiple(String pregunta, int puntuacion) {
        super(pregunta, puntuacion);
    }

    

    public ArrayList<String> getRespdisp() {
        return respdisp;
    }

    public void setRespdisp(ArrayList<String> respdisp) {
        this.respdisp = respdisp;
    }

    public ArrayList<String> getRespcorrectas() {
        return respcorrectas;
    }

    public void setRespcorrectas(ArrayList<String> respcorrectas) {
        this.respcorrectas = respcorrectas;
    }

    @Override
    public String toString() {
        return "SeleccionMultiple{" + "respdisp=" + respdisp + ", respcorrectas=" + respcorrectas ;
    }

    @Override
    public boolean evaluar(JPanel panel, Pregunta pregunta) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
}
