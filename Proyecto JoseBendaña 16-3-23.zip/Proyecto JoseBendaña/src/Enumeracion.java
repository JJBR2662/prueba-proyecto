
import java.util.ArrayList;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Enumeracion extends Pregunta {

    private ArrayList<String> respcorrectas = new ArrayList();

    public Enumeracion() {
    }

    public Enumeracion(String pregunta, int puntuacion) {
        super(pregunta, puntuacion);
    }

    public ArrayList<String> getRespcorrectas() {
        return respcorrectas;
    }

    public void setRespcorrectas(ArrayList<String> respcorrectas) {
        this.respcorrectas = respcorrectas;
    }

    @Override
    public String toString() {
        return "Enumeracion{" + "respcorrectas=" + respcorrectas + '}';
    }

    @Override
    public boolean evaluar(JPanel panel, Pregunta pregunta) {
        boolean llena = false;
        for (int i = 1; i < respcorrectas.size() + 1; i++) {
            if (!((JTextField) panel.getComponent(i)).getText().isBlank()) {
                llena = true;
            }
        }
        if (llena) {
            ArrayList<String> copiaresps = new ArrayList();
            for (int i = 0; i < respcorrectas.size(); i++) {
                copiaresps.add(respcorrectas.get(i));
            }
            for (int i = 0; i < respcorrectas.size() + 1; i++) {
                if (!((JTextField) panel.getComponent(i)).getText().isBlank()) {
                    for (int j = 0; j < copiaresps.size(); j++) {
                        if (((JTextField) panel.getComponent(i)).getText().equals(copiaresps.get(j))){
                            
                        }
                    }
                }
            }
            return true;
        } else {
            return false;
        }
//        return true;
    }
}
