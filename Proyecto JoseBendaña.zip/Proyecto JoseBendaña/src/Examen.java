
import java.util.ArrayList;
import java.util.Date;


class Examen {
    private ArrayList<Pregunta> Preguntas = new ArrayList();
    private ArrayList<Nota> notasdeexamen = new ArrayList();
    private String titulo, horaab;
    private int tiempo;
    private Date fecha;

    public Examen() {
    }

    public Examen(String titulo, Date fecha, String horaab, int tiempo) {
        this.titulo = titulo;
        this.fecha = fecha;
        this.horaab = horaab;
        this.tiempo = tiempo;
    }

    
    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    
    public ArrayList<Pregunta> getPreguntas() {
        return Preguntas;
    }

    public void setPreguntas(ArrayList<Pregunta> Preguntas) {
        this.Preguntas = Preguntas;
    }

    public ArrayList<Nota> getNotasdeexamen() {
        return notasdeexamen;
    }

    public void setNotasdeexamen(ArrayList<Nota> notasdeexamen) {
        this.notasdeexamen = notasdeexamen;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getHoraab() {
        return horaab;
    }

    public void setHoraab(String hora) {
        this.horaab = hora;
    }

    public int getTiempo() {
        return tiempo;
    }

    public void setTiempo(int tiempo) {
        this.tiempo = tiempo;
    }

    @Override
    public String toString() {
        return titulo;
    }
    
    
}
