
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;

class Tarea implements Serializable{
    private ArrayList<Nota> notasdealumnos = new ArrayList();
    private String tipodefile, titulo;
    private Date fechadeentrega;
    private Date fechadecierre;
    private static final long serialVersionUID = 12390967584732L;

    public Tarea() {
    }

    public Tarea(String titulo, String tipodefile, Date fechadeentrega, Date fechadecierre) {
        this.tipodefile = tipodefile;
        this.fechadeentrega = fechadeentrega;
        this.titulo = titulo;
        this.fechadecierre = fechadecierre;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public Date getFechadecierre() {
        return fechadecierre;
    }

    public void setFechadecierre(Date fechadecierre) {
        this.fechadecierre = fechadecierre;
    }

    public ArrayList<Nota> getNotasdealumnos() {
        return notasdealumnos;
    }

    public void setNotasdealumnos(ArrayList<Nota> notasdealumnos) {
        this.notasdealumnos = notasdealumnos;
    }

    public String getTipodefile() {
        return tipodefile;
    }

    public void setTipodefile(String tipodefile) {
        this.tipodefile = tipodefile;
    }

    public Date getFechadeentrega() {
        return fechadeentrega;
    }

    public void setFechadeentrega(Date fechadeentrega) {
        this.fechadeentrega = fechadeentrega;
    }

    @Override
    public String toString() {
        return titulo;
    }
    
    
}
