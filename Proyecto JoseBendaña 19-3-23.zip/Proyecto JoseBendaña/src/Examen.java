
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.JFrame;


class Examen implements Serializable {
    private ArrayList<Pregunta> Preguntas = new ArrayList();
    private ArrayList<Nota> notasdeexamen = new ArrayList();
    private String titulo, horaab;
    private int tiempo, nota, intento;
    private Date fecha;
    private JFrame ex;
    private static final long serialVersionUID = 239646111123412L;

    public Examen() {
    }

    public Examen(String titulo, Date fecha, String horaab, int tiempo, int nota) {
        this.titulo = titulo;
        this.fecha = fecha;
        this.horaab = horaab;
        this.tiempo = tiempo;
        this.nota = nota;
        this.intento = intento = 0;
    }

    public int getIntento() {
        return intento;
    }

    public void setIntento(int intento) {
        this.intento = intento;
    }

    public JFrame getEx() {
        return ex;
    }

    public void setEx(JFrame ex) {
        this.ex = ex;
    }
    
    

    public int getNota() {
        return nota;
    }

    public void setNota(int nota) {
        this.nota = nota;
    }

    
    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    
    public ArrayList<Pregunta> getPreguntas() {
        return Preguntas;
    }

    public void setPreguntas(ArrayList<Pregunta> Preguntas) {
        this.Preguntas = Preguntas;
    }

    public ArrayList<Nota> getNotasdeexamen() {
        return notasdeexamen;
    }

    public void setNotasdeexamen(ArrayList<Nota> notasdeexamen) {
        this.notasdeexamen = notasdeexamen;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getHoraab() {
        return horaab;
    }

    public void setHoraab(String hora) {
        this.horaab = hora;
    }

    public int getTiempo() {
        return tiempo;
    }

    public void setTiempo(int tiempo) {
        this.tiempo = tiempo;
    }

    @Override
    public String toString() {
        return titulo;
    }
    
    
}
