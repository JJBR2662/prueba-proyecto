
import java.io.Serializable;
import javax.swing.JPanel;


abstract class Pregunta implements Serializable{
    protected String pregunta;
    protected int puntuacion;
    private static final long serialVersionUID = 13245234575683289L;
    // metodo poli para revisar;

    public Pregunta() {
    }

    public Pregunta(String pregunta, int puntuacion) {
        this.pregunta = pregunta;
        this.puntuacion = puntuacion;
    }

    public int getPuntuacion() {
        return puntuacion;
    }

    public void setPuntuacion(int puntuacion) {
        this.puntuacion = puntuacion;
    }

    public String getPregunta() {
        return pregunta;
    }

    public void setPregunta(String pregunta) {
        this.pregunta = pregunta;
    }

    @Override
    public String toString() {
        return pregunta ;
    }
    
    public abstract boolean evaluar(JPanel panel, Pregunta pregunta);
    
}
