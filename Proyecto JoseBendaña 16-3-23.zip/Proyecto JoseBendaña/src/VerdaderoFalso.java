
import javax.swing.JPanel;
import javax.swing.JRadioButton;


public class VerdaderoFalso extends Pregunta{
    private boolean respcorrecta;

    public VerdaderoFalso() {
    }

    public VerdaderoFalso(boolean respcorrecta, String pregunta, int puntuacion) {
        super(pregunta, puntuacion);
        this.respcorrecta = respcorrecta;
    }

    

    public boolean isRespcorrecta() {
        return respcorrecta;
    }

    public void setRespcorrecta(boolean respcorrecta) {
        this.respcorrecta = respcorrecta;
    }

    @Override
    public String toString() {
        return "VerdaderoFalso{" + "respcorrecta=" + respcorrecta + '}';
    }

    @Override
    public boolean evaluar(JPanel panel, Pregunta pregunta) {
        if ((!((JRadioButton)panel.getComponent(1)).isSelected())&&(!((JRadioButton)panel.getComponent(2)).isSelected())){
            return false;
        }else{
            if (respcorrecta==true){
                if (((JRadioButton)panel.getComponent(1)).isSelected()) {
                    return true;
                }else{
                    return false;
                }
            }else if(respcorrecta==false){
                if (((JRadioButton)panel.getComponent(2)).isSelected()) {
                    return true;
                }else{
                    return false;
                }
            }
        }
        return false;
    }
    
    
}
